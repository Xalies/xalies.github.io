window.MeshVaultScrape = function() {
    const pageUrl = normalizeGrabCadPageUrl(window.location.href);
    const jsonLd = findGrabCadJsonLd();
    const parsedTitle = parseGrabCadTitle(getMeta("og:title") || getMeta("twitter:title") || document.title || "");
    const title = cleanGrabCadTitle(
        jsonLd?.name
        || document.querySelector("h1")?.textContent
        || document.querySelector("[ng-bind='model.name']")?.textContent
        || parsedTitle.title
    );
    const authorNode = findGrabCadAuthorNode();
    const author = cleanGrabCadText(jsonLd?.author?.name || authorNode?.textContent || parsedTitle.author || "");
    const authorUrl = normalizeGrabCadUrl(jsonLd?.author?.url || authorNode?.getAttribute?.("href") || "");
    const description = cleanGrabCadHtml(
        jsonLd?.description
        || findGrabCadDescriptionHtml()
        || plainTextToGrabCadHtml(getMeta("description") || getMeta("og:description") || "")
    );
    const images = collectGrabCadImages(jsonLd);
    const thumbnailUrl = images[0] || normalizeGrabCadImage(getMeta("og:image") || getMeta("twitter:image") || "");
    const tags = collectGrabCadTags();

    return {
        sourceSite: "GrabCAD",
        sourceModelId: extractGrabCadModelId(pageUrl),
        sourceUrl: pageUrl,
        title,
        author,
        authorUrl,
        summary: firstGrabCadText(description || getMeta("description") || ""),
        description,
        tags,
        license: "",
        category: collectGrabCadCategory(),
        thumbnailUrl,
        images,
        publishedAtUtc: normalizeGrabCadDate(jsonLd?.datePublished),
        modifiedAtUtc: normalizeGrabCadDate(jsonLd?.dateModified),
        sourceMetadataMethod: jsonLd ? "grabcad-jsonld-dom" : "grabcad-dom"
    };
};

function getMeta(name) {
    return document.querySelector(`meta[property="${name}"]`)?.content
        || document.querySelector(`meta[name="${name}"]`)?.content
        || "";
}

function findGrabCadJsonLd() {
    for (const script of Array.from(document.querySelectorAll('script[type="application/ld+json"]'))) {
        try {
            const data = JSON.parse(script.textContent || "{}");
            const items = Array.isArray(data) ? data : [data];
            const found = items.find((item) => item?.name && (item.image || item.description || String(item.url || "").includes("/library/")));
            if (found) return found;
        } catch (_) {
            // Keep looking.
        }
    }
    return null;
}

function parseGrabCadTitle(rawTitle) {
    let title = cleanGrabCadText(rawTitle)
        .replace(/\s*\|\s*3D CAD Model Library\s*\|\s*GrabCAD.*$/i, "")
        .replace(/\s*-\s*GrabCAD.*$/i, "");
    let author = "";
    const byMatch = title.match(/^(.*?)\s+by\s+(.+)$/i);
    if (byMatch) {
        title = cleanGrabCadText(byMatch[1]);
        author = cleanGrabCadText(byMatch[2]);
    }
    return { title, author };
}

function findGrabCadAuthorNode() {
    return document.querySelector("a.content-author__name[ng-bind='model.author.name']")
        || document.querySelector("a.content-author__name")
        || document.querySelector("a[href^='/profile/']")
        || Array.from(document.querySelectorAll("a[href]")).find((node) => /\/profile\//i.test(node.getAttribute("href") || ""));
}

function findGrabCadDescriptionHtml() {
    const selectors = [
        "div.description[ng-show]",
        "div.description",
        "[class*='description' i]",
        "[data-testid*='description' i]"
    ];
    for (const selector of selectors) {
        const node = document.querySelector(selector);
        const text = cleanGrabCadText(node?.textContent || "");
        if (node && text.length > 20) return node.innerHTML || "";
    }
    return "";
}

function collectGrabCadImages(jsonLd) {
    const urls = [];
    const add = (value, element = null) => {
        const image = normalizeGrabCadImage(value);
        if (!image || isBadGrabCadImage(image, element)) return;
        urls.push(image);
    };

    extractGrabCadScreenshotUrlsFromText(document.documentElement?.innerHTML || "").forEach(add);
    [jsonLd?.image].flat().filter(Boolean).forEach(add);
    add(getMeta("og:image"));
    add(getMeta("twitter:image"));

    const scope = document.querySelector("main")
        || document.querySelector("[class*='model' i]")
        || document.body;
    scope.querySelectorAll("img.image-content, img[ng-src*='/screenshots/pics/'], img[src*='/screenshots/pics/']").forEach((img) => {
        [
            img.getAttribute("ng-src"),
            img.currentSrc,
            img.src,
            img.getAttribute("src"),
            img.getAttribute("data-src")
        ].forEach((url) => add(url, img));
    });
    scope.querySelectorAll("img").forEach((img) => {
        bestGrabCadSrcsetUrls(img.getAttribute("srcset")).forEach((url) => add(url, img));
        [
            img.currentSrc,
            img.src,
            img.getAttribute("src"),
            img.getAttribute("data-src"),
            img.getAttribute("data-original"),
            img.getAttribute("data-lazy-src")
        ].forEach((url) => add(url, img));
    });
    scope.querySelectorAll("[style], [data-src], [data-image], [data-url]").forEach((node) => {
        extractGrabCadUrlsFromText(node.getAttribute("style") || "").forEach((url) => add(url, node));
        add(node.getAttribute("data-src"), node);
        add(node.getAttribute("data-image"), node);
        add(node.getAttribute("data-url"), node);
    });
    Array.from(document.scripts).forEach((script) => {
        extractGrabCadScreenshotUrlsFromText(script.textContent || "").forEach(add);
        extractGrabCadUrlsFromText(script.textContent || "").forEach(add);
        extractGrabCadImageValuesFromText(script.textContent || "").forEach(add);
    });
    document.querySelectorAll("[ng-init], [ng-model], [ng-repeat]").forEach((node) => {
        extractGrabCadUrlsFromText(node.getAttribute("ng-init") || "").forEach((url) => add(url, node));
        extractGrabCadImageValuesFromText(node.getAttribute("ng-init") || "").forEach((url) => add(url, node));
        extractGrabCadImageValuesFromText(node.getAttribute("ng-repeat") || "").forEach((url) => add(url, node));
    });

    return sortGrabCadImages(uniqueGrabCadStrings(urls)).slice(0, 12);
}

function normalizeGrabCadImage(raw) {
    if (!raw || typeof raw !== "string") return "";
    try {
        return new URL(raw.replace(/&amp;/g, "&").trim(), window.location.origin).toString();
    } catch (_) {
        return "";
    }
}

function isBadGrabCadImage(url, element = null) {
    const lower = String(url || "").toLowerCase();
    if (/(?:placeholder|default|missing|missing_medium|blank|no[_-]?image|image-placeholder|spacer|transparent)/i.test(lower)) return true;
    const looksLikeImage = /\.(?:png|jpe?g|webp)(?:[?#]|$)/i.test(lower)
        || lower.includes("grabcad.com/screenshots/pics/")
        || lower.includes("grabcad.com") && /(?:model|library|image|render|large|medium|small|thumbnail|picture|screenshot)/i.test(lower)
        || lower.includes("s3.amazonaws.com/gc-p/") && /(?:pictures|images|renders|screenshots|large|medium|small|thumbnail|uploads|cads)/i.test(lower)
        || lower.includes("d2t1xqejof9utc.cloudfront.net") && /(?:pictures|images|renders|screenshots|large|medium|small|thumbnail|uploads|cads)/i.test(lower);
    if (!looksLikeImage) return true;
    if (lower.includes("avatar") || lower.includes("profile") || lower.includes("logo") || lower.includes("ads")) return true;
    if (element?.closest?.("header, nav, footer, [class*='avatar' i], [class*='profile' i], [class*='author' i], [class*='ad' i]")) return true;
    return false;
}

function sortGrabCadImages(values) {
    return values.slice().sort((left, right) => scoreGrabCadImage(right) - scoreGrabCadImage(left));
}

function scoreGrabCadImage(value) {
    const lower = String(value || "").toLowerCase();
    let score = 0;
    if (lower.includes("/screenshots/pics/")) score += 1000;
    if (lower.includes("/large.")) score += 300;
    if (lower.includes("/medium.")) score += 150;
    if (lower.includes("/small.")) score += 50;
    if (lower.includes("missing") || lower.includes("placeholder")) score -= 10000;
    return score;
}

function extractGrabCadUrlsFromText(text) {
    return Array.from(String(text || "").matchAll(/https?:\\?\/\\?\/[^"')<>\s]+/gi))
        .map((match) => match[0].replace(/\\\//g, "/").replace(/&amp;/g, "&"));
}

function extractGrabCadScreenshotUrlsFromText(text) {
    const raw = String(text || "")
        .replace(/&quot;/g, '"')
        .replace(/&#34;/g, '"')
        .replace(/\\u002F/g, "/")
        .replace(/\\\//g, "/");
    const matches = [
        ...raw.matchAll(/https?:\/\/grabcad\.com\/screenshots\/pics\/[^"')<>\s]+/gi),
        ...raw.matchAll(/\/screenshots\/pics\/[^"')<>\s]+/gi)
    ];
    return matches
        .map((match) => match[0].replace(/&amp;/g, "&"))
        .map((url) => url.startsWith("http") ? url : `https://grabcad.com${url}`);
}

function extractGrabCadImageValuesFromText(text) {
    const values = [];
    const raw = String(text || "");
    const patterns = [
        /(?:large|medium|small|thumb|thumbnail|image|image_url|url)["']?\s*[:=]\s*["']([^"']+)["']/gi,
        /\\?"(?:large|medium|small|thumb|thumbnail|image|image_url|url)\\?"\s*:\s*\\?"([^"\\]+)\\?"/gi
    ];
    patterns.forEach((pattern) => {
        let match;
        while ((match = pattern.exec(raw)) !== null) {
            values.push(match[1].replace(/\\\//g, "/").replace(/&amp;/g, "&"));
        }
    });
    return values;
}

function bestGrabCadSrcsetUrls(srcset) {
    if (!srcset) return [];
    return srcset.split(",")
        .map((entry) => {
            const [url, descriptor] = entry.trim().split(/\s+/);
            const width = descriptor?.endsWith("w") ? parseInt(descriptor, 10) || 0 : 0;
            return { url, width };
        })
        .sort((left, right) => right.width - left.width)
        .map((entry) => entry.url)
        .filter(Boolean);
}

function collectGrabCadTags() {
    const tags = new Set();
    document.querySelectorAll("a[href*='/tags/'], a[href*='tag='], .tag, [class*='tag' i] a").forEach((node) => {
        const text = cleanGrabCadText(node.textContent || "").replace(/^#/, "");
        if (text && text.length < 64) tags.add(text);
    });
    return Array.from(tags);
}

function collectGrabCadCategory() {
    const crumbs = Array.from(document.querySelectorAll("a[href*='/library'], a[href*='/categories'], nav a"))
        .map((node) => cleanGrabCadText(node.textContent || ""))
        .filter((text) => text && !/^grabcad|library|models$/i.test(text));
    return uniqueGrabCadStrings(crumbs).slice(0, 5).join(" / ");
}

function cleanGrabCadHtml(html) {
    if (!html) return "";
    const template = document.createElement("template");
    template.innerHTML = String(html);
    template.content.querySelectorAll("script, style, meta, link, noscript, form, button, svg").forEach((node) => node.remove());
    template.content.querySelectorAll("*").forEach((node) => {
        Array.from(node.attributes || []).forEach((attr) => {
            if (/^on/i.test(attr.name) || attr.name === "class" || attr.name === "style" || attr.name.startsWith("data-")) {
                node.removeAttribute(attr.name);
            }
        });
    });
    return trimGrabCadShowMore(template.innerHTML.trim());
}

function trimGrabCadShowMore(html) {
    if (!html) return "";
    const template = document.createElement("template");
    template.innerHTML = html;
    Array.from(template.content.querySelectorAll("a, button, span, div")).forEach((node) => {
        if (/^\s*show\s+more\.{0,3}\s*$/i.test(node.textContent || "")) node.remove();
    });
    let cleaned = template.innerHTML
        .replace(/\s*(?:<br\s*\/?>\s*)*(?:show\s+more\.{0,3})\s*$/i, "")
        .trim();
    return cleaned;
}

function plainTextToGrabCadHtml(text) {
    const clean = cleanGrabCadText(text);
    return clean ? `<p>${escapeGrabCadHtml(clean)}</p>` : "";
}

function firstGrabCadText(htmlOrText) {
    const template = document.createElement("template");
    template.innerHTML = htmlOrText || "";
    const text = cleanGrabCadText(template.content.textContent || htmlOrText || "");
    return text.length <= 280 ? text : `${text.slice(0, 277).trim()}...`;
}

function normalizeGrabCadPageUrl(raw) {
    try {
        const url = new URL(raw, window.location.origin);
        url.hash = "";
        return url.toString().replace(/\/$/, "");
    } catch (_) {
        return String(raw || "").split("#")[0].replace(/\/$/, "");
    }
}

function extractGrabCadModelId(pageUrl) {
    try {
        const last = new URL(pageUrl).pathname.split("/").filter(Boolean).pop() || "";
        return last.match(/-(\d+)$/)?.[1] || last;
    } catch (_) {
        return "";
    }
}

function normalizeGrabCadUrl(raw) {
    if (!raw) return "";
    try {
        return new URL(raw, window.location.origin).toString();
    } catch (_) {
        return "";
    }
}

function normalizeGrabCadDate(value) {
    if (!value) return "";
    const parsed = new Date(value);
    return Number.isNaN(parsed.getTime()) ? "" : parsed.toISOString();
}

function cleanGrabCadText(value) {
    return String(value || "").replace(/\u00a0/g, " ").replace(/\s+/g, " ").trim();
}

function cleanGrabCadTitle(value) {
    return cleanGrabCadText(value)
        .replace(/\.(?:zip|step|stp|stl|sldprt|sldasm|f3d|iges|igs|obj|3mf|dwg|dxf|pdf)$/i, "")
        .trim();
}

function uniqueGrabCadStrings(values) {
    const seen = new Set();
    return values.filter((value) => {
        const clean = String(value || "").trim();
        const key = clean.toLowerCase();
        if (!clean || seen.has(key)) return false;
        seen.add(key);
        return true;
    });
}

function escapeGrabCadHtml(value) {
    return String(value || "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;");
}
