window.MeshVaultScrape = function() {
    const pageUrl = normalizeThangsPageUrl(window.location.href);
    const nextData = readThangsNextData();
    const modelId = extractThangsModelId(pageUrl);
    const nextModel = findThangsModelObject(nextData, modelId);
    const titleAuthor = parseThangsTitle(
        getMeta("og:title")
        || getMeta("twitter:title")
        || nextModel?.name
        || document.title
        || ""
    );
    const title = cleanThangsText(nextModel?.name || titleAuthor.title);
    const author = cleanThangsText(
        nextModel?.creator?.name
        || nextModel?.designer?.username
        || nextModel?.designerName
        || titleAuthor.author
        || findThangsAuthorFromUrl(pageUrl)
    );
    const authorUrl = normalizeThangsUrl(
        nextModel?.creator?.url
        || nextModel?.designer?.url
        || (author ? `https://thangs.com/designer/${encodeURIComponent(author)}` : "")
    );
    const description = cleanThangsHtml(
        nextModel?.descriptionHtml
        || nextModel?.description
        || findThangsDescriptionHtml()
        || plainTextToThangsHtml(getMeta("description") || getMeta("og:description") || "")
    );
    const images = collectThangsImages(nextData, nextModel);
    const thumbnailUrl = images[0] || normalizeThangsImage(getMeta("og:image") || getMeta("twitter:image") || "");
    const tags = collectThangsTags(nextModel);

    return {
        sourceUrl: pageUrl,
        title,
        author,
        authorUrl,
        summary: firstThangsText(description || getMeta("description") || ""),
        description,
        tags,
        thumbnailUrl,
        images,
        publishedAtUtc: normalizeThangsDate(nextModel?.createdAt || nextModel?.publishedAt || nextModel?.created),
        modifiedAtUtc: normalizeThangsDate(nextModel?.updatedAt || nextModel?.modifiedAt || nextModel?.modified),
        sourceMetadataMethod: nextModel ? "thangs-next-data" : "thangs-dom",
        thangs: {
            downloads: asThangsNumber(nextModel?.downloadCount || nextModel?.downloads),
            likes: asThangsNumber(nextModel?.likeCount || nextModel?.likes)
        }
    };
};

function getMeta(name) {
    return document.querySelector(`meta[property="${name}"]`)?.content
        || document.querySelector(`meta[name="${name}"]`)?.content
        || "";
}

function readThangsNextData() {
    try {
        if (window.__NEXT_DATA__) return window.__NEXT_DATA__;
        const script = document.getElementById("__NEXT_DATA__");
        return script?.textContent ? JSON.parse(script.textContent) : null;
    } catch (_) {
        return null;
    }
}

function findThangsModelObject(root, modelId) {
    const seen = new Set();
    const stack = [root];
    let best = null;
    while (stack.length) {
        const current = stack.pop();
        if (!current || typeof current !== "object" || seen.has(current)) continue;
        seen.add(current);

        const id = String(current.id || current.modelId || current.contentId || current.thingId || "");
        const name = current.name || current.title;
        const description = current.description || current.descriptionHtml;
        if (name && (description || id === modelId)) {
            if (!best || id === modelId || String(current.slug || "").includes(modelId)) best = current;
        }

        if (Array.isArray(current)) {
            current.forEach((item) => stack.push(item));
        } else {
            Object.values(current).forEach((value) => {
                if (value && typeof value === "object") stack.push(value);
            });
        }
    }
    return best;
}

function parseThangsTitle(rawTitle) {
    let base = cleanThangsText(rawTitle);
    if (base.includes(" on Thangs")) base = base.split(" on Thangs")[0].trim();
    const marker = " - 3D model by ";
    if (!base.includes(marker)) return { title: base, author: "" };
    const parts = base.split(marker);
    return {
        title: cleanThangsText(parts[0] || ""),
        author: cleanThangsText(parts.slice(1).join(marker) || "")
    };
}

function findThangsAuthorFromUrl(pageUrl) {
    try {
        const parts = new URL(pageUrl).pathname.split("/").filter(Boolean);
        const designerIndex = parts.findIndex((part) => part.toLowerCase() === "designer");
        return designerIndex >= 0 ? decodeURIComponent(parts[designerIndex + 1] || "") : "";
    } catch (_) {
        return "";
    }
}

function findThangsDescriptionHtml() {
    const labels = Array.from(document.querySelectorAll("h2, h3, button, a, div, span"))
        .filter((node) => cleanThangsText(node.textContent).toLowerCase() === "description");
    for (const label of labels) {
        const container = label.closest("section, article, [class*='description' i], [class*='detail' i]") || label.parentElement;
        if (!container) continue;
        const clone = container.cloneNode(true);
        clone.querySelectorAll("script, style, button, svg").forEach((node) => node.remove());
        const text = cleanThangsText(clone.textContent || "");
        if (text.length > "Description".length + 25) return clone.innerHTML;
    }
    return "";
}

function collectThangsImages(nextData, model) {
    const urls = [];
    const add = (value) => {
        const image = normalizeThangsImage(value);
        if (image && !isThangsPromoImage(image)) urls.push(image);
    };

    add(model?.image);
    add(model?.thumbnail);
    add(model?.thumbnailUrl);
    add(model?.coverImage);
    add(model?.coverImageUrl);
    add(getMeta("og:image"));
    add(getMeta("twitter:image"));

    findThangsModelImageElements().forEach((img) => {
        if (isThangsNonModelImageElement(img)) return;
        bestThangsSrcsetUrl(img.getAttribute("srcset")).forEach(add);
        add(img.currentSrc || img.src || img.getAttribute("src") || img.getAttribute("data-src") || "");
    });

    return uniqueThangsStrings(urls).slice(0, 8);
}

function findThangsModelImageElements() {
    const scope = document.querySelector("#model-viewer")
        || document.querySelector("[class*='Model_ModelViewer']");
    if (!scope) return [];
    return Array.from(scope.querySelectorAll("img"));
}

function collectThangsTags(model) {
    const tags = new Set();
    const add = (value) => {
        const tag = cleanThangsText(typeof value === "string" ? value : value?.name || value?.tag || value?.label || "");
        if (tag && tag.length < 64) tags.add(tag.replace(/^#/, ""));
    };
    [model?.tags, model?.keywords].flat().filter(Boolean).forEach(add);
    document.querySelectorAll("a[href*='tag'], a[href*='search'], a[href*='categories']").forEach((node) => {
        const text = cleanThangsText(node.textContent || "");
        if (text && text.length < 64 && !/explore|marketplace|categories/i.test(text)) add(text);
    });
    return Array.from(tags);
}

function collectThangsCategory(model) {
    const categories = [];
    const add = (value) => {
        const text = cleanThangsText(typeof value === "string" ? value : value?.name || value?.title || "");
        if (text && text.length < 80) categories.push(text);
    };
    [model?.category, model?.categories].flat().filter(Boolean).forEach(add);
    document.querySelectorAll("a[href*='category'], a[href*='categories']").forEach((node) => add(node.textContent || ""));
    return uniqueThangsStrings(categories).slice(0, 4).join(" / ");
}

function collectThangsLicense(model) {
    return cleanThangsText(model?.license?.name || model?.license || model?.licenseType || "");
}

function normalizeThangsImage(raw) {
    if (!raw || typeof raw !== "string") return "";
    let value = raw.replace(/&amp;/g, "&").trim();
    try {
        const parsed = new URL(value, window.location.origin);
        if (parsed.pathname.includes("/_next/image")) {
            const inner = parsed.searchParams.get("url");
            if (inner) value = decodeURIComponent(inner);
        }
    } catch (_) {
        return "";
    }
    return normalizeThangsYouTubeThumb(value);
}

function normalizeThangsYouTubeThumb(raw) {
    try {
        const parsed = new URL(raw, window.location.origin);
        const host = parsed.hostname.toLowerCase();
        const path = parsed.pathname;
        if (host.includes("i.ytimg.com")) {
            const match = path.match(/\/vi_webp\/([^/]+)/i) || path.match(/\/vi\/([^/]+)/i);
            return match?.[1] ? `https://i.ytimg.com/vi/${match[1]}/hqdefault.jpg` : parsed.toString();
        }
        if (host.includes("youtu.be")) {
            const id = path.replace(/^\//, "").split("/")[0];
            return id ? `https://i.ytimg.com/vi/${id}/hqdefault.jpg` : "";
        }
        if (host.includes("youtube.com")) {
            const id = parsed.searchParams.get("v")
                || path.split("/shorts/")[1]?.split(/[?&#/]/)[0]
                || path.split("/embed/")[1]?.split(/[?&#/]/)[0]
                || "";
            return id ? `https://i.ytimg.com/vi/${id}/hqdefault.jpg` : "";
        }
        return parsed.toString();
    } catch (_) {
        return "";
    }
}

function isThangsImageUrl(value) {
    return /\.(?:png|jpe?g|webp)(?:[?#]|$)/i.test(normalizeThangsImage(value));
}

function isThangsPromoImage(value) {
    const lower = String(value || "").toLowerCase();
    return lower.includes("promo")
        || lower.includes("coupon")
        || lower.includes("discount")
        || lower.includes("use%20code")
        || lower.includes("use code")
        || lower.includes("avatar")
        || lower.includes("profile")
        || lower.includes("user-profile")
        || lower.includes("users/")
        || lower.includes("user_")
        || lower.includes("author")
        || lower.includes("designer");
}

function isThangsNonModelImageElement(img) {
    if (!img) return true;
    const alt = cleanThangsText(img.getAttribute("alt") || "").toLowerCase();
    const aria = cleanThangsText(img.getAttribute("aria-label") || "").toLowerCase();
    if (alt.includes("avatar") || alt.includes("profile") || aria.includes("avatar") || aria.includes("profile")) return true;

    const nonModelContainer = img.closest?.([
        "header",
        "nav",
        "footer",
        "[class*='avatar' i]",
        "[class*='profile' i]",
        "[class*='author' i]",
        "[class*='designer' i]",
        "[class*='user' i]",
        "[class*='creator' i]",
        "[data-testid*='avatar' i]",
        "[data-testid*='profile' i]"
    ].join(","));
    return Boolean(nonModelContainer);
}

function bestThangsSrcsetUrl(srcset) {
    if (!srcset) return [];
    return srcset.split(",")
        .map((entry) => {
            const [url, descriptor] = entry.trim().split(/\s+/);
            const width = descriptor?.endsWith("w") ? parseInt(descriptor, 10) || 0 : 0;
            return { url, width };
        })
        .sort((left, right) => right.width - left.width)
        .map((entry) => entry.url)
        .filter(Boolean);
}

function cleanThangsHtml(html) {
    if (!html) return "";
    const template = document.createElement("template");
    template.innerHTML = String(html);
    template.content.querySelectorAll("script, style, meta, link, noscript, form, button, svg").forEach((node) => node.remove());
    template.content.querySelectorAll("*").forEach((node) => {
        Array.from(node.attributes || []).forEach((attr) => {
            if (/^on/i.test(attr.name) || attr.name === "class" || attr.name === "style" || attr.name.startsWith("data-")) {
                node.removeAttribute(attr.name);
            }
        });
    });
    return template.innerHTML.trim();
}

function plainTextToThangsHtml(text) {
    const clean = cleanThangsText(text);
    if (!clean) return "";
    return clean.split(/\n{2,}/).map((part) => `<p>${escapeThangsHtml(part)}</p>`).join("");
}

function firstThangsText(htmlOrText) {
    const template = document.createElement("template");
    template.innerHTML = htmlOrText || "";
    const text = cleanThangsText(template.content.textContent || htmlOrText || "");
    if (text.length <= 280) return text;
    return `${text.slice(0, 277).trim()}...`;
}

function normalizeThangsPageUrl(raw) {
    try {
        const url = new URL(raw, window.location.origin);
        url.hash = "";
        return url.toString();
    } catch (_) {
        return String(raw || "").split("#")[0];
    }
}

function extractThangsModelId(pageUrl) {
    try {
        const last = new URL(pageUrl).pathname.split("/").filter(Boolean).pop() || "";
        return last.match(/-(\d+)$/)?.[1] || "";
    } catch (_) {
        return "";
    }
}

function normalizeThangsUrl(raw) {
    if (!raw) return "";
    try {
        return new URL(raw, window.location.origin).toString();
    } catch (_) {
        return "";
    }
}

function normalizeThangsDate(value) {
    if (!value) return "";
    const parsed = new Date(value);
    return Number.isNaN(parsed.getTime()) ? "" : parsed.toISOString();
}

function asThangsNumber(value) {
    const number = Number(value);
    return Number.isFinite(number) ? number : null;
}

function cleanThangsText(value) {
    return String(value || "").replace(/\u00a0/g, " ").replace(/\s+/g, " ").trim();
}

function uniqueThangsStrings(values) {
    const seen = new Set();
    return values.filter((value) => {
        const clean = String(value || "").trim();
        const key = clean.toLowerCase();
        if (!clean || seen.has(key)) return false;
        seen.add(key);
        return true;
    });
}

function escapeThangsHtml(value) {
    return String(value || "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;");
}
