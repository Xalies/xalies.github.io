window.MeshVaultScrape = function() {
    const pageUrl = window.location.href.split("#")[0].replace(/\/$/, "");
    const design = findMakerWorldDesignPayload(document, pageUrl);
    if (design) {
        return buildMakerWorldMetadata(design, pageUrl);
    }

    return "";
};

function findMakerWorldDesignPayload(root, pageUrl = "") {
    const nextData = root.querySelector("script#__NEXT_DATA__");
    if (!nextData?.textContent) {
        return null;
    }

    try {
        const data = JSON.parse(nextData.textContent);
        const design = data?.props?.pageProps?.design;
        if (!design?.id || !design?.title) return null;
        return makerWorldDesignMatchesPageUrl(design, pageUrl) ? design : null;
    } catch (_) {
        return null;
    }
}

function makerWorldDesignMatchesPageUrl(design, pageUrl) {
    const pageModelId = extractMakerWorldModelIdFromUrl(pageUrl);
    if (!pageModelId) return true;
    const designIds = [
        design.modelId,
        design.id,
        design.designId
    ].map((value) => String(value || "").trim()).filter(Boolean);
    return designIds.includes(pageModelId);
}

function extractMakerWorldModelIdFromUrl(pageUrl) {
    try {
        const path = new URL(pageUrl || "").pathname;
        return path.match(/\/models\/(\d+)/i)?.[1] || "";
    } catch (_) {
        return String(pageUrl || "").match(/\/models\/(\d+)/i)?.[1] || "";
    }
}

function buildMakerWorldMetadata(design, pageUrl) {
    const creator = design.designCreator || {};
    const authorHandle = creator.handle || "";
    const descriptionHtml = cleanMakerWorldDescription(
        design.summaryTranslated || design.summary || ""
    );
    const images = collectMakerWorldImages(design);
    const thumbnailUrl = design.coverUrl || images[0] || document.querySelector('meta[property="og:image"]')?.content || "";
    const tags = Array.isArray(design.tagsOriginal) && design.tagsOriginal.length > 0
        ? design.tagsOriginal.map(getMakerWorldTagName).filter(Boolean)
        : Array.isArray(design.tags)
            ? design.tags.map(getMakerWorldTagName).filter(Boolean)
            : [];

    return {
        sourceUrl: pageUrl,
        title: design.titleTranslated || design.title || document.querySelector('h1.title-for-share')?.textContent?.trim() || "",
        author: creator.name || "",
        authorUrl: authorHandle ? `https://makerworld.com/en/@${authorHandle}` : "",
        summary: makeMakerWorldSummary(descriptionHtml, design.title || ""),
        description: descriptionHtml,
        tags: uniqueStrings(tags),
        thumbnailUrl,
        images,
        publishedAtUtc: design.createTime || "",
        modifiedAtUtc: design.updateTime || "",
        sourceMetadataMethod: "makerworld-next-data",
        stats: {
            likes: asNumberOrNull(design.likeCount),
            downloads: asNumberOrNull(design.downloadCount),
            rawModelDownloads: asNumberOrNull(design.rawModelFileDownloadCount),
            prints: asNumberOrNull(design.printCount),
            comments: asNumberOrNull(design.commentCount),
            collections: asNumberOrNull(design.collectionCount)
        },
        makerWorld: {
            modelId: design.modelId || "",
            defaultProfileId: design.defaultInstanceId || "",
            printProfiles: Array.isArray(design.instances)
                ? design.instances.map(toMakerWorldProfileSummary).filter(Boolean)
                : [],
            modelFiles: design.designExtension?.model_files?.map(toMakerWorldFileSummary).filter(Boolean) || []
        }
    };
}

function cleanMakerWorldDescription(html) {
    if (!html) {
        return "";
    }

    const template = document.createElement("template");
    template.innerHTML = html;
    template.content.querySelectorAll(".commercialroot, .boostmeroot, script, style").forEach((node) => node.remove());
    template.content.querySelectorAll("p").forEach((node) => {
        const text = (node.textContent || "").trim().toLowerCase();
        if (text === "commercial licensing available") {
            node.remove();
        }
    });

    return template.innerHTML.trim();
}

function collectMakerWorldImages(design) {
    const urls = [];
    const add = (url) => {
        if (!url || typeof url !== "string") return;
        const clean = url.replace(/&amp;/g, "&").trim();
        if (!/^https?:\/\//i.test(clean)) return;
        urls.push(clean);
    };

    add(design.coverUrl);
    add(design.coverPortrait);
    add(design.coverLandscape);

    const pictures = design.designExtension?.design_pictures;
    if (Array.isArray(pictures)) {
        pictures.forEach((picture) => add(picture?.url || picture?.imageUrl || picture?.cover));
    }

    if (Array.isArray(design.instances)) {
        design.instances.forEach((profile) => {
            add(profile?.cover);
            if (Array.isArray(profile?.pictures)) {
                profile.pictures.forEach((picture) => add(picture?.url || picture?.imageUrl || picture?.cover));
            }
        });
    }

    return uniqueStrings(urls).slice(0, 12);
}

function makeMakerWorldSummary(descriptionHtml, fallbackTitle) {
    const template = document.createElement("template");
    template.innerHTML = descriptionHtml || "";
    const paragraph = Array.from(template.content.querySelectorAll("p, li"))
        .map((node) => normalizeWhitespace(node.textContent || ""))
        .find(Boolean);
    if (paragraph) {
        return paragraph;
    }

    return fallbackTitle || "";
}

function getMakerWorldTagName(tag) {
    if (!tag) return "";
    if (typeof tag === "string") return tag.trim();
    return (tag.name || tag.tagName || tag.displayName || tag.value || tag.label || "").trim();
}

function toMakerWorldProfileSummary(profile) {
    if (!profile) return null;
    const compatibility = profile.extention?.modelInfo?.compatibility || {};
    return {
        profileId: profile.profileId || "",
        title: profile.title || "",
        cover: profile.cover || "",
        printer: compatibility.devProductName || "",
        nozzleDiameter: compatibility.nozzleDiameter ?? null,
        weightGrams: profile.weight ?? null,
        needsAms: Boolean(profile.needAms),
        downloadCount: asNumberOrNull(profile.downloadCount),
        printCount: asNumberOrNull(profile.printCount)
    };
}

function toMakerWorldFileSummary(file) {
    if (!file) return null;
    return {
        name: file.modelName || file.modelFileName || "",
        type: file.modelType || "",
        sizeBytes: asNumberOrNull(file.modelSize),
        updatedAtUtc: file.modelUpdateTime || "",
        thumbnailUrl: file.thumbnailUrl || ""
    };
}

function uniqueStrings(values) {
    const seen = new Set();
    return values
        .map((value) => String(value || "").trim())
        .filter((value) => {
            if (!value) return false;
            const key = value.toLowerCase();
            if (seen.has(key)) return false;
            seen.add(key);
            return true;
        });
}

function normalizeWhitespace(value) {
    return String(value || "")
        .replace(/\u00a0/g, " ")
        .replace(/\uFFFD/g, "")
        .replace(/\s+/g, " ")
        .trim();
}

function asNumberOrNull(value) {
    const number = Number(value);
    return Number.isFinite(number) ? number : null;
}
