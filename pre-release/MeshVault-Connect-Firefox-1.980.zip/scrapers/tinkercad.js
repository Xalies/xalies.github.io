window.MeshVaultScrape = function() {
    const pageUrl = normalizeTinkercadPageUrl(window.location.href);
    const metaDescription = cleanTinkercadText(getMeta("description") || getMeta("og:description") || "");
    const parsedMeta = parseTinkercadMetaDescription(metaDescription);
    const title = chooseTinkercadTitle(
        parsedMeta.title
        || getMeta("og:title")
        || getMeta("twitter:title")
        || document.querySelector("[data-testid*='title' i]")?.textContent
        || document.querySelector("h1")?.textContent
        || document.title
        || ""
    );
    const author = parsedMeta.author || findTinkercadAuthor();
    const descriptionText = findTinkercadDescriptionText() || (isTinkercadBoilerplateDescription(metaDescription) ? "" : metaDescription);
    const images = collectTinkercadImages();
    const thumbnailUrl = images[0] || "";

    return {
        sourceSite: "Tinkercad",
        sourceUrl: pageUrl,
        title,
        author,
        authorUrl: "",
        summary: descriptionText,
        description: descriptionText ? plainTextToTinkercadHtml(descriptionText) : "",
        tags: ["Tinkercad"],
        license: "",
        category: "",
        thumbnailUrl,
        images,
        sourceMetadataMethod: "tinkercad-dom"
    };
};

function getMeta(name) {
    return document.querySelector(`meta[property="${name}"]`)?.content
        || document.querySelector(`meta[name="${name}"]`)?.content
        || "";
}

function normalizeTinkercadPageUrl(value) {
    try {
        const url = new URL(value || window.location.href, window.location.href);
        url.hash = "";
        url.search = "";
        const thingPath = url.pathname.match(/\/things\/[^/]+/i)?.[0] || "";
        url.pathname = thingPath || url.pathname.replace(/\/edit\/?$/i, "").replace(/\/$/, "");
        return url.toString();
    } catch (_) {
        return value || window.location.href;
    }
}

function chooseTinkercadTitle(value) {
    const clean = cleanTinkercadTitle(value);
    return isGenericTinkercadTitle(clean) ? titleFromTinkercadUrl(window.location.href) : clean;
}

function cleanTinkercadTitle(value) {
    return cleanTinkercadText(value)
        .replace(/^3D design\s+/i, "")
        .replace(/\s*\|\s*Tinkercad\s*$/i, "")
        .replace(/\s*-\s*Tinkercad\s*$/i, "");
}

function isGenericTinkercadTitle(value) {
    const clean = cleanTinkercadText(value).toLowerCase();
    return !clean || clean === "tinkercad" || clean === "login";
}

function titleFromTinkercadUrl(value) {
    try {
        const path = new URL(value || window.location.href, window.location.href).pathname;
        const slug = path.match(/\/things\/[^/]+-([^/?#]+)/i)?.[1] || "";
        return slug
            .split("-")
            .filter(Boolean)
            .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
            .join(" ");
    } catch (_) {
        return "";
    }
}

function cleanTinkercadText(value) {
    return String(value || "")
        .replace(/\s+/g, " ")
        .trim();
}

function findTinkercadAuthor() {
    const explicitUsername = cleanTinkercadText(
        document.querySelector("#design-detail-username")?.getAttribute("title")
        || document.querySelector("#design-detail-username")?.textContent
        || ""
    );
    if (explicitUsername && !/tinkercad/i.test(explicitUsername)) return explicitUsername;

    const candidates = [
        ".user-lockup-username a[title]",
        ".user-lockup-username a",
        "[data-testid*='author' i]",
        "[class*='author' i]",
        "[class*='owner' i]",
        "a[href*='/users/']"
    ];
    for (const selector of candidates) {
        const node = document.querySelector(selector);
        const text = cleanTinkercadText(node?.getAttribute?.("title") || node?.textContent || "");
        if (text && !/tinkercad/i.test(text)) return text;
    }
    return "";
}

function findTinkercadDescriptionText() {
    const selectors = [
        ".truncated-text-container markdown",
        "[class*='truncated-text-container' i] markdown",
        "markdown",
        "[data-testid*='description' i]",
        "[data-test*='description' i]",
        "[class*='description' i]",
        "[class*='details' i]",
        "[class*='summary' i]",
        "[class*='notes' i]",
        "[class*='instructions' i]"
    ];
    const candidates = [];
    for (const selector of selectors) {
        document.querySelectorAll(selector).forEach((node) => {
            const text = cleanTinkercadDescriptionCandidate(node?.textContent || "");
            if (text && isUsefulTinkercadDescription(text)) candidates.push({ text, score: scoreTinkercadDescription(node, text) });
        });
    }
    return candidates
        .sort((left, right) => right.score - left.score || left.text.length - right.text.length)
        .map((candidate) => candidate.text)[0] || "";
}

function cleanTinkercadDescriptionCandidate(value) {
    return cleanTinkercadText(value)
        .replace(/^description\s*/i, "")
        .replace(/^about\s+this\s+(design|thing)\s*/i, "")
        .trim();
}

function isUsefulTinkercadDescription(text) {
    if (!text || text.length < 12) return false;
    if (isTinkercadBoilerplateDescription(text)) return false;
    if (/^(copy and tinker|download|share|like|comment|view in 3d|sign in|join|report abuse)\b/i.test(text)) return false;
    return /[.!?]$/.test(text) || text.length > 40;
}

function scoreTinkercadDescription(node, text) {
    const signature = [
        node?.tagName || "",
        node?.className || "",
        node?.id || "",
        node?.getAttribute?.("data-testid") || "",
        node?.getAttribute?.("data-test") || "",
        node?.parentElement?.className || "",
        node?.parentElement?.id || ""
    ].join(" ").toLowerCase();
    let score = Math.min(text.length, 240);
    if (node?.tagName?.toLowerCase() === "markdown") score += 180;
    if (signature.includes("truncated-text-container")) score += 220;
    if (signature.includes("description")) score += 140;
    if (signature.includes("summary")) score += 80;
    if (signature.includes("notes") || signature.includes("instruction")) score += 40;
    if (/tinkercad|autodesk|sign in|download|share|copy and tinker/i.test(text)) score -= 120;
    return score;
}

function parseTinkercadMetaDescription(value) {
    const text = cleanTinkercadText(value);
    const match = text.match(/^3D design\s+(.+?)\s+created by\s+(.+?)\s+with Tinkercad\.?$/i);
    return {
        title: match ? match[1].trim() : "",
        author: match ? match[2].trim() : ""
    };
}

function isTinkercadBoilerplateDescription(value) {
    return /^3D design\s+.+?\s+created by\s+.+?\s+with Tinkercad\.?$/i.test(cleanTinkercadText(value));
}

function collectTinkercadImages() {
    const urls = [];
    const add = (value, element = null) => {
        const image = normalizeTinkercadImage(value);
        if (!image || isBadTinkercadImage(image, element)) return;
        urls.push(image);
    };

    add(getMeta("og:image"));
    add(getMeta("twitter:image"));

    const scopes = [
        document.querySelector("main"),
        document.querySelector("[class*='thing' i]"),
        document.querySelector("[class*='gallery' i]"),
        document.body
    ].filter((scope, index, all) => scope && all.indexOf(scope) === index);

    scopes.forEach((scope) => {
        scope.querySelectorAll("img, source").forEach((node) => {
            bestTinkercadSrcsetUrls(node.getAttribute("srcset")).forEach((url) => add(url, node));
            [
                node.currentSrc,
                node.src,
                node.getAttribute("src"),
                node.getAttribute("ng-src"),
                node.getAttribute("data-src"),
                node.getAttribute("data-image"),
                node.getAttribute("data-url"),
                node.getAttribute("data-background-image"),
                node.getAttribute("data-original"),
                node.getAttribute("data-lazy-src")
            ].forEach((url) => add(url, node));
        });

        scope.querySelectorAll("[style], [ng-style], [data-src], [data-image], [data-url], [data-background-image]").forEach((node) => {
            [
                node.getAttribute("style"),
                node.getAttribute("ng-style"),
                node.getAttribute("data-src"),
                node.getAttribute("data-image"),
                node.getAttribute("data-url"),
                node.getAttribute("data-background-image"),
                node.getAttribute("data-original"),
                node.getAttribute("data-lazy-src")
            ].forEach((value) => extractTinkercadUrlsFromText(value || "").forEach((url) => add(url, node)));
        });
    });

    Array.from(document.scripts).forEach((script) => {
        extractTinkercadUrlsFromText(script.textContent || "").forEach(add);
    });

    extractTinkercadUrlsFromText(document.documentElement?.innerHTML || "").forEach(add);

    return uniqueTinkercadImages(urls)
        .sort((left, right) => scoreTinkercadImage(right) - scoreTinkercadImage(left))
        .slice(0, 16);
}

function bestTinkercadSrcsetUrls(srcset) {
    return String(srcset || "")
        .split(",")
        .map((part) => part.trim().split(/\s+/)[0])
        .filter(Boolean);
}

function extractTinkercadUrlsFromText(value) {
    const text = String(value || "").replace(/\\\//g, "/").replace(/&amp;/g, "&");
    const urls = [];
    const patterns = [
        /url\((['"]?)(.*?)\1\)/gi,
        /https?:\/\/[^"'()<>\s\\]+/gi,
        /(?:src|image|thumbnail|cover|url|backgroundImage|background-image)["']?\s*[:=]\s*["']([^"']+)["']/gi
    ];
    patterns.forEach((pattern) => {
        let match;
        while ((match = pattern.exec(text))) {
            urls.push(match[2] || match[1] || match[0]);
        }
    });
    return urls;
}

function normalizeTinkercadImage(value) {
    if (!value) return "";
    try {
        const url = new URL(String(value).replace(/&amp;/g, "&"), window.location.href);
        if (!/^https?:$/i.test(url.protocol)) return "";
        if (/\.(?:png|jpe?g|webp)(?:$|[?#])/i.test(url.toString())) return url.toString();
        if (url.hostname.toLowerCase().includes("tinkercad.com")) return url.toString();
        if (url.hostname.toLowerCase().includes("autodesk.com") && /(?:image|thumbnail|render|preview|thing|asset)/i.test(url.toString())) return url.toString();
        return "";
    } catch (_) {
        return "";
    }
}

function isBadTinkercadImage(url, element) {
    const lower = String(url || "").toLowerCase();
    if (!lower || lower.includes("avatar") || lower.includes("logo") || lower.includes("icon")) return true;
    if (lower.includes("sprite") || lower.includes("favicon") || lower.includes("placeholder")) return true;
    if (element?.closest?.("header, nav, footer, [class*='avatar' i], [class*='profile' i], [class*='user' i]")) return true;
    return false;
}

function uniqueTinkercadImages(values) {
    const seen = new Set();
    return values.filter((value) => {
        const key = String(value || "").replace(/([?&])(?:width|height|w|h)=\d+/gi, "").toLowerCase();
        if (!key || seen.has(key)) return false;
        seen.add(key);
        return true;
    });
}

function scoreTinkercadImage(value) {
    const lower = String(value || "").toLowerCase();
    let score = 0;
    if (lower.includes("tinkercad.com")) score += 30;
    if (lower.includes("/things/")) score += 30;
    if (lower.includes("thumbnail") || lower.includes("preview") || lower.includes("render")) score += 20;
    if (/\.(png|jpe?g|webp)(?:$|[?#])/i.test(lower)) score += 10;
    if (lower.includes("avatar") || lower.includes("logo") || lower.includes("icon")) score -= 100;
    return score;
}

function plainTextToTinkercadHtml(text) {
    const escaped = String(text || "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;");
    return escaped ? `<p>${escaped.replace(/\n{2,}/g, "</p><p>").replace(/\n/g, "<br>")}</p>` : "";
}
