window.MeshVaultScrape = function() {
    const STORAGE_KEY = "meshvault_cults3d_meta";

    const isModelPage = () => {
        const url = window.location.href;
        return url.includes("/3d-model/") && !url.includes("/downloads/") && !url.includes("/orders/");
    };

    const normalizeModelUrl = (raw) => {
        if (!raw) return "";
        try {
            const url = new URL(raw, window.location.origin);
            url.hash = "";
            if (!url.pathname.includes("/3d-model/")) return "";
            url.pathname = url.pathname.replace(/\/downloads?\/?$/, "");
            return url.toString().replace(/\/$/, "");
        } catch (_) {
            return "";
        }
    };

    const readMetadataFromDoc = (doc, pageUrlFallback) => {
        const pageUrl = normalizeModelUrl(pageUrlFallback || window.location.href)
            || normalizeModelUrl(doc.querySelector("link[rel='canonical']")?.href)
            || String(pageUrlFallback || window.location.href).split("#")[0].replace(/\/$/, "");
        const mediaObject = findCultsMediaObject(doc);
        const title = cleanTitle(
            getMeta(doc, "og:title")
            || mediaObject?.name
            || doc.querySelector("h1")?.textContent
            || doc.title
            || ""
        );
        const author = findCultsAuthor(doc, mediaObject);
        const modelDescription = cleanCultsHtml(sectionAfterHeading(doc, "3D model description"))
            || plainTextToHtml(mediaObject?.description || getMeta(doc, "og:description") || getMeta(doc, "description") || "");
        const printSettings = cleanCultsHtml(sectionAfterHeading(doc, "3D printing settings"));
        const description = joinCultsDescription(modelDescription, printSettings);
        const images = collectCultsImages(doc, mediaObject, title);
        const thumbnailUrl = images[0] || normalizeCultsImageUrl(mediaObject?.image || getMeta(doc, "og:image") || "");
        const tags = collectCultsTags(doc);
        const files = collectCultsFiles(doc);
        const designNumber = extractDesignNumber(doc, mediaObject);

        return {
            sourceUrl: pageUrl,
            title,
            author: author.name,
            authorUrl: author.url,
            summary: firstUsefulText(modelDescription || mediaObject?.description || ""),
            description,
            printSettingsJson: "",
            tags,
            thumbnailUrl,
            images,
            publishedAtUtc: normalizeCultsDate(mediaObject?.datePublished),
            sourceMetadataMethod: mediaObject ? "cults3d-mediaobject-dom" : "cults3d-dom",
            cults: {
                designNumber,
                isFree: isCultsFree(doc, mediaObject),
                format: mediaObject?.encodingFormat || extractFormatText(doc),
                files
            }
        };
    };

    const currentModelUrl = normalizeModelUrl(window.location.href) || normalizeModelUrl(document.referrer);

    try {
        let result = "";
        const cached = sessionStorage.getItem(STORAGE_KEY) || "";
        if (cached) {
            const cachedMeta = parseCachedCultsMeta(cached);
            const cachedPage = cachedMeta?.sourceUrl || "";
            if (currentModelUrl && cachedPage && cachedPage !== currentModelUrl) {
                sessionStorage.removeItem(STORAGE_KEY);
            }
        }

        if (isModelPage()) {
            const current = readMetadataFromDoc(document, window.location.href);
            if (current?.sourceUrl) {
                sessionStorage.setItem(STORAGE_KEY, JSON.stringify(current));
                result = current;
            }
        }

        const postCache = sessionStorage.getItem(STORAGE_KEY) || "";
        if (!postCache && currentModelUrl && !isModelPage()) {
            try {
                const xhr = new XMLHttpRequest();
                xhr.open("GET", currentModelUrl, false);
                xhr.send(null);
                if (xhr.status >= 200 && xhr.status < 300 && xhr.responseText) {
                    const doc = new DOMParser().parseFromString(xhr.responseText, "text/html");
                    const fetched = readMetadataFromDoc(doc, currentModelUrl);
                    if (fetched?.sourceUrl) {
                        sessionStorage.setItem(STORAGE_KEY, JSON.stringify(fetched));
                    }
                }
            } catch (_) {
                // No-op
            }
        }

        const finalCache = sessionStorage.getItem(STORAGE_KEY) || "";
        if (finalCache) {
            result = parseCachedCultsMeta(finalCache) || result;
        }

        return result;
    } catch (_) {
        return "";
    }
};

function findCultsMediaObject(doc) {
    const scripts = Array.from(doc.querySelectorAll('script[type="application/ld+json"]'));
    for (const script of scripts) {
        try {
            const data = JSON.parse(script.textContent || "{}");
            const items = Array.isArray(data) ? data : [data];
            const media = items.find((item) => item?.["@type"] === "MediaObject" && item.name);
            if (media) return media;
        } catch (_) {
            // Keep looking.
        }
    }
    return null;
}

function parseCachedCultsMeta(value) {
    try {
        const parsed = JSON.parse(value);
        return parsed && typeof parsed === "object" ? parsed : null;
    } catch (_) {
        return null;
    }
}

function getMeta(doc, name) {
    return doc.querySelector(`meta[property="${name}"]`)?.content
        || doc.querySelector(`meta[name="${name}"]`)?.content
        || "";
}

function cleanTitle(value) {
    return normalizeCultsText(value)
        .replace(/^download\s+/i, "")
        .replace(/(?:・|\|).*$/g, "")
        .replace(/^[^\w]+/, "")
        .trim();
}

function findCultsAuthor(doc, mediaObject) {
    const creator = mediaObject?.creator || {};
    const profileLink = doc.querySelector("a[href^='/@'], a[href*='cults3d.com/@'], h2 a[href*='/@'], h3 a[href*='/@']");
    const name = normalizeCultsText(creator.name || profileLink?.textContent || "");
    const rawUrl = creator.url || profileLink?.getAttribute("href") || "";
    const url = rawUrl ? new URL(rawUrl, window.location.origin).toString() : "";
    return { name, url };
}

function sectionAfterHeading(doc, headingText) {
    const heading = Array.from(doc.querySelectorAll("h2, h3"))
        .find((node) => normalizeCultsText(node.textContent).toLowerCase() === headingText.toLowerCase());
    if (!heading) return "";

    const wrapper = doc.createElement("div");
    let node = heading.nextElementSibling;
    while (node && !/^H[23]$/i.test(node.tagName)) {
        if (!isCultsNoiseNode(node)) wrapper.appendChild(node.cloneNode(true));
        node = node.nextElementSibling;
    }
    return wrapper.innerHTML;
}

function isCultsNoiseNode(node) {
    const text = normalizeCultsText(node.textContent || "");
    return !text && !node.querySelector?.("img, a, iframe");
}

function cleanCultsHtml(html) {
    if (!html) return "";
    const template = document.createElement("template");
    template.innerHTML = html;
    template.content.querySelectorAll("script, style, meta, link, noscript, form, button, svg, [class*='ad'], [id*='ad']").forEach((node) => node.remove());
    template.content.querySelectorAll("*").forEach((node) => {
        Array.from(node.attributes || []).forEach((attr) => {
            if (/^on/i.test(attr.name) || attr.name.startsWith("data-") || attr.name === "class" || attr.name === "style") {
                node.removeAttribute(attr.name);
            }
        });
    });
    return template.innerHTML.trim();
}

function joinCultsDescription(modelDescription, printSettings) {
    const parts = [];
    if (modelDescription) parts.push(modelDescription);
    if (printSettings) parts.push(`<h2>3D printing settings</h2>${printSettings}`);
    return parts.join("");
}

function plainTextToHtml(text) {
    const clean = normalizeCultsText(text);
    if (!clean) return "";
    return clean.split(/\n{2,}/)
        .map((part) => `<p>${escapeHtml(part.trim())}</p>`)
        .join("");
}

function collectCultsImages(doc, mediaObject, title) {
    const urls = [];
    const add = (url, element = null) => {
        const clean = normalizeCultsImageUrl(url);
        if (!clean || isBadCultsImage(clean, element)) return;
        urls.push(clean);
    };

    add(mediaObject?.image);
    add(getMeta(doc, "og:image"));
    add(getMeta(doc, "twitter:image"));

    const titleLower = normalizeCultsText(title).toLowerCase();
    doc.querySelectorAll("img.painting-image, img[src*='fbi.cults3d.com/uploaders/'], img[data-src*='fbi.cults3d.com/uploaders/']").forEach((img) => {
        const alt = normalizeCultsText(img.getAttribute("alt") || "").toLowerCase();
        const src = img.currentSrc || img.src || img.getAttribute("data-src") || "";
        if (alt && titleLower && !alt.includes(titleLower) && !/\.(gif|jpe?g|png|webp)\b/i.test(alt)) return;
        add(src, img);
    });

    return uniqueCultsStrings(urls).slice(0, 16);
}

function normalizeCultsImageUrl(rawUrl) {
    if (!rawUrl || typeof rawUrl !== "string") return "";
    const clean = rawUrl.replace(/&amp;/g, "&").trim();
    if (!/^https?:\/\//i.test(clean)) return "";
    if (clean.startsWith("https://images.cults3d.com/") && clean.includes("/https://")) {
        return clean.substring(clean.indexOf("/https://") + 1);
    }
    if (clean.startsWith("https://videos.cults3d.com/") && clean.includes("/https://")) {
        return clean.substring(clean.indexOf("/https://") + 1);
    }
    return clean;
}

function isBadCultsImage(url, element = null) {
    const lower = String(url || "").toLowerCase();
    if (!lower || lower.includes("/uploads/user/avatar/") || lower.includes("assets.cults3d.com/assets/")) return true;
    if (lower.includes("preview3d-images.cults3d.com")) return true;
    if (element?.closest?.("[class*='author' i], [class*='avatar' i], [class*='similar' i], [class*='recommend' i], footer")) return true;
    return false;
}

function collectCultsTags(doc) {
    const tags = new Set();
    const keywords = getMeta(doc, "keywords");
    keywords.split(",").forEach((tag) => {
        const clean = normalizeCultsText(tag);
        if (clean && clean.toLowerCase() !== "cults") tags.add(clean);
    });
    doc.querySelectorAll("a[href*='/tags/'], a[href*='/search?q='], a.tag, .tag a").forEach((node) => {
        const text = normalizeCultsText(node.textContent || "").replace(/^#/, "");
        if (text && text.length < 60) tags.add(text);
    });
    return Array.from(tags);
}

function collectCultsCategory(doc) {
    const crumbs = Array.from(doc.querySelectorAll("a[href*='/categories'], a[href*='/3d-model/']"))
        .map((node) => normalizeCultsText(node.textContent || ""))
        .filter((text) => text && !/^download|cults\.?$/i.test(text));
    return uniqueCultsStrings(crumbs).slice(0, 8).join(" / ");
}

function collectCultsLicense(doc) {
    const candidates = Array.from(doc.querySelectorAll("a[href*='license'], a[href*='licenses'], a[href*='cults-pu'], a[href*='cults-pc']"))
        .map((node) => normalizeCultsText(node.textContent || ""))
        .filter(Boolean);
    return candidates[0] || "";
}

function collectCultsFiles(doc) {
    const files = [];
    const seen = new Set();
    const pattern = /([^<>\n\r]+?\.(?:stl|3mf|obj|step|stp|zip|scad|gcode|ply|dae))\s+([0-9.,]+\s*[x×]\s*[0-9.,]+\s*[x×]\s*[0-9.,]+\s*mm)?/gi;
    const text = doc.body?.textContent || "";
    let match;
    while ((match = pattern.exec(text)) !== null) {
        const name = normalizeCultsText(match[1]);
        if (!name || seen.has(name.toLowerCase())) continue;
        seen.add(name.toLowerCase());
        files.push({ name, dimensions: normalizeCultsText(match[2] || "") });
    }
    return files.slice(0, 80);
}

function extractDesignNumber(doc, mediaObject) {
    const identifier = String(mediaObject?.identifier || "");
    const fromIdentifier = identifier.match(/:(\d+)$/)?.[1] || "";
    if (fromIdentifier) return fromIdentifier;
    const text = doc.body?.textContent || "";
    return text.match(/Design number\s+(\d+)/i)?.[1] || "";
}

function extractFormatText(doc) {
    const text = normalizeCultsText(doc.body?.textContent || "");
    return text.match(/3D design format\s+[^()]*\(([^)]+)\)/i)?.[1] || "";
}

function isCultsFree(doc, mediaObject) {
    const offer = Array.isArray(mediaObject?.offers) ? mediaObject.offers[0] : mediaObject?.offers;
    if (Number(offer?.price) === 0) return true;
    return /\bDownload\s+Free\b/i.test(doc.body?.textContent || "");
}

function normalizeCultsDate(value) {
    if (!value) return "";
    const parsed = new Date(value);
    return Number.isNaN(parsed.getTime()) ? "" : parsed.toISOString();
}

function firstUsefulText(htmlOrText) {
    const template = document.createElement("template");
    template.innerHTML = htmlOrText || "";
    const text = normalizeCultsText(template.content.textContent || htmlOrText || "");
    if (text.length <= 280) return text;
    const sentenceEnd = text.search(/[.!?]\s+[A-Z0-9]/);
    if (sentenceEnd >= 80 && sentenceEnd <= 280) return text.slice(0, sentenceEnd + 1).trim();
    return `${text.slice(0, 277).trim()}...`;
}

function normalizeCultsText(value) {
    return String(value || "")
        .replace(/\u00a0/g, " ")
        .replace(/\s+/g, " ")
        .trim();
}

function uniqueCultsStrings(values) {
    const seen = new Set();
    return values
        .map((value) => String(value || "").trim())
        .filter((value) => {
            const key = value.toLowerCase();
            if (!value || seen.has(key)) return false;
            seen.add(key);
            return true;
        });
}

function escapeHtml(value) {
    return String(value || "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;");
}
