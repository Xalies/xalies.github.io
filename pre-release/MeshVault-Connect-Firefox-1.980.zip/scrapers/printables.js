window.MeshVaultScrape = function() {
    const pageUrl = window.location.href.split("#")[0].replace(/\/$/, "");
    const mediaRoot = getPrintablesPublicEnv("PUBLIC_MEDIA_ROOT_URL") || "https://media.printables.com";
    const model = findPrintablesModelPayload(document) || fetchPrintablesBaseModelPayload(pageUrl);

    if (model) {
        const authorHandle = model.user?.handle || model.user?.publicUsername || "";
        const sourceImages = Array.isArray(model.images) ? model.images : [];
        const thumbnailSource = sourceImages[0] || model.image;
        const thumbnailImageKey = getPrintablesComparableImageKey(thumbnailSource);
        const thumbnailUrl = buildPrintablesImageUrl(thumbnailSource, mediaRoot, "large")
            || buildPrintablesImageUrl(model.image, mediaRoot, "cover")
            || "";
        const images = sourceImages
            .filter((image) => getPrintablesComparableImageKey(image) !== thumbnailImageKey)
            .map((image) => buildPrintablesImageUrl(image, mediaRoot, "large"))
            .filter(Boolean);

        return {
            sourceUrl: pageUrl,
            title: model.name || document.querySelector('meta[property="og:title"]')?.content || document.title || "",
            author: model.user?.publicUsername || authorHandle,
            authorUrl: authorHandle ? `https://www.printables.com/@${authorHandle}` : "",
            summary: model.summary || "",
            description: model.description || "",
            tags: Array.isArray(model.tags) ? model.tags.map((tag) => tag?.name).filter(Boolean) : [],
            thumbnailUrl,
            images,
            publishedAtUtc: model.datePublished || model.firstPublish || "",
            modifiedAtUtc: model.modified || "",
            aiGenerated: Boolean(model.aiGenerated),
            nsfw: Boolean(model.nsfw),
            stats: {
                likes: model.likesCount ?? null,
                downloads: model.downloadCount ?? null,
                views: model.displayCount ?? null,
                files: model.filesCount ?? null,
                makes: model.makesCount ?? null
            }
        };
    }

    return scrapePrintablesFromDom(pageUrl);
};

function findPrintablesModelPayload(root) {
    const scripts = Array.from(root.querySelectorAll('script[type="application/json"][data-sveltekit-fetched]'));
    for (const script of scripts) {
        try {
            const wrapper = JSON.parse(script.textContent || "{}");
            const body = typeof wrapper.body === "string" ? JSON.parse(wrapper.body) : wrapper.body;
            const model = body?.data?.model;
            if (model?.id && model?.name) {
                return model;
            }
        } catch (_) {
            // Keep looking. Printables embeds several unrelated SvelteKit fetch payloads.
        }
    }

    return null;
}

function fetchPrintablesBaseModelPayload(pageUrl) {
    if (!/\/files\/?$/i.test(pageUrl)) return null;

    try {
        const baseUrl = pageUrl.replace(/\/files\/?$/i, "");
        const xhr = new XMLHttpRequest();
        xhr.open("GET", baseUrl, false);
        xhr.send(null);
        if (xhr.status < 200 || xhr.status >= 300 || !xhr.responseText) return null;

        const doc = new DOMParser().parseFromString(xhr.responseText, "text/html");
        return findPrintablesModelPayload(doc);
    } catch (_) {
        return null;
    }
}

function getPrintablesPublicEnv(key) {
    const scripts = Array.from(document.scripts);
    const needle = `"${key}":"`;
    for (const script of scripts) {
        const text = script.textContent || "";
        const start = text.indexOf(needle);
        if (start < 0) continue;
        const valueStart = start + needle.length;
        const valueEnd = text.indexOf('"', valueStart);
        if (valueEnd > valueStart) {
            return text.slice(valueStart, valueEnd);
        }
    }

    return "";
}

function absolutizeMediaPath(path, mediaRoot) {
    if (!path) return "";
    if (/^https?:\/\//i.test(path)) return path;
    return `${mediaRoot.replace(/\/$/, "")}/${String(path).replace(/^\//, "")}`;
}

function buildPrintablesImageUrl(image, mediaRoot, size) {
    const path = getPrintablesImagePath(image);
    if (!path) return "";
    const absolute = absolutizeMediaPath(path, mediaRoot);
    if (!absolute || absolute.includes("/thumbs/")) return absolute;

    try {
        const url = new URL(absolute);
        const parts = url.pathname.split("/");
        const file = parts.pop();
        if (!file) return absolute;
        const format = getPrintablesThumbnailFormat(file);
        const thumbnailFile = getPrintablesThumbnailFileName(file, format);
        const thumbSize = size === "cover" ? "1200x630" : "1280x960";
        url.pathname = `${parts.join("/")}/thumbs/${size === "cover" ? "cover" : "inside"}/${thumbSize}/${format}/${thumbnailFile}`;
        return url.toString();
    } catch (_) {
        return absolute;
    }
}

function getPrintablesImagePath(image) {
    if (!image) return "";
    if (typeof image === "string") return image;

    return image.filePath ||
        image.path ||
        image.url ||
        image.imageUrl ||
        image.fileUrl ||
        image.originalUrl ||
        image.original ||
        image.file?.filePath ||
        image.file?.path ||
        image.file?.url ||
        image.file?.downloadUrl ||
        image.image?.filePath ||
        image.image?.path ||
        image.image?.url ||
        "";
}

function getPrintablesComparableImageKey(image) {
    const path = getPrintablesImagePath(image);
    if (!path) return "";
    try {
        const url = new URL(path, "https://media.printables.com");
        return url.pathname
            .replace(/\/thumbs\/(?:cover|inside)\/[^/]+\/[^/]+\//i, "/")
            .replace(/\.[^.\/]+$/i, "")
            .toLowerCase();
    } catch (_) {
        return String(path)
            .replace(/\/thumbs\/(?:cover|inside)\/[^/]+\/[^/]+\//i, "/")
            .replace(/\.[^.\/?#]+(?:[?#].*)?$/i, "")
            .toLowerCase();
    }
}

function getPrintablesThumbnailFormat(fileName) {
    const lower = (fileName || "").toLowerCase();
    if (lower.endsWith(".png")) return "png";
    if (lower.endsWith(".webp")) return "webp";
    if (lower.endsWith(".jpg")) return "jpg";
    return "jpeg";
}

function getPrintablesThumbnailFileName(fileName, format) {
    if (format === "jpeg") {
        return fileName.replace(/\.[^.]+$/, ".jpg");
    }

    return fileName;
}

function scrapePrintablesFromDom(pageUrl) {
    const parseTitleAuthor = (raw) => {
        if (!raw) return { title: "", author: "" };
        let base = raw.includes(" | ") ? raw.split(" | ")[0] : raw;
        if (base.includes(" by ")) {
            const parts = base.split(" by ");
            return {
                title: parts[0]?.trim() || "",
                author: parts.slice(1).join(" by ").trim()
            };
        }
        return { title: base.trim(), author: "" };
    };

    const authorHandle = (() => {
        const match = (document.body?.innerText || "").match(/@([A-Za-z0-9_-]+)/);
        return match ? match[1] : "";
    })();

    const rawTitle = document.querySelector('meta[property="og:title"]')?.content || document.title;
    const parsed = parseTitleAuthor(rawTitle);
    const tags = Array.from(document.querySelectorAll("div.row.tags a, div.row.tags.svelte-2i8v0n a"))
        .map((node) => (node.textContent || "").trim())
        .filter(Boolean);
    const descriptionNode = document.querySelector("main .user-inserted, .user-inserted");
    const thumbnailUrl = document.querySelector('meta[property="og:image"]')?.content || "";

    return {
        sourceUrl: pageUrl,
        title: parsed.title,
        author: parsed.author || authorHandle,
        authorUrl: authorHandle ? `https://www.printables.com/@${authorHandle}` : "",
        description: descriptionNode?.innerHTML?.trim() || "",
        tags: Array.from(new Set(tags)),
        thumbnailUrl
    };
}
