window.MeshVaultScrape = function() {
    const pageUrl = normalizeMmfPageUrl(window.location.href);
    const jsonLd = findMmfJsonLd();
    const embeddedData = readMmfEmbeddedData();
    const objectData = findMmfObjectData(embeddedData, extractMmfObjectId(pageUrl));
    const titleAuthor = parseMmfTitle(getMeta("og:title") || getMeta("twitter:title") || document.title || "");
    const title = cleanMmfTitle(objectData?.name || objectData?.title || jsonLd?.name || document.querySelector("h1")?.textContent || titleAuthor.title);
    const authorNode = findMmfAuthorNode();
    const author = cleanMmfText(
        objectData?.designer?.name
        || objectData?.designer?.username
        || objectData?.user?.name
        || objectData?.user?.username
        || jsonLd?.author?.name
        || authorNode?.textContent
        || titleAuthor.author
    );
    const authorUrl = normalizeMmfUrl(
        objectData?.designer?.url
        || objectData?.user?.url
        || jsonLd?.author?.url
        || authorNode?.getAttribute?.("href")
    );
    const description = cleanMmfHtml(
        objectData?.description
        || objectData?.descriptionHtml
        || jsonLd?.description
        || findMmfDescriptionHtml()
        || plainTextToMmfHtml(getMeta("description") || getMeta("og:description") || "")
    );
    const images = collectMmfImages(embeddedData, objectData, jsonLd);
    const thumbnailUrl = images[0] || normalizeMmfImage(getMeta("og:image") || getMeta("twitter:image") || "");
    const tags = collectMmfTags(objectData);

    return {
        sourceSite: "MyMiniFactory",
        sourceModelId: extractMmfObjectId(pageUrl),
        sourceUrl: pageUrl,
        title,
        author,
        authorUrl,
        summary: firstMmfText(description || getMeta("description") || ""),
        description,
        tags,
        license: collectMmfLicense(objectData, jsonLd),
        category: collectMmfCategory(objectData),
        thumbnailUrl,
        images,
        publishedAtUtc: normalizeMmfDate(objectData?.publishedAt || objectData?.datePublished || jsonLd?.datePublished),
        modifiedAtUtc: normalizeMmfDate(objectData?.updatedAt || objectData?.dateModified || jsonLd?.dateModified),
        sourceMetadataMethod: objectData ? "myminifactory-embedded-data" : jsonLd ? "myminifactory-jsonld-dom" : "myminifactory-dom"
    };
};

function getMeta(name) {
    return document.querySelector(`meta[property="${name}"]`)?.content
        || document.querySelector(`meta[name="${name}"]`)?.content
        || "";
}

function findMmfJsonLd() {
    for (const script of Array.from(document.querySelectorAll('script[type="application/ld+json"]'))) {
        try {
            const data = JSON.parse(script.textContent || "{}");
            const items = Array.isArray(data) ? data : [data];
            const found = items.find((item) => item?.name && (item.image || item.description || String(item.url || "").includes("/object/")));
            if (found) return found;
        } catch (_) {
            // Keep looking.
        }
    }
    return null;
}

function readMmfEmbeddedData() {
    const roots = [];
    try {
        if (window.__NEXT_DATA__) roots.push(window.__NEXT_DATA__);
        if (window.__NUXT__) roots.push(window.__NUXT__);
        if (window.__INITIAL_STATE__) roots.push(window.__INITIAL_STATE__);
    } catch (_) {
        // No-op.
    }
    document.querySelectorAll("script").forEach((script) => {
        const text = script.textContent || "";
        if (!/(object|designer|images|gallery|myminifactory)/i.test(text)) return;
        const json = text.match(/\{[\s\S]*\}/)?.[0] || "";
        if (!json || json.length > 5_000_000) return;
        try {
            roots.push(JSON.parse(json));
        } catch (_) {
            // Most scripts are not pure JSON.
        }
    });
    return roots;
}

function findMmfObjectData(roots, objectId) {
    const seen = new Set();
    const stack = Array.isArray(roots) ? roots.slice() : [roots];
    let best = null;
    while (stack.length) {
        const current = stack.pop();
        if (!current || typeof current !== "object" || seen.has(current)) continue;
        seen.add(current);

        const id = String(current.id || current.objectId || current.object_id || current.uuid || "");
        const hasName = current.name || current.title;
        const hasObjectShape = hasName && (current.description || current.images || current.gallery || current.files || id === objectId);
        if (hasObjectShape && (!best || id === objectId)) best = current;

        if (Array.isArray(current)) current.forEach((item) => stack.push(item));
        else Object.values(current).forEach((value) => {
            if (value && typeof value === "object") stack.push(value);
        });
    }
    return best;
}

function parseMmfTitle(rawTitle) {
    let title = cleanMmfText(rawTitle)
        .replace(/^3D Printable\s+/i, "")
        .replace(/\s*\|\s*Download.*$/i, "")
        .replace(/\s*-\s*MyMiniFactory.*$/i, "");
    let author = "";
    const byMatch = title.match(/^(.*?)\s+by\s+(.+)$/i);
    if (byMatch) {
        title = cleanMmfText(byMatch[1]);
        author = cleanMmfText(byMatch[2]);
    }
    return { title, author };
}

function findMmfAuthorNode() {
    return document.querySelector(".designerWordFlex a.under-hover:not([href*='objects'])")
        || document.querySelector("a[href*='/users/']")
        || document.querySelector("a[href*='/profile/']")
        || document.querySelector("a[href*='/designer/']")
        || Array.from(document.querySelectorAll("a[href]")).find((link) => /\/users\/|\/profile\/|\/designer\//i.test(link.getAttribute("href") || ""));
}

function findMmfDescriptionHtml() {
    const selectors = [
        "div.short-text.text-auto-link",
        "[class*='description' i]",
        "[data-testid*='description' i]",
        ".object-description",
        ".description"
    ];
    for (const selector of selectors) {
        const node = document.querySelector(selector);
        const text = cleanMmfText(node?.textContent || "");
        if (node && text.length > 20) return node.innerHTML || "";
    }
    return "";
}

function collectMmfImages(embeddedData, objectData, jsonLd) {
    const urls = [];
    const carouselUrls = [];
    const add = (value, element = null) => {
        const image = normalizeMmfImage(value);
        if (!image || isBadMmfImage(image, element)) return;
        urls.push(image);
    };
    const addCarousel = (value, element = null) => {
        const image = normalizeMmfImage(value);
        if (!image || isBadMmfImage(image, element)) return;
        carouselUrls.push(image);
        urls.push(image);
    };

    const imageScopes = Array.from(document.querySelectorAll(".slick-slide[data-slick-index]:not(.slick-cloned)"))
        .filter((node) => node.querySelector("img"));
    const scopes = imageScopes.length ? imageScopes : [document.querySelector("main") || document.body];
    scopes.forEach((scope) => {
        const slideCandidates = [];
        scope.querySelectorAll("img").forEach((img) => {
            slideCandidates.push(...bestMmfSrcsetUrls(img.getAttribute("srcset")));
            slideCandidates.push(
                img.getAttribute("data-original"),
                img.getAttribute("data-lazy-src"),
                img.getAttribute("data-src"),
                img.currentSrc,
                img.src,
                img.getAttribute("src")
            );
        });
        scope.querySelectorAll("[style], [data-src], [data-image], [data-url]").forEach((node) => {
            slideCandidates.push(...extractMmfAssetImageUrlsFromText(node.getAttribute("style") || ""));
            slideCandidates.push(...extractMmfUrlsFromText(node.getAttribute("style") || ""));
            slideCandidates.push(
                node.getAttribute("data-src"),
                node.getAttribute("data-image"),
                node.getAttribute("data-url")
            );
        });

        const best = slideCandidates
            .map((url) => normalizeMmfImage(url))
            .filter((image) => image && !isBadMmfImage(image, scope))
            .sort((left, right) => scoreMmfImage(right) - scoreMmfImage(left))[0] || "";
        addCarousel(best, scope);
    });

    if (!carouselUrls.length) {
        [jsonLd?.image].flat().filter(Boolean).forEach(add);
        extractMmfAssetImageUrlsFromText(document.documentElement?.innerHTML || "").forEach(add);
        collectMmfStrings(objectData).filter(isLikelyMmfImageString).forEach(add);
        collectMmfStrings(embeddedData).filter(isLikelyMmfImageString).forEach(add);
        Array.from(document.scripts).forEach((script) => {
            extractMmfAssetImageUrlsFromText(script.textContent || "").forEach(add);
            extractMmfUrlsFromText(script.textContent || "").filter(isLikelyMmfImageString).forEach(add);
        });
    }
    if (!carouselUrls.length) {
        add(getMeta("og:image"));
        add(getMeta("twitter:image"));
    }

    return selectMmfGalleryImages(urls).slice(0, 16);
}

function collectMmfStrings(root) {
    const strings = [];
    const seen = new Set();
    const stack = Array.isArray(root) ? root.slice() : [root];
    while (stack.length) {
        const current = stack.pop();
        if (!current || seen.has(current)) continue;
        if (typeof current === "string") {
            strings.push(current);
            continue;
        }
        if (typeof current !== "object") continue;
        seen.add(current);
        if (Array.isArray(current)) current.forEach((item) => stack.push(item));
        else Object.values(current).forEach((value) => stack.push(value));
    }
    return strings;
}

function isLikelyMmfImageString(value) {
    const lower = String(value || "").toLowerCase();
    return /\.(?:png|jpe?g|webp)(?:[?#]|$)/i.test(lower)
        || lower.includes("cdn.myminifactory.com")
        || lower.includes("cdn2.myminifactory.com")
        || lower.includes("dl.myminifactory.com")
        || lower.includes("dl2.myminifactory.com")
        || lower.includes("myminifactory.com/object-assets")
        || lower.includes("myminifactory.com/assets/object-assets");
}

function normalizeMmfImage(raw) {
    if (!raw || typeof raw !== "string") return "";
    const value = raw.replace(/&amp;/g, "&").replace(/\\\//g, "/").trim();
    try {
        return new URL(value, window.location.origin).toString();
    } catch (_) {
        return "";
    }
}

function isBadMmfImage(url, element = null) {
    const lower = String(url || "").toLowerCase();
    const isObjectAsset = lower.includes("/assets/object-assets/") || lower.includes("object-assets");
    if (!isObjectAsset && /(?:avatar|profile|logo|icon|placeholder|missing|blank|transparent|badge|flag)/i.test(lower)) return true;
    if (isObjectAsset && /(?:placeholder|missing|blank|transparent)/i.test(lower)) return true;
    if (!isMmfImageFileUrl(lower)) return true;
    if (element?.closest?.(".slick-cloned")) return true;
    if (element?.closest?.("header, nav, footer, [class*='avatar' i], [class*='profile' i], [class*='designer' i], [class*='author' i], [class*='ad' i]")) return true;
    return false;
}

function isMmfImageFileUrl(value) {
    return /\.(?:png|jpe?g|webp)(?:[?#]|$)/i.test(String(value || ""));
}

function bestMmfSrcsetUrls(srcset) {
    if (!srcset) return [];
    return srcset.split(",")
        .map((entry) => {
            const [url, descriptor] = entry.trim().split(/\s+/);
            const width = descriptor?.endsWith("w") ? parseInt(descriptor, 10) || 0 : 0;
            return { url, width };
        })
        .sort((left, right) => right.width - left.width)
        .map((entry) => entry.url)
        .filter(Boolean);
}

function extractMmfUrlsFromText(text) {
    return Array.from(String(text || "").matchAll(/https?:\\?\/\\?\/[^"')<>\s]+/gi))
        .map((match) => match[0].replace(/\\\//g, "/").replace(/&amp;/g, "&"));
}

function extractMmfAssetImageUrlsFromText(text) {
    const raw = String(text || "")
        .replace(/&quot;/g, '"')
        .replace(/&#34;/g, '"')
        .replace(/\\u002F/g, "/")
        .replace(/\\\//g, "/")
        .replace(/&amp;/g, "&");
    const matches = [
        ...raw.matchAll(/https?:\/\/cdn2?\.myminifactory\.com\/assets\/object-assets\/[^"')<>\s]+\/images\/[^"')<>\s]+/gi),
        ...raw.matchAll(/https?:\/\/dl2?\.myminifactory\.com\/object-assets\/[^"')<>\s]+\/images\/[^"')<>\s]+/gi),
        ...raw.matchAll(/https?:\/\/[^"')<>\s]*myminifactory\.com\/assets\/object-assets\/[^"')<>\s]+\/images\/[^"')<>\s]+/gi),
        ...raw.matchAll(/https?:\/\/[^"')<>\s]*myminifactory\.com\/object-assets\/[^"')<>\s]+\/images\/[^"')<>\s]+/gi),
        ...raw.matchAll(/\/object-assets\/[^"')<>\s]+\/images\/[^"')<>\s]+/gi),
        ...raw.matchAll(/\/assets\/object-assets\/[^"')<>\s]+\/images\/[^"')<>\s]+/gi)
    ];
    return matches
        .map((match) => match[0])
        .map((url) => url.startsWith("http") ? url : `https://dl2.myminifactory.com${url}`);
}

function sortMmfImages(values) {
    return values.slice().sort((left, right) => scoreMmfImage(right) - scoreMmfImage(left));
}

function scoreMmfImage(value) {
    const lower = String(value || "").toLowerCase();
    let score = 0;
    if (lower.includes("object-assets")) score += 800;
    const size = getMmfImageSizePrefix(value);
    if (size.width && size.height) score += Math.min(size.width * size.height, 2000000);
    if (lower.includes("preview")) score += 300;
    if (lower.includes("render")) score += 200;
    if (lower.includes("thumb")) score -= 100;
    if (lower.includes("avatar") || lower.includes("placeholder")) score -= 10000;
    return score;
}

function getMmfImageSizePrefix(value) {
    try {
        const file = new URL(value).pathname.split("/").pop() || "";
        const match = file.match(/^(\d+)x(\d+)-/i);
        return {
            width: match ? Number(match[1]) || 0 : 0,
            height: match ? Number(match[2]) || 0 : 0
        };
    } catch (_) {
        return { width: 0, height: 0 };
    }
}

function selectMmfGalleryImages(values) {
    const sorted = sortMmfImages(values).filter(isMmfImageFileUrl);
    const fullSize = sorted.filter((value) => {
        const size = getMmfImageSizePrefix(value);
        return size.width >= 1000 && size.height >= 1000;
    });
    const source = fullSize.length ? fullSize : sorted;
    return uniqueMmfImages(source);
}

function collectMmfTags(objectData) {
    const tags = new Set();
    const add = (value) => {
        const tag = cleanMmfText(typeof value === "string" ? value : value?.name || value?.tag || value?.label || "");
        if (tag && tag.length < 64) tags.add(tag.replace(/^#/, ""));
    };
    [objectData?.tags, objectData?.keywords].flat().filter(Boolean).forEach(add);
    document.querySelectorAll(".row.list-tags a.under-hover, a[href*='/search'], a[href*='/tag'], [class*='tag' i] a").forEach((node) => add(node.textContent || ""));
    return Array.from(tags);
}

function collectMmfCategory(objectData) {
    const categories = [];
    const add = (value) => {
        const text = cleanMmfText(typeof value === "string" ? value : value?.name || value?.title || "");
        if (text && text.length < 80) categories.push(text);
    };
    [objectData?.category, objectData?.categories].flat().filter(Boolean).forEach(add);
    document.querySelectorAll("a[href*='/category'], a[href*='/categories'], nav a").forEach((node) => add(node.textContent || ""));
    return uniqueMmfStrings(categories).slice(0, 5).join(" / ");
}

function collectMmfLicense(objectData, jsonLd) {
    return cleanMmfText(objectData?.license?.name || objectData?.license || jsonLd?.license || "");
}

function cleanMmfHtml(html) {
    if (!html) return "";
    const template = document.createElement("template");
    template.innerHTML = String(html);
    template.content.querySelectorAll("script, style, meta, link, noscript, form, button, svg").forEach((node) => node.remove());
    template.content.querySelectorAll("*").forEach((node) => {
        Array.from(node.attributes || []).forEach((attr) => {
            if (/^on/i.test(attr.name) || attr.name === "class" || attr.name === "style" || attr.name.startsWith("data-")) {
                node.removeAttribute(attr.name);
            }
        });
    });
    return template.innerHTML.trim();
}

function plainTextToMmfHtml(text) {
    const clean = cleanMmfText(text);
    return clean ? `<p>${escapeMmfHtml(clean)}</p>` : "";
}

function firstMmfText(htmlOrText) {
    const template = document.createElement("template");
    template.innerHTML = htmlOrText || "";
    const text = cleanMmfText(template.content.textContent || htmlOrText || "");
    return text.length <= 280 ? text : `${text.slice(0, 277).trim()}...`;
}

function normalizeMmfPageUrl(raw) {
    try {
        const url = new URL(raw, window.location.origin);
        url.hash = "";
        return url.toString().replace(/\/$/, "");
    } catch (_) {
        return String(raw || "").split("#")[0].replace(/\/$/, "");
    }
}

function extractMmfObjectId(pageUrl) {
    try {
        const last = new URL(pageUrl).pathname.split("/").filter(Boolean).pop() || "";
        return last.match(/-(\d+)$/)?.[1] || "";
    } catch (_) {
        return "";
    }
}

function normalizeMmfUrl(raw) {
    if (!raw) return "";
    try {
        return new URL(raw, window.location.origin).toString();
    } catch (_) {
        return "";
    }
}

function normalizeMmfDate(value) {
    if (!value) return "";
    const parsed = new Date(value);
    return Number.isNaN(parsed.getTime()) ? "" : parsed.toISOString();
}

function cleanMmfText(value) {
    return String(value || "").replace(/\u00a0/g, " ").replace(/\s+/g, " ").trim();
}

function cleanMmfTitle(value) {
    return cleanMmfText(value).replace(/^3D Printable\s+/i, "").trim();
}

function uniqueMmfStrings(values) {
    const seen = new Set();
    return values.filter((value) => {
        const clean = String(value || "").trim();
        const key = clean.toLowerCase();
        if (!clean || seen.has(key)) return false;
        seen.add(key);
        return true;
    });
}

function uniqueMmfImages(values) {
    const seen = new Set();
    return values.filter((value) => {
        const clean = String(value || "").trim();
        const key = getMmfImageKey(clean);
        if (!clean || seen.has(key)) return false;
        seen.add(key);
        return true;
    });
}

function getMmfImageKey(value) {
    try {
        const url = new URL(value);
        url.hash = "";
        url.search = "";
        url.hostname = url.hostname.toLowerCase()
            .replace(/^cdn2?\./, "")
            .replace(/^dl2?\./, "");
        url.pathname = decodeURIComponent(url.pathname)
            .replace(/^\/assets\/object-assets\//i, "/object-assets/")
            .replace(/\/images\/\d+x\d+-/i, "/images/")
            .toLowerCase();
        return url.toString();
    } catch (_) {
        return String(value || "").split(/[?#]/)[0].toLowerCase();
    }
}

function escapeMmfHtml(value) {
    return String(value || "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;");
}
