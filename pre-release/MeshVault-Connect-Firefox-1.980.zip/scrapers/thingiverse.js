window.MeshVaultScrape = function() {
    const pageUrl = normalizeThingiversePageUrl(window.location.href);
    const product = findThingiverseProductJsonLd(document);
    const domDescription = findThingiverseDescriptionHtml();
    const titleAuthor = parseThingiverseTitle(
        getMeta("og:title") ||
        getMeta("twitter:title") ||
        product?.name ||
        document.title ||
        ""
    );
    const author = findThingiverseAuthor(product, titleAuthor.author);
    const images = collectThingiverseImages(product);
    const thumbnailUrl = images[0] || filterThingiverseImageUrl(getMeta("og:image")) || filterThingiverseImageUrl(getMeta("twitter:image")) || "";
    const description = domDescription || plainTextDescriptionToHtml(product?.description || getMeta("og:description") || getMeta("description") || "");

    return {
        sourceUrl: pageUrl,
        title: titleAuthor.title || product?.name || "",
        author: author.name || "",
        authorUrl: author.url || "",
        summary: firstUsefulText(description),
        description,
        tags: collectThingiverseTags(product),
        thumbnailUrl,
        images,
        publishedAtUtc: normalizeThingiverseDate(product?.mainEntityOfPage?.datePublished),
        modifiedAtUtc: normalizeThingiverseDate(product?.mainEntityOfPage?.dateModified),
        sourceMetadataMethod: product ? "thingiverse-json-ld" : "thingiverse-dom"
    };
};

function findThingiverseProductJsonLd(root) {
    const scripts = Array.from(root.querySelectorAll('script[type="application/ld+json"]'));
    for (const script of scripts) {
        try {
            const data = JSON.parse(script.textContent || "{}");
            const items = Array.isArray(data) ? data : [data];
            const product = items.find((item) => item?.["@type"] === "Product" && (item.sku || item.mpn || item.name));
            if (product) return product;
        } catch (_) {
            // Thingiverse can include unrelated JSON-LD blocks; keep looking.
        }
    }

    return null;
}

function findThingiverseDescriptionHtml() {
    const selectors = [
        ".DetailDescriptionSummary__detailDescriptionSummary--UMoKx",
        "[class*='DetailDescriptionSummary']",
        "[data-testid*='description']",
        "[class*='description'] .markdown",
        "[class*='description']"
    ];

    for (const selector of selectors) {
        const node = document.querySelector(selector);
        const html = cleanThingiverseDescriptionHtml(node?.innerHTML || "");
        if (html && htmlToText(html).length > 40) {
            return html;
        }
    }

    return "";
}

function cleanThingiverseDescriptionHtml(html) {
    if (!html) return "";
    const template = document.createElement("template");
    template.innerHTML = html;
    template.content.querySelectorAll("script, style, iframe, ins, [class*='ad'], [id*='ad']").forEach((node) => node.remove());
    return template.innerHTML.trim();
}

function plainTextDescriptionToHtml(text) {
    const clean = normalizeThingiverseText(text);
    if (!clean) return "";

    const sectionNames = [
        "Features",
        "Print Settings",
        "How it's made",
        "How it’s made",
        "Post-Printing",
        "Custom Section",
        "Instructions"
    ];
    const pattern = new RegExp(`(${sectionNames.map(escapeRegex).join("|")})`, "gi");
    const parts = clean
        .replace(pattern, "\n\n$1\n")
        .split(/\n{2,}/)
        .map((part) => part.trim())
        .filter(Boolean);

    if (parts.length === 0) {
        return `<p>${escapeHtml(clean)}</p>`;
    }

    return parts.map((part, index) => {
        if (sectionNames.some((name) => name.toLowerCase() === part.toLowerCase())) {
            return `<h3>${escapeHtml(part)}</h3>`;
        }

        if (index > 0 && looksLikeKeyValueRun(part)) {
            return keyValueRunToList(part);
        }

        return `<p>${escapeHtml(part)}</p>`;
    }).join("");
}

function looksLikeKeyValueRun(text) {
    return /[A-Za-z][A-Za-z /-]{2,}:\s+\S/.test(text);
}

function keyValueRunToList(text) {
    const matches = Array.from(text.matchAll(/([A-Za-z][A-Za-z /-]{2,}):\s*/g));
    if (matches.length < 2) {
        return `<p>${escapeHtml(text)}</p>`;
    }

    const items = [];
    for (let index = 0; index < matches.length; index++) {
        const label = matches[index][1].trim();
        const valueStart = matches[index].index + matches[index][0].length;
        const valueEnd = index + 1 < matches.length ? matches[index + 1].index : text.length;
        const value = text.slice(valueStart, valueEnd).trim();
        if (label && value) {
            items.push(`<li><strong>${escapeHtml(label)}:</strong> ${escapeHtml(value)}</li>`);
        }
    }

    return items.length > 0 ? `<ul>${items.join("")}</ul>` : `<p>${escapeHtml(text)}</p>`;
}

function parseThingiverseTitle(rawTitle) {
    let base = String(rawTitle || "").replace(/\s+-\s+Thingiverse\s*$/i, "").trim();
    let title = base;
    let author = "";
    const byIndex = base.lastIndexOf(" by ");
    if (byIndex >= 0) {
        title = base.slice(0, byIndex).trim();
        author = base.slice(byIndex + 4).trim();
    }

    return { title, author };
}

function findThingiverseAuthor(product, fallbackAuthor) {
    const brand = product?.brand || {};
    const author = product?.mainEntityOfPage?.author || {};
    const name = author.name || brand.name || fallbackAuthor || "";
    const url = author.url || brand.url || (name ? `https://www.thingiverse.com/${encodeURIComponent(name)}` : "");
    return { name, url };
}

function collectThingiverseImages(product) {
    const urls = [];
    const add = (url, element = null) => {
        if (!url || typeof url !== "string") return;
        const clean = filterThingiverseImageUrl(url, element);
        if (!clean) return;
        if (/^https?:\/\//i.test(clean)) urls.push(clean);
    };

    const productImages = Array.isArray(product?.image) ? product.image : [product?.image];
    productImages.forEach(add);
    add(product?.thumbnailUrl);
    add(getMeta("og:image"));
    add(getMeta("twitter:image"));
    document.querySelectorAll("img.mediaItem--image, img[src*='cdn.thingiverse.com/assets/'], img[src*='resize.thingiverse.com/']").forEach((image) => {
        add(image.currentSrc || image.src || image.getAttribute("data-src") || "", image);
    });

    return uniqueThingiverseStrings(urls).slice(0, 12);
}

function filterThingiverseImageUrl(url, element = null) {
    const clean = unwrapThingiverseResizeUrl(String(url || "").replace(/&amp;/g, "&").trim());
    if (!clean || !/^https?:\/\//i.test(clean)) return "";
    if (isThingiversePlaceholder(clean) || isThingiverseProfileImage(clean, element)) return "";
    return clean;
}

function unwrapThingiverseResizeUrl(url) {
    try {
        const parsed = new URL(url);
        if (parsed.hostname.toLowerCase() !== "resize.thingiverse.com") return url;
        return parsed.searchParams.get("url") || url;
    } catch (_) {
        return url;
    }
}

function isThingiverseProfileImage(url, element = null) {
    const lower = String(url || "").toLowerCase();
    if (/\/(?:avatar|avatars|profile|profiles|user|users)\b/.test(lower)) return true;
    if (/\/(?:favicons?|logo|logos?)\b/.test(lower)) return true;

    if (!element) return false;
    const elementText = [
        element.className,
        element.id,
        element.alt,
        element.title,
        element.getAttribute?.("aria-label")
    ].filter(Boolean).join(" ").toLowerCase();
    if (/\b(?:avatar|profile|user|author|creator)\b/.test(elementText)) return true;
    if (element.closest?.("[class*='avatar' i], [class*='profile' i], [class*='author' i], [class*='creator' i], [class*='user' i]")) return true;

    const profileLink = element.closest?.("a[href]");
    const href = profileLink?.getAttribute("href") || "";
    if (href) {
        try {
            const parsed = new URL(href, window.location.origin);
            const path = parsed.pathname.replace(/^\/+|\/+$/g, "");
            if (parsed.hostname.includes("thingiverse.com") && path && !path.includes("/") && !path.startsWith("thing:")) {
                return true;
            }
        } catch (_) {
            // Ignore malformed links.
        }
    }

    return false;
}

function collectThingiverseTags(product) {
    const tags = [];
    document.querySelectorAll("a[href*='/tag:'], a[href*='tag='], [class*='tag']").forEach((node) => {
        const text = (node.textContent || "").trim();
        if (text && text.length < 50) tags.push(text.replace(/^#/, ""));
    });
    if (product?.category) {
        String(product.category).split(",").forEach((part) => tags.push(part.trim()));
    }
    return uniqueThingiverseStrings(tags);
}

function firstUsefulText(html) {
    const template = document.createElement("template");
    template.innerHTML = html || "";
    const text = Array.from(template.content.querySelectorAll("p, li"))
        .map((node) => normalizeThingiverseText(node.textContent || ""))
        .find((value) => value.length > 20) || "";
    return shortenThingiverseSummary(text);
}

function getMeta(name) {
    return document.querySelector(`meta[property="${name}"]`)?.content
        || document.querySelector(`meta[name="${name}"]`)?.content
        || "";
}

function normalizeThingiversePageUrl(urlString) {
    try {
        const url = new URL(urlString);
        url.hash = "";
        url.pathname = url.pathname.replace(/\/files\/?$/, "").replace(/\/zip\/?$/, "");
        return url.toString().replace(/\/$/, "");
    } catch (_) {
        return String(urlString || "").split("#")[0].replace(/\/$/, "");
    }
}

function extractThingiverseId(url) {
    return String(url || "").match(/thing:(\d+)/i)?.[1] || "";
}

function normalizeThingiverseDate(value) {
    return value ? new Date(value).toISOString() : "";
}

function normalizeThingiverseText(value) {
    return String(value || "")
        .replace(/\u00a0/g, " ")
        .replace(/\uFFFD/g, "")
        .replace(/\)([A-Z])/g, ") $1")
        .replace(/\s+/g, " ")
        .trim();
}

function shortenThingiverseSummary(value) {
    const text = normalizeThingiverseText(value);
    if (text.length <= 280) return text;

    const sentenceEnd = text.search(/[.!?]\s+[A-Z0-9]/);
    if (sentenceEnd >= 80 && sentenceEnd <= 280) {
        return text.slice(0, sentenceEnd + 1).trim();
    }

    return `${text.slice(0, 277).trim()}...`;
}

function htmlToText(html) {
    const template = document.createElement("template");
    template.innerHTML = html || "";
    return normalizeThingiverseText(template.content.textContent || "");
}

function isThingiversePlaceholder(url) {
    const lower = String(url || "").toLowerCase();
    return !lower || lower.includes("/site/img/thingiverseopengraph") || lower.includes("/site/img/favicons/");
}

function uniqueThingiverseStrings(values) {
    const seen = new Set();
    return values
        .map((value) => String(value || "").trim())
        .filter((value) => {
            if (!value) return false;
            const key = value.toLowerCase();
            if (seen.has(key)) return false;
            seen.add(key);
            return true;
        });
}

function escapeHtml(value) {
    return String(value || "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;");
}

function escapeRegex(value) {
    return String(value).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
