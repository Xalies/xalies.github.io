// This script is injected into pages.
// It provides a small helper for manual uploads.

let meshVaultExtensionEnabled = false;
let meshVaultDisabledSites = {};

const MESHVAULT_SITE_DOMAINS = [
    "printables.com",
    "thingiverse.com",
    "makerworld.com",
    "thangs.com",
    "cults3d.com",
    "grabcad.com",
    "myminifactory.com",
    "tinkercad.com"
];

function meshVaultCurrentSiteDomain() {
    const host = window.location.hostname.toLowerCase();
    return MESHVAULT_SITE_DOMAINS.find((domain) => host === domain || host.endsWith(`.${domain}`)) || "";
}

function meshVaultIsEnabled() {
    const domain = meshVaultCurrentSiteDomain();
    return meshVaultExtensionEnabled !== false && !(domain && meshVaultDisabledSites[domain]);
}

function notifyMeshVaultPageBridgeEnabled() {
    try {
        window.postMessage({
            source: "MeshVaultConnect",
            type: "meshvault-enabled",
            enabled: meshVaultIsEnabled()
        }, window.location.origin);
    } catch (_) {
        // No-op
    }
}

chrome.storage.local.get({ extensionEnabled: true, disabledSites: {} }, (settings) => {
    meshVaultExtensionEnabled = settings.extensionEnabled !== false;
    meshVaultDisabledSites = settings.disabledSites || {};
    notifyMeshVaultPageBridgeEnabled();
    initializeMeshVaultPage();
    installThingiversePageBridge();
});

chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local") return;
    if (!changes.extensionEnabled && !changes.disabledSites) return;
    if (changes.extensionEnabled) meshVaultExtensionEnabled = changes.extensionEnabled.newValue !== false;
    if (changes.disabledSites) meshVaultDisabledSites = changes.disabledSites.newValue || {};
    notifyMeshVaultPageBridgeEnabled();
    if (meshVaultIsEnabled()) {
        initializeMeshVaultPage();
        installThingiversePageBridge();
    }
    if (!meshVaultIsEnabled()) {
        showMeshVaultDownloadStatus({ state: "hide" });
    }
});

const SUPPORTED_DEBUG_HOSTS = MESHVAULT_SITE_DOMAINS;

function isSupportedDebugHost() {
    const host = window.location.hostname || "";
    return SUPPORTED_DEBUG_HOSTS.some((domain) => host.includes(domain));
}

function sendDebugPageSeen(reason) {
    if (!meshVaultIsEnabled()) return;
    if (!isSupportedDebugHost()) return;
    chrome.runtime.sendMessage({
        action: "debugPageSeen",
        pageUrl: window.location.href,
        reason: reason || ""
    });
}

function initializeMeshVaultPage() {
    if (!meshVaultIsEnabled()) return;
    sendDebugPageSeen("load");
    if (window.__meshVaultPageNotified) return;
    window.__meshVaultPageNotified = true;
    chrome.runtime.sendMessage({ action: "supportedPageLoaded", pageUrl: window.location.href });

    const isModelPage = () => {
        const host = window.location.hostname.toLowerCase();
        const path = window.location.pathname.toLowerCase();
        if (host.includes("cults3d.com")) {
            return path.includes("/3d-model/") && !path.includes("/downloads/") && !path.includes("/orders/");
        }
        if (host.includes("thingiverse.com")) {
            return path.includes("/thing:");
        }
        if (host.includes("printables.com")) {
            return path.includes("/model/");
        }
        if (host.includes("makerworld.com")) {
            return path.includes("/models/");
        }
        if (host.includes("thangs.com")) {
            return path.includes("/3d-model/");
        }
        if (host.includes("grabcad.com")) {
            return path.includes("/library/");
        }
        if (host.includes("myminifactory.com")) {
            return path.includes("/object/") || path.includes("/objects/");
        }
        if (host.includes("tinkercad.com")) {
            return path.includes("/things/");
        }
        return false;
    };

    if (isModelPage()) {
        chrome.runtime.sendMessage({ action: "supportedModelPageLoaded", pageUrl: window.location.href });
        setTimeout(() => {
            try {
                const rawMeta = typeof window.MeshVaultScrape === "function" ? window.MeshVaultScrape() : "";
                if (rawMeta) {
                    chrome.runtime.sendMessage({
                        action: "cachePageMetadata",
                        pageUrl: window.location.href,
                        rawMeta
                    });
                }
            } catch (_) {
                // Metadata capture is best-effort; the background worker can still scrape on demand.
            }
        }, 500);
    }
    console.log("MeshVault active on supported site:", window.location.href);
}

function meshVaultModelPageKey(urlString) {
    try {
        const url = new URL(urlString || window.location.href, window.location.href);
        const host = url.hostname.toLowerCase();
        const path = url.pathname.toLowerCase();
        if (host.includes("thingiverse.com")) return path.match(/\/thing:\d+/)?.[0] || "";
        if (host.includes("printables.com")) return path.match(/\/model\/[^/]+/)?.[0] || "";
        if (host.includes("makerworld.com")) return path.match(/\/models\/[^/]+/)?.[0] || "";
        if (host.includes("thangs.com")) return path.match(/\/3d-model\/[^/]+/)?.[0] || "";
        if (host.includes("cults3d.com")) return path.match(/\/3d-model\/[^/]+\/[^/]+/)?.[0] || "";
        if (host.includes("grabcad.com")) return path.match(/\/library\/[^/]+/)?.[0] || "";
        if (host.includes("myminifactory.com")) return path.match(/\/objects?\/[^/]+/)?.[0] || "";
        if (host.includes("tinkercad.com")) return path.match(/\/things\/[^/]+/)?.[0] || "";
        return "";
    } catch (_) {
        return "";
    }
}

if (!window.__meshVaultModelPageChangeWatcher) {
    window.__meshVaultModelPageChangeWatcher = true;
    let meshVaultLastModelPageKey = meshVaultModelPageKey(window.location.href);
    let meshVaultLastModelPageUrl = window.location.href;
    const cacheMeshVaultCurrentPageMetadata = () => {
        setTimeout(() => {
            try {
                const rawMeta = typeof window.MeshVaultScrape === "function" ? window.MeshVaultScrape() : "";
                if (rawMeta) {
                    chrome.runtime.sendMessage({
                        action: "cachePageMetadata",
                        pageUrl: window.location.href,
                        rawMeta
                    });
                }
            } catch (_) {
                // Metadata capture is best-effort; the background worker can still scrape on demand.
            }
        }, 500);
    };
    const notifyModelPageChanged = () => {
        if (!meshVaultIsEnabled()) return;
        const nextKey = meshVaultModelPageKey(window.location.href);
        if (meshVaultLastModelPageKey && nextKey !== meshVaultLastModelPageKey) {
            clearMeshVaultExtraImageSelection();
            chrome.runtime.sendMessage({
                action: "modelPageChanged",
                pageUrl: window.location.href,
                previousPageUrl: meshVaultLastModelPageUrl
            });
            if (nextKey) cacheMeshVaultCurrentPageMetadata();
        }
        meshVaultLastModelPageKey = nextKey;
        meshVaultLastModelPageUrl = window.location.href;
    };
    const originalMeshVaultPushState = history.pushState;
    const originalMeshVaultReplaceState = history.replaceState;
    history.pushState = function () {
        const result = originalMeshVaultPushState.apply(this, arguments);
        setTimeout(notifyModelPageChanged, 0);
        return result;
    };
    history.replaceState = function () {
        const result = originalMeshVaultReplaceState.apply(this, arguments);
        setTimeout(notifyModelPageChanged, 0);
        return result;
    };
    window.addEventListener("popstate", () => setTimeout(notifyModelPageChanged, 0));
}

if (window.location.hostname.includes("cults3d.com") && window.location.pathname.includes("/3d-model/")) {
    chrome.runtime.sendMessage({
        action: "debugCultsMeta",
        pageUrl: window.location.href,
        message: "Cults3D content script loaded"
    });
    const sendCultsMeta = (attempt) => {
        if (!meshVaultIsEnabled()) return;
        if (window.__meshVaultCultsMetaSent) return;
        const hasScraper = typeof window.MeshVaultScrape === "function";
        const rawMeta = hasScraper ? window.MeshVaultScrape() : "";
        if (rawMeta) {
            window.__meshVaultCultsMetaSent = true;
            chrome.runtime.sendMessage({
                action: "cacheCultsMeta",
                pageUrl: rawMeta?.sourceUrl || window.location.href,
                rawMeta
            });
            return;
        }
        if (attempt >= 3) {
            chrome.runtime.sendMessage({
                action: "debugCultsMeta",
                pageUrl: window.location.href,
                message: "Cults3D meta scrape failed after retries",
                hasScraper
            });
            return;
        }
        const delay = attempt === 1 ? 800 : attempt === 2 ? 2000 : 4000;
        setTimeout(() => sendCultsMeta(attempt + 1), delay);
    };
    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", () => sendCultsMeta(1), { once: true });
    } else {
        sendCultsMeta(1);
    }
}

if (window.location.hostname.includes("thangs.com")) {
    const THANGS_AFFILIATE_KEY = "meshvault_thangs_affiliate_applied";
    const THANGS_AFFILIATE_CODE = "MeshVault";
    const isThangsModelLink = (href) => {
        if (!href) return false;
        try {
            const url = new URL(href, window.location.origin);
            return url.hostname.includes("thangs.com")
                && url.pathname.includes("/designer/")
                && url.pathname.includes("/3d-model/");
        } catch (_) {
            return false;
        }
    };
    const shouldApplyAffiliate = () => !sessionStorage.getItem(THANGS_AFFILIATE_KEY);

    document.addEventListener("click", (event) => {
        try {
            if (!meshVaultIsEnabled()) return;
            const link = event.target?.closest?.("a[href]");
            if (!link) return;
            const href = link.getAttribute("href") || "";
            if (!isThangsModelLink(href)) return;
            if (!shouldApplyAffiliate()) return;

            const targetUrl = new URL(href, window.location.origin);
            if (targetUrl.searchParams.has("affiliateCode")) {
                sessionStorage.setItem(THANGS_AFFILIATE_KEY, "1");
                return;
            }

            targetUrl.searchParams.set("affiliateCode", THANGS_AFFILIATE_CODE);
            sessionStorage.setItem(THANGS_AFFILIATE_KEY, "1");
            event.preventDefault();
            event.stopPropagation();
            window.location.assign(targetUrl.toString());
        } catch (_) {
            // No-op
        }
    }, true);

    const cacheThangsMeta = () => {
        if (!meshVaultIsEnabled()) return;
        if (!window.location.pathname.includes("/designer/") || !window.location.pathname.includes("/3d-model/")) return;
        const rawMeta = typeof window.MeshVaultScrape === "function"
            ? window.MeshVaultScrape()
            : "";
        if (rawMeta) {
            chrome.runtime.sendMessage({
                action: "cacheThangsMeta",
                pageUrl: window.location.href,
                rawMeta
            });
        }
    };

    cacheThangsMeta();

    if (!window.__meshVaultThangsWatcher) {
        window.__meshVaultThangsWatcher = true;
        let lastUrl = window.location.href;
        const handleUrlChange = () => {
            const current = window.location.href;
            if (current === lastUrl) return;
            lastUrl = current;
            cacheThangsMeta();
        };
        const originalPushState = history.pushState;
        const originalReplaceState = history.replaceState;
        history.pushState = function () {
            const result = originalPushState.apply(this, arguments);
            handleUrlChange();
            return result;
        };
        history.replaceState = function () {
            const result = originalReplaceState.apply(this, arguments);
            handleUrlChange();
            return result;
        };
        window.addEventListener("popstate", handleUrlChange);
        const observer = new MutationObserver(() => {
            handleUrlChange();
        });
        observer.observe(document.body, { childList: true, subtree: true });
    }
}
if (window.location.hostname.includes("cults3d.com")) {
    let lastUrl = window.location.href;
    const scheduleCultsScrape = () => {
        if (!meshVaultIsEnabled()) return;
        if (!window.location.pathname.includes("/3d-model/")) return;
        window.__meshVaultCultsMetaSent = false;
        setTimeout(() => {
            chrome.runtime.sendMessage({
                action: "debugCultsMeta",
                pageUrl: window.location.href,
                message: "Cults3D SPA navigation detected"
            });
            const send = (attempt) => {
                if (window.__meshVaultCultsMetaSent) return;
                if (typeof window.MeshVaultScrape !== "function") return;
                const rawMeta = window.MeshVaultScrape();
                if (rawMeta) {
                    window.__meshVaultCultsMetaSent = true;
                    chrome.runtime.sendMessage({
                        action: "cacheCultsMeta",
                        pageUrl: rawMeta?.sourceUrl || window.location.href,
                        rawMeta
                    });
                    return;
                }
                if (attempt < 2) {
                    setTimeout(() => send(attempt + 1), 1200);
                }
            };
            send(1);
        }, 600);
    };
    const handleUrlChange = () => {
        const current = window.location.href;
        if (current === lastUrl) return;
        lastUrl = current;
        scheduleCultsScrape();
    };
    const originalPushState = history.pushState;
    const originalReplaceState = history.replaceState;
    history.pushState = function () {
        const result = originalPushState.apply(this, arguments);
        handleUrlChange();
        return result;
    };
    history.replaceState = function () {
        const result = originalReplaceState.apply(this, arguments);
        handleUrlChange();
        return result;
    };
    window.addEventListener("popstate", handleUrlChange);
    const observer = new MutationObserver(() => {
        handleUrlChange();
    });
    observer.observe(document.body, { childList: true, subtree: true });
}


if (!window.__meshVaultSpaWatcher) {
    window.__meshVaultSpaWatcher = true;
    let lastUrl = window.location.href;
    const handleUrlChange = () => {
        const current = window.location.href;
        if (current === lastUrl) return;
        lastUrl = current;
        sendDebugPageSeen("spa-change");
    };
    const originalPushState = history.pushState;
    const originalReplaceState = history.replaceState;
    history.pushState = function () {
        const result = originalPushState.apply(this, arguments);
        handleUrlChange();
        return result;
    };
    history.replaceState = function () {
        const result = originalReplaceState.apply(this, arguments);
        handleUrlChange();
        return result;
    };
    window.addEventListener("popstate", handleUrlChange);
    const observer = new MutationObserver(() => {
        handleUrlChange();
    });
    observer.observe(document.body, { childList: true, subtree: true });
}

function triggerMeshVaultSave(url, filename) {
    if (!meshVaultIsEnabled()) return;
    chrome.runtime.sendMessage({
        action: "uploadToMeshVault",
        url: url,
        filename: filename
    });
}

window.MeshVaultTriggerSave = triggerMeshVaultSave;

function installThingiversePageBridge() {
    if (meshVaultExtensionEnabled !== true) return;
    if (!meshVaultIsEnabled()) return;
    if (!window.location.hostname.includes("thingiverse.com") || window.__meshVaultThingiverseBridgeInjected) return;
    window.__meshVaultThingiverseBridgeInjected = true;
    const script = document.createElement("script");
    script.src = chrome.runtime.getURL("thingiverse_bridge.js");
    script.onload = () => script.remove();
    (document.documentElement || document.head || document.body).appendChild(script);
}

installThingiversePageBridge();

window.addEventListener("message", (event) => {
    try {
        if (!meshVaultIsEnabled()) return;
        if (event.source !== window) return;
        const data = event.data || {};
        if (data.source !== "MeshVaultThingiverseBridge") return;
        if (data.type === "thingiverse-blob-start") {
            const rawMeta = typeof window.MeshVaultScrape === "function"
                ? window.MeshVaultScrape()
                : "";
            console.log("MeshVault Thingiverse: bridge captured blob download", {
                filename: data.filename || "",
                size: data.size || 0,
                via: data.via || ""
            });
            queueMeshVaultThingiverseBlobMessage(data.id, {
                action: "thingiverseBlobStart",
                id: data.id,
                filename: data.filename || "",
                pageUrl: data.pageUrl || window.location.href,
                size: data.size || 0,
                mimeType: data.mimeType || "",
                metadata: rawMeta
            });
            return;
        }
        if (data.type === "thingiverse-blob-chunk") {
            queueMeshVaultThingiverseBlobMessage(data.id, {
                action: "thingiverseBlobChunk",
                id: data.id,
                offset: data.offset || 0,
                bytes: data.bytes || 0,
                data: data.data || ""
            });
            return;
        }
        if (data.type === "thingiverse-blob-complete") {
            queueMeshVaultThingiverseBlobMessage(data.id, {
                action: "thingiverseBlobComplete",
                id: data.id
            });
            return;
        }
        if (data.type === "thingiverse-blob-error") {
            queueMeshVaultThingiverseBlobMessage(data.id, {
                action: "thingiverseBlobError",
                id: data.id,
                message: data.message || "Could not read blob download."
            });
            return;
        }
        if (data.type !== "thingiverse-download" || !data.url) return;
        const filename = data.filename || getThingiverseFilenameFromUrl(data.url) || "";
        if (shouldSkipThingiverseDuplicate(data.url, filename)) return;
        const rawMeta = typeof window.MeshVaultScrape === "function"
            ? window.MeshVaultScrape()
            : "";
        console.log("MeshVault Thingiverse: bridge captured download", {
            via: data.via || "",
            filename,
            url: data.url
        });
        chrome.runtime.sendMessage({
            action: "uploadToMeshVault",
            url: data.url,
            filename,
            pageUrl: data.pageUrl || window.location.href,
            metadata: rawMeta,
            headers: data.headers || {}
        });
    } catch (_) {
        // No-op
    }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (!meshVaultIsEnabled() && message?.action !== "meshVaultDownloadStatus") return;
    if (message?.action === "meshVaultDownloadStatus") {
        showMeshVaultDownloadStatus(message.status || {});
        sendResponse({ ok: true });
        return true;
    }
    if (message?.action === "toggleExtraImagePicker") {
        toggleMeshVaultExtraImagePicker();
        sendResponse({ ok: true });
        return true;
    }
    if (message?.action === "getExtraImageSelection") {
        sendResponse({
            ok: true,
            pageUrl: window.location.href,
            urls: Array.from(meshVaultSelectedExtraImages).slice(0, MESHVAULT_EXTRA_IMAGE_LIMIT)
        });
        return true;
    }
    if (message?.action !== "scrapeMetadata") return;
    try {
        const rawMeta = typeof window.MeshVaultScrape === "function"
            ? window.MeshVaultScrape()
            : "";
        sendResponse({ rawMeta });
    } catch (err) {
        sendResponse({ rawMeta: "" });
    }
    return true;
});

let meshVaultDownloadStatusPanel = null;
let meshVaultDownloadStatusHideTimer = null;
const meshVaultThingiverseBlobQueues = new Map();

function queueMeshVaultThingiverseBlobMessage(id, message) {
    const key = String(id || "");
    const previous = meshVaultThingiverseBlobQueues.get(key) || Promise.resolve();
    const next = previous
        .catch(() => {})
        .then(() => chrome.runtime.sendMessage(message).catch(() => {}));
    meshVaultThingiverseBlobQueues.set(key, next);
    if (message.action === "thingiverseBlobComplete" || message.action === "thingiverseBlobError") {
        next.finally(() => {
            if (meshVaultThingiverseBlobQueues.get(key) === next) {
                meshVaultThingiverseBlobQueues.delete(key);
            }
        });
    }
}

function ensureMeshVaultDownloadStatusStyle() {
    if (document.getElementById("meshvault-download-status-style")) return;
    const style = document.createElement("style");
    style.id = "meshvault-download-status-style";
    style.textContent = `
        #meshvault-download-status {
            position: fixed;
            right: 18px;
            top: 18px;
            z-index: 2147483647;
            width: min(360px, calc(100vw - 36px));
            padding: 13px 14px;
            border-radius: 8px;
            background: linear-gradient(135deg, rgba(38, 33, 44, 0.96), rgba(30, 27, 31, 0.96));
            color: #f4f1fa;
            border: 1px solid #3a3344;
            box-shadow: 0 18px 48px rgba(0,0,0,0.42);
            font-family: "Bahnschrift", "Segoe UI Variable", "Segoe UI", Arial, sans-serif;
            font-size: 13px;
            line-height: 1.35;
            display: none;
            gap: 11px;
            align-items: center;
            backdrop-filter: blur(10px);
        }
        #meshvault-download-status.meshvault-visible {
            display: flex;
        }
        #meshvault-download-status .meshvault-spinner {
            width: 26px;
            height: 26px;
            border-radius: 999px;
            border: 3px solid rgba(244,241,250,0.2);
            border-top-color: #9a7cff;
            flex: 0 0 26px;
            animation: meshvault-spin 0.82s linear infinite;
        }
        #meshvault-download-status.meshvault-success .meshvault-spinner,
        #meshvault-download-status.meshvault-error .meshvault-spinner {
            animation: none;
            display: grid;
            place-items: center;
            border: 0;
            background: #8fe3a3;
            font-weight: 800;
            color: #100d16;
        }
        #meshvault-download-status.meshvault-error .meshvault-spinner {
            background: #ff7d8f;
        }
        #meshvault-download-status.meshvault-success .meshvault-spinner::before {
            content: "✓";
        }
        #meshvault-download-status.meshvault-error .meshvault-spinner::before {
            content: "!";
        }
        #meshvault-download-status .meshvault-title-row {
            display: flex;
            align-items: baseline;
            justify-content: space-between;
            gap: 12px;
            margin-bottom: 2px;
        }
        #meshvault-download-status .meshvault-title {
            font-weight: 750;
            letter-spacing: 0;
        }
        #meshvault-download-status .meshvault-phase {
            color: #cdbdff;
            font-size: 12px;
            font-weight: 700;
            white-space: nowrap;
        }
        #meshvault-download-status.meshvault-error .meshvault-phase {
            color: #ffb3bf;
        }
        #meshvault-download-status.meshvault-success .meshvault-phase {
            color: #8fe3a3;
        }
        #meshvault-download-status .meshvault-message {
            color: #b8afc5;
            overflow-wrap: anywhere;
        }
        #meshvault-download-status .meshvault-progress-track {
            height: 4px;
            margin-top: 9px;
            border-radius: 999px;
            background: #2b2733;
            overflow: hidden;
        }
        #meshvault-download-status .meshvault-progress-fill {
            width: 36%;
            height: 100%;
            border-radius: inherit;
            background: linear-gradient(90deg, #9a7cff, #cdbdff);
            transform-origin: left center;
            animation: meshvault-progress-pulse 1.15s ease-in-out infinite;
        }
        #meshvault-download-status.meshvault-has-percent .meshvault-progress-fill {
            animation: none;
            width: var(--meshvault-percent, 0%);
        }
        @keyframes meshvault-spin {
            to { transform: rotate(360deg); }
        }
        @keyframes meshvault-progress-pulse {
            0% { transform: translateX(-115%); }
            55% { transform: translateX(80%); }
            100% { transform: translateX(240%); }
        }
    `;
    document.documentElement.appendChild(style);
}

function ensureMeshVaultDownloadStatusPanel() {
    ensureMeshVaultDownloadStatusStyle();
    if (meshVaultDownloadStatusPanel) return meshVaultDownloadStatusPanel;

    meshVaultDownloadStatusPanel = document.createElement("div");
    meshVaultDownloadStatusPanel.id = "meshvault-download-status";
    meshVaultDownloadStatusPanel.innerHTML = `
        <div class="meshvault-spinner" aria-hidden="true"></div>
        <div style="min-width:0;flex:1">
            <div class="meshvault-title-row">
                <div class="meshvault-title">MeshVault</div>
                <div class="meshvault-phase">Preparing</div>
            </div>
            <div class="meshvault-message">Starting...</div>
            <div class="meshvault-progress-track"><div class="meshvault-progress-fill"></div></div>
        </div>
    `;
    document.documentElement.appendChild(meshVaultDownloadStatusPanel);
    return meshVaultDownloadStatusPanel;
}

function showMeshVaultDownloadStatus(status) {
    if (status.state === "hide") {
        hideMeshVaultDownloadStatus(0);
        return;
    }

    const panel = ensureMeshVaultDownloadStatusPanel();
    window.clearTimeout(meshVaultDownloadStatusHideTimer);
    panel.classList.add("meshvault-visible");
    panel.classList.toggle("meshvault-success", status.state === "success");
    panel.classList.toggle("meshvault-error", status.state === "error");
    panel.classList.toggle("meshvault-has-percent", Number.isFinite(status.percent));
    panel.style.setProperty("--meshvault-percent", `${Math.max(0, Math.min(100, Number(status.percent) || 0))}%`);
    panel.querySelector(".meshvault-title").textContent = status.title || "MeshVault";
    panel.querySelector(".meshvault-phase").textContent = status.phase || "Working";
    panel.querySelector(".meshvault-message").textContent = status.message || "Working...";

    if (status.state === "success") {
        hideMeshVaultDownloadStatus(2600);
    } else if (status.state === "error") {
        hideMeshVaultDownloadStatus(6500);
    }
}

function hideMeshVaultDownloadStatus(delay) {
    window.clearTimeout(meshVaultDownloadStatusHideTimer);
    meshVaultDownloadStatusHideTimer = window.setTimeout(() => {
        if (meshVaultDownloadStatusPanel) {
            meshVaultDownloadStatusPanel.classList.remove("meshvault-visible");
        }
    }, delay);
}

const MESHVAULT_EXTRA_IMAGE_LIMIT = 5;
let meshVaultExtraPickerActive = false;
let meshVaultExtraPickerBar = null;
let meshVaultExtraPickerCount = null;
let meshVaultExtraPickerHint = null;
let meshVaultDefaultThumbnailPreview = null;
let meshVaultSelectedExtraImages = new Set();
let meshVaultDefaultThumbnailUrl = "";

function ensureMeshVaultExtraPickerStyle() {
    if (document.getElementById("meshvault-extra-image-picker-style")) return;
    const style = document.createElement("style");
    style.id = "meshvault-extra-image-picker-style";
    style.textContent = `
        .meshvault-extra-image-selected {
            outline: 4px solid #9a7cff !important;
            outline-offset: 3px !important;
            box-shadow: 0 0 0 8px rgba(154, 124, 255, 0.24) !important;
        }
        #meshvault-extra-image-picker {
            position: fixed;
            top: 16px;
            right: 16px;
            z-index: 2147483647;
            width: 290px;
            padding: 12px;
            border-radius: 8px;
            background: linear-gradient(135deg, #26212c, #1e1b1f);
            color: #f4f1fa;
            border: 1px solid #3a3344;
            box-shadow: 0 18px 50px rgba(0,0,0,0.45);
            font-family: "Bahnschrift", "Segoe UI Variable", "Segoe UI", Arial, sans-serif;
            font-size: 13px;
        }
        #meshvault-extra-image-picker strong {
            display: block;
            font-size: 14px;
            margin-bottom: 4px;
        }
        #meshvault-extra-image-picker .meshvault-picker-hint {
            color: #b8afc5;
            line-height: 1.35;
            margin: 6px 0 10px;
        }
        #meshvault-extra-image-picker .meshvault-default-preview {
            display: none;
            margin: 10px 0;
            padding: 8px;
            border-radius: 8px;
            border: 1px solid #9a7cff;
            background: rgba(154, 124, 255, 0.14);
            align-items: center;
            gap: 9px;
        }
        #meshvault-extra-image-picker .meshvault-default-preview-title {
            color: #cdbdff;
            font-weight: 700;
            line-height: 1.25;
        }
        #meshvault-extra-image-picker .meshvault-default-preview img {
            display: block;
            width: 72px;
            height: 72px;
            flex: 0 0 72px;
            object-fit: cover;
            border-radius: 6px;
            border: 1px solid #4a4256;
            background: #0c0b0f;
        }
        #meshvault-extra-image-picker .meshvault-picker-actions {
            display: flex;
            gap: 8px;
        }
        #meshvault-extra-image-picker button {
            border: 0;
            border-radius: 22px;
            padding: 7px 10px;
            cursor: pointer;
            font-weight: 700;
        }
        #meshvault-extra-image-picker .meshvault-picker-done {
            background: #9a7cff;
            color: #100d16;
        }
        #meshvault-extra-image-picker .meshvault-picker-clear {
            background: #2b2733;
            color: #f4f1fa;
            border: 1px solid #4a4256;
        }
    `;
    document.documentElement.appendChild(style);
}

function toggleMeshVaultExtraImagePicker() {
    if (meshVaultExtraPickerActive) {
        stopMeshVaultExtraImagePicker(false);
    } else {
        startMeshVaultExtraImagePicker();
    }
}

function startMeshVaultExtraImagePicker() {
    ensureMeshVaultExtraPickerStyle();
    meshVaultExtraPickerActive = true;
    if (!meshVaultExtraPickerBar) {
        meshVaultExtraPickerBar = document.createElement("div");
        meshVaultExtraPickerBar.id = "meshvault-extra-image-picker";
        meshVaultExtraPickerBar.innerHTML = `
            <strong>MeshVault extra images</strong>
            <div><span id="meshvault-extra-image-count">0/${MESHVAULT_EXTRA_IMAGE_LIMIT}</span> selected for the next save.</div>
            <div class="meshvault-picker-hint" id="meshvault-extra-image-hint">Left-click galleries as normal. Right-click a visible loaded image to add or remove it.</div>
            <div class="meshvault-default-preview" id="meshvault-default-thumbnail-preview">
                <img alt="Default scraped thumbnail" />
                <div class="meshvault-default-preview-title">Default scraped thumbnail</div>
            </div>
            <div class="meshvault-picker-actions">
                <button class="meshvault-picker-done" type="button">Done</button>
                <button class="meshvault-picker-clear" type="button">Clear</button>
            </div>
        `;
        meshVaultExtraPickerCount = meshVaultExtraPickerBar.querySelector("#meshvault-extra-image-count");
        meshVaultExtraPickerHint = meshVaultExtraPickerBar.querySelector("#meshvault-extra-image-hint");
        meshVaultDefaultThumbnailPreview = meshVaultExtraPickerBar.querySelector("#meshvault-default-thumbnail-preview");
        meshVaultExtraPickerBar.querySelector(".meshvault-picker-done").addEventListener("click", () => stopMeshVaultExtraImagePicker(false));
        meshVaultExtraPickerBar.querySelector(".meshvault-picker-clear").addEventListener("click", clearMeshVaultExtraImageSelection);
        document.documentElement.appendChild(meshVaultExtraPickerBar);
    }
    meshVaultExtraPickerBar.style.display = "block";
    document.addEventListener("contextmenu", handleMeshVaultExtraImageContextMenu, true);
    document.addEventListener("keydown", handleMeshVaultExtraImageKeydown, true);
    markMeshVaultDefaultThumbnail();
}

function stopMeshVaultExtraImagePicker(clearSelection) {
    meshVaultExtraPickerActive = false;
    document.removeEventListener("contextmenu", handleMeshVaultExtraImageContextMenu, true);
    document.removeEventListener("keydown", handleMeshVaultExtraImageKeydown, true);
    if (clearSelection) clearMeshVaultExtraImageSelection();
    clearMeshVaultDefaultThumbnailMarkers();
    if (meshVaultExtraPickerBar) meshVaultExtraPickerBar.style.display = "none";
    notifyMeshVaultExtraImageSelectionChanged();
}

function clearMeshVaultExtraImageSelection() {
    meshVaultSelectedExtraImages.clear();
    document.querySelectorAll(".meshvault-extra-image-selected").forEach((node) => {
        node.classList.remove("meshvault-extra-image-selected");
    });
    updateMeshVaultExtraImageFeedback("Selection cleared.");
    notifyMeshVaultExtraImageSelectionChanged();
}

function markMeshVaultDefaultThumbnail() {
    clearMeshVaultDefaultThumbnailMarkers();
    meshVaultDefaultThumbnailUrl = getMeshVaultDefaultThumbnailUrl();
    updateMeshVaultDefaultThumbnailPreview(meshVaultDefaultThumbnailUrl);
    updateMeshVaultExtraImageFeedback(
        meshVaultDefaultThumbnailUrl
            ? "Default thumbnail preview shown. Right-click page images to add extras."
            : "Selection mode is on. Right-click images to add them."
    );
}

function clearMeshVaultDefaultThumbnailMarkers() {
    meshVaultDefaultThumbnailUrl = "";
    updateMeshVaultDefaultThumbnailPreview("");
}

function updateMeshVaultDefaultThumbnailPreview(url) {
    if (!meshVaultDefaultThumbnailPreview) return;
    const image = meshVaultDefaultThumbnailPreview.querySelector("img");
    if (!url || !image) {
        meshVaultDefaultThumbnailPreview.style.display = "none";
        if (image) image.removeAttribute("src");
        return;
    }
    image.src = url;
    meshVaultDefaultThumbnailPreview.style.display = "flex";
}

function getMeshVaultDefaultThumbnailUrl() {
    try {
        const rawMeta = typeof window.MeshVaultScrape === "function" ? window.MeshVaultScrape() : "";
        const thumbnail = rawMeta?.split("|||")?.[1] || "";
        return normalizeMeshVaultComparableUrl(thumbnail)
            || normalizeMeshVaultComparableUrl(document.querySelector('meta[property="og:image"]')?.content)
            || normalizeMeshVaultComparableUrl(document.querySelector('meta[name="twitter:image"]')?.content)
            || normalizeMeshVaultComparableUrl(document.querySelector('link[rel="image_src"]')?.href);
    } catch (_) {
        return "";
    }
}

function handleMeshVaultExtraImageKeydown(event) {
    if (event.key === "Escape") {
        stopMeshVaultExtraImagePicker(false);
    }
}

function handleMeshVaultExtraImageContextMenu(event) {
    if (!meshVaultIsEnabled()) return;
    if (!meshVaultExtraPickerActive) return;
    if (event.target?.closest?.("#meshvault-extra-image-picker")) return;

    const target = findMeshVaultImageTarget(event);
    if (target?.isGif) {
        event.preventDefault();
        event.stopPropagation();
        event.stopImmediatePropagation();
        updateMeshVaultExtraImageFeedback("GIFs cannot be added as extra images.");
        return;
    }
    if (!target?.url) return;

    event.preventDefault();
    event.stopPropagation();
    event.stopImmediatePropagation();

    if (meshVaultSelectedExtraImages.has(target.url)) {
        meshVaultSelectedExtraImages.delete(target.url);
        target.element?.classList?.remove("meshvault-extra-image-selected");
        updateMeshVaultExtraImageFeedback("Image removed.");
    } else {
        if (meshVaultSelectedExtraImages.size >= MESHVAULT_EXTRA_IMAGE_LIMIT) {
            updateMeshVaultExtraImageFeedback(`Limit reached. Remove one before adding another.`);
            return;
        }
        meshVaultSelectedExtraImages.add(target.url);
        target.element?.classList?.add("meshvault-extra-image-selected");
        updateMeshVaultExtraImageFeedback("Image added. Select more or click Done, then download.");
    }
    notifyMeshVaultExtraImageSelectionChanged();
}

function findMeshVaultImageTarget(event) {
    const path = event.composedPath ? event.composedPath() : [];
    for (const node of path) {
        if (!(node instanceof Element)) continue;
        const image = node.matches?.("img") ? node : node.querySelector?.("img");
        if (image) {
            const url = normalizeMeshVaultImageUrl(bestMeshVaultImageUrl(image));
            if (url) return { url, element: image };
            if (isMeshVaultGifUrl(bestMeshVaultImageUrl(image))) return { isGif: true, element: image };
        }
        const backgroundUrl = normalizeMeshVaultImageUrl(extractMeshVaultBackgroundUrl(node));
        if (backgroundUrl) return { url: backgroundUrl, element: node };
        if (isMeshVaultGifUrl(extractMeshVaultBackgroundUrl(node))) return { isGif: true, element: node };
    }
    return null;
}

function bestMeshVaultImageUrl(image) {
    if (!image) return "";
    const fromSrcset = bestMeshVaultSrcsetUrl(image.getAttribute("srcset"));
    return image.currentSrc || fromSrcset || image.src || image.getAttribute("src") || "";
}

function bestMeshVaultSrcsetUrl(srcset) {
    if (!srcset) return "";
    return srcset.split(",")
        .map((part) => {
            const [url, descriptor] = part.trim().split(/\s+/);
            let score = 1;
            if (descriptor?.endsWith("w")) score = parseInt(descriptor, 10) || 1;
            if (descriptor?.endsWith("x")) score = (parseFloat(descriptor) || 1) * 1000;
            return { url, score };
        })
        .sort((a, b) => b.score - a.score)[0]?.url || "";
}

function extractMeshVaultBackgroundUrl(element) {
    const inline = element.getAttribute?.("style") || "";
    const customMatch = inline.match(/--(?:bg-)?image:\s*url\((['"]?)(.*?)\1\)/i);
    if (customMatch?.[2]) return customMatch[2];

    const background = window.getComputedStyle(element).backgroundImage || "";
    const match = background.match(/url\((['"]?)(.*?)\1\)/i);
    return match?.[2] || "";
}

function normalizeMeshVaultImageUrl(url) {
    if (!url || typeof url !== "string") return "";
    const trimmed = url.trim();
    if (!trimmed || trimmed.startsWith("data:") || trimmed.startsWith("blob:")) return "";
    try {
        const absolute = new URL(trimmed, window.location.href).toString();
        if (isMeshVaultGifUrl(absolute)) return "";
        if (!/\.(png|jpe?g|webp)(\?|#|$)/i.test(absolute)) return "";
        if (absolute.toLowerCase().endsWith(".svg")) return "";
        return absolute;
    } catch (_) {
        return "";
    }
}

function isMeshVaultGifUrl(url) {
    if (!url || typeof url !== "string") return false;
    try {
        const parsed = new URL(url.trim(), window.location.href);
        return parsed.pathname.toLowerCase().endsWith(".gif");
    } catch (_) {
        return /\.gif(?:[?#]|$)/i.test(url);
    }
}

function normalizeMeshVaultComparableUrl(url) {
    if (!url || typeof url !== "string") return "";
    const trimmed = url.trim();
    if (!trimmed || trimmed.startsWith("data:") || trimmed.startsWith("blob:")) return "";
    try {
        const parsed = new URL(trimmed, window.location.href);
        if (parsed.pathname.toLowerCase().endsWith(".svg")) return "";
        return parsed.toString();
    } catch (_) {
        return "";
    }
}


function updateMeshVaultExtraImageFeedback(message) {
    if (meshVaultExtraPickerCount) {
        meshVaultExtraPickerCount.textContent = `${meshVaultSelectedExtraImages.size}/${MESHVAULT_EXTRA_IMAGE_LIMIT}`;
    }
    if (meshVaultExtraPickerHint && message) {
        meshVaultExtraPickerHint.textContent = message;
    }
}

function notifyMeshVaultExtraImageSelectionChanged() {
    if (!meshVaultIsEnabled()) return;
    chrome.runtime.sendMessage({
        action: "extraImagesSelectionChanged",
        pageUrl: window.location.href,
        urls: Array.from(meshVaultSelectedExtraImages).slice(0, MESHVAULT_EXTRA_IMAGE_LIMIT)
    });
}

const meshVaultThingiverseRecentDownloads = new Map();

const decodeThingiverseOfn = (value) => {
    if (!value) return "";
    try {
        return decodeURIComponent(escape(atob(value)));
    } catch (_) {
        try {
            return atob(value);
        } catch (_) {
            return "";
        }
    }
};

const normalizeThingiverseDownloadUrl = (value) => {
    if (!value || typeof value !== "string") return "";
    const trimmed = value.trim().replace(/\\\//g, "/").replace(/&amp;/g, "&");
    if (!trimmed || trimmed.startsWith("blob:") || trimmed.startsWith("data:")) return "";
    const urlMatch = trimmed.match(/https?:\/\/[^"'<>\\\s]*(?:thingiverse\.com\/download:|cdn\.thingiverse\.com\/assets\/)[^"'<>\\\s]*/i);
    const candidate = urlMatch ? urlMatch[0] : trimmed;
    if (!/thingiverse\.com\/download:|cdn\.thingiverse\.com\/assets\//i.test(candidate)) return "";
    try {
        return new URL(candidate, window.location.origin).toString();
    } catch (_) {
        return "";
    }
};

const extractThingiverseDownloadId = (value, name = "") => {
    if (!value || typeof value !== "string") return "";
    const trimmed = value.trim();
    const direct = trimmed.match(/(?:thingiverse\.com\/download:|\/download:|download:)(\d{3,})/i);
    if (direct) return direct[1];
    const hint = `${name} ${trimmed}`.toLowerCase();
    if (!/(file|download|item|thing)/.test(hint)) return "";
    const named = trimmed.match(/(?:file[_-]?id|fileId|thingFileId|thingiverseFileId|download[_-]?id|downloadId|item[_-]?id|itemId)["'\s:=]+(\d{3,})/i);
    if (named) return named[1];
    if (/^(?:data-)?(?:file|download|item|thing)[a-z0-9_-]*id$/i.test(name) && /^\d{3,}$/.test(trimmed)) {
        return trimmed;
    }
    return "";
};

const getThingiverseFilenameFromText = (value) => {
    if (!value || typeof value !== "string") return "";
    const cleaned = value.replace(/\s+/g, " ").trim();
    const fileMatch = cleaned.match(/[\w .()[\]-]+\.(?:3mf|stl|obj|step|stp|scad|f3d|iges|igs|zip|rar|7z|gcode|bgcode)\b/i);
    return fileMatch ? fileMatch[0].trim() : "";
};

const collectThingiverseCandidateNodes = (event, button) => {
    const nodes = [];
    const add = (node) => {
        if (node && node.nodeType === Node.ELEMENT_NODE && !nodes.includes(node)) nodes.push(node);
    };

    add(button);
    const path = event?.composedPath ? event.composedPath() : [];
    for (const node of path) {
        add(node);
        if (node === document.body) break;
    }

    const containers = [
        button?.closest?.("li"),
        button?.closest?.("tr"),
        button?.closest?.("[role='listitem']"),
        button?.closest?.("[class*='file' i]"),
        button?.closest?.("[class*='download' i]"),
        button?.closest?.("[data-item-id], [data-file-id], [data-download-id]"),
        button?.parentElement
    ];

    for (const container of containers) {
        add(container);
        const descendants = Array.from(container?.querySelectorAll?.("a, button, [href], [download], [data-item-id], [data-file-id], [data-download-id], [data-id]") || []).slice(0, 250);
        descendants.forEach(add);
    }

    return nodes;
};

const findThingiverseDownloadTarget = (event, button) => {
    if (!button) return null;
    const nodes = collectThingiverseCandidateNodes(event, button);
    let id = "";
    let filename = "";

    for (const node of nodes) {
        if (!filename) {
            filename = getThingiverseFilenameFromText(node.getAttribute?.("aria-label")?.replace(/^download\s+/i, "") || "")
                || getThingiverseFilenameFromText(node.getAttribute?.("download") || "")
                || getThingiverseFilenameFromText(node.textContent || "");
        }

        if (node instanceof HTMLAnchorElement) {
            const direct = normalizeThingiverseDownloadUrl(node.href || node.getAttribute("href") || "");
            if (direct) return { url: direct, filename: filename || getThingiverseFilenameFromUrl(direct) };
        }

        for (const { name, value } of Array.from(node.attributes || [])) {
            const direct = normalizeThingiverseDownloadUrl(value);
            if (direct) return { url: direct, filename: filename || getThingiverseFilenameFromUrl(direct) };
            if (!id) id = extractThingiverseDownloadId(value, name);
            if (!filename && /download|filename|file/i.test(name)) filename = getThingiverseFilenameFromText(value);
        }

        for (const [name, value] of Object.entries(node.dataset || {})) {
            const direct = normalizeThingiverseDownloadUrl(value);
            if (direct) return { url: direct, filename: filename || getThingiverseFilenameFromUrl(direct) };
            if (!id) id = extractThingiverseDownloadId(value, name);
        }
    }

    if (id) {
        return {
            url: `https://www.thingiverse.com/download:${id}`,
            filename: filename || ""
        };
    }

    return null;
};

const getThingiverseFilenameFromUrl = (url) => {
    try {
        const parsed = new URL(url, window.location.origin);
        const ofn = parsed.searchParams.get("ofn");
        if (ofn) return decodeThingiverseOfn(ofn);
        const leaf = parsed.pathname.split("/").filter(Boolean).pop() || "";
        return getThingiverseFilenameFromText(leaf);
    } catch (_) {
        return "";
    }
};

const shouldSkipThingiverseDuplicate = (url, filename) => {
    const key = `${url}|${filename || ""}`;
    const now = Date.now();
    const previous = meshVaultThingiverseRecentDownloads.get(key) || 0;
    meshVaultThingiverseRecentDownloads.set(key, now);
    for (const [existingKey, timestamp] of meshVaultThingiverseRecentDownloads) {
        if (now - timestamp > 5000) meshVaultThingiverseRecentDownloads.delete(existingKey);
    }
    return now - previous < 1500;
};

const sendThingiverseDownloadToMeshVault = (event, target) => {
    if (!meshVaultIsEnabled()) return false;
    if (!target?.url) return false;
    const filename = target.filename || getThingiverseFilenameFromUrl(target.url) || "";
    const isDuplicate = shouldSkipThingiverseDuplicate(target.url, filename);

    event.preventDefault();
    event.stopPropagation();
    event.stopImmediatePropagation?.();
    if (isDuplicate) return true;

    const rawMeta = typeof window.MeshVaultScrape === "function"
        ? window.MeshVaultScrape()
        : "";
    console.log("MeshVault Thingiverse: intercept download", { filename, url: target.url });
    chrome.runtime.sendMessage({
        action: "uploadToMeshVault",
        url: target.url,
        filename,
        metadata: rawMeta
    });
    return true;
};

const findThingiverseDownloadButton = (event) => {
    const path = event.composedPath ? event.composedPath() : [];
    for (const node of path) {
        if (!node || !node.getAttribute) continue;
        const label = node.getAttribute("aria-label");
        if (label && label.toLowerCase().startsWith("download ")) {
            return node;
        }
    }
    return event.target?.closest?.("button[aria-label^='Download '], button[aria-label^='download ']");
};

const handleThingiverseFileDownload = (event) => {
    try {
        if (!meshVaultIsEnabled()) return;
        if (!window.location.hostname.includes("thingiverse.com")) return;
        const button = findThingiverseDownloadButton(event);
        if (!button) return;
        const target = findThingiverseDownloadTarget(event, button);
        if (!target?.url) {
            console.log("MeshVault Thingiverse: download button clicked, no direct target found", button);
            return;
        }

        sendThingiverseDownloadToMeshVault(event, target);
    } catch (_) {
        // No-op
    }
};

document.addEventListener("click", (event) => {
    try {
        if (!meshVaultIsEnabled()) return;
        if (!window.location.hostname.includes("thingiverse.com")) return;
        const target = event.target;
        const button = target?.closest?.("button, a");
        if (!button) return;
        const labelNode = button.querySelector("span.button-content");
        const text = (labelNode?.textContent || button.textContent || "").trim().toLowerCase();
        if (text === "download all files") {
            event.preventDefault();
            event.stopPropagation();

            chrome.runtime.sendMessage({
                action: "thingiverseDownloadAll",
                pageUrl: window.location.href,
                fallbackTitle: document.title || ""
            });
            return;
        }

    } catch (_) {
        // No-op
    }
}, true);


// Cults3D download button handler
function getCultsRawMeta() {
    return typeof window.MeshVaultScrape === "function"
        ? window.MeshVaultScrape()
        : "";
}

function cacheCultsRawMeta(rawMeta) {
    if (!rawMeta) return;
    chrome.runtime.sendMessage({
        action: "cacheCultsMeta",
        rawMeta,
        pageUrl: rawMeta?.sourceUrl || window.location.href
    });
}

function cacheCultsOrderMeta(orderUrl, rawMeta = getCultsRawMeta()) {
    if (!orderUrl || !rawMeta) return;
    chrome.runtime.sendMessage({
        action: "cacheCultsOrderMeta",
        orderUrl: new URL(orderUrl, window.location.origin).toString(),
        rawMeta,
        pageUrl: rawMeta?.sourceUrl || window.location.href
    });
}

function isCultsDownloadUrl(value) {
    if (!value || typeof value !== "string") return false;
    try {
        const url = new URL(value, window.location.origin);
        const host = url.hostname.toLowerCase();
        const path = url.pathname.toLowerCase();
        if (host.includes("downloader.cults3d.com") || host.includes("download.cults3d.com")) return true;
        if (!host.includes("cults3d.com")) return false;
        return path.includes("/downloads/") || path.includes("/download/");
    } catch (_) {
        return false;
    }
}

function isCultsOrderUrl(value) {
    if (!value || typeof value !== "string") return false;
    try {
        const url = new URL(value, window.location.origin);
        return url.hostname.toLowerCase().includes("cults3d.com")
            && /\/orders\/\d+/i.test(url.pathname);
    } catch (_) {
        return false;
    }
}

function findCultsOrderTarget(event) {
    const path = event.composedPath ? event.composedPath() : [];
    for (const node of path) {
        if (!node || node.nodeType !== Node.ELEMENT_NODE) continue;
        const candidates = [
            node.getAttribute?.("href"),
            node.getAttribute?.("data-href"),
            node.getAttribute?.("data-url")
        ];
        if (node instanceof HTMLAnchorElement && node.href) candidates.push(node.href);
        for (const candidate of candidates) {
            if (isCultsOrderUrl(candidate)) return new URL(candidate, window.location.origin).toString();
        }
    }
    return "";
}

function cacheVisibleCultsOrderLinks() {
    if (!meshVaultIsEnabled()) return;
    if (!window.location.hostname.includes("cults3d.com")) return;
    if (!window.location.pathname.includes("/3d-model/")) return;
    const rawMeta = getCultsRawMeta();
    if (!rawMeta) return;
    document.querySelectorAll("a[href*='/orders/']").forEach((link) => {
        const href = link.getAttribute("href") || link.href || "";
        if (isCultsOrderUrl(href)) cacheCultsOrderMeta(href, rawMeta);
    });
}

if (window.location.hostname.includes("cults3d.com") && window.location.pathname.includes("/3d-model/") && !window.__meshVaultCultsOrderObserver) {
    window.__meshVaultCultsOrderObserver = true;
    setTimeout(cacheVisibleCultsOrderLinks, 600);
    const observer = new MutationObserver(() => cacheVisibleCultsOrderLinks());
    observer.observe(document.body, { childList: true, subtree: true });
}

function shouldLetChromeHandleCultsDownload(url) {
    try {
        const parsed = new URL(url, window.location.origin);
        const host = parsed.hostname.toLowerCase();
        const path = parsed.pathname.toLowerCase();
        return host.includes("cults3d.com")
            && !host.includes("download.cults3d.com")
            && !host.includes("downloader.cults3d.com")
            && (path.includes("/downloads/") || path.includes("/download/"));
    } catch (_) {
        return false;
    }
}

function findCultsDownloadTarget(event) {
    const nodes = [];
    const add = (node) => {
        if (node && node.nodeType === Node.ELEMENT_NODE && !nodes.includes(node)) nodes.push(node);
    };

    const path = event.composedPath ? event.composedPath() : [];
    path.forEach(add);
    add(event.target?.closest?.("a[href]"));
    add(event.target?.closest?.("form[action]"));
    add(event.target?.closest?.("[href], [data-href], [data-url], [data-download-url], [formaction]"));

    for (const node of nodes) {
        const candidates = [
            node.getAttribute?.("href"),
            node.getAttribute?.("action"),
            node.getAttribute?.("formaction"),
            node.getAttribute?.("data-href"),
            node.getAttribute?.("data-url"),
            node.getAttribute?.("data-download-url")
        ];

        if (node instanceof HTMLButtonElement && node.formAction) candidates.push(node.formAction);
        if (node instanceof HTMLAnchorElement && node.href) candidates.push(node.href);
        if (node instanceof HTMLFormElement && node.action) candidates.push(node.action);

        for (const candidate of candidates) {
            if (!isCultsDownloadUrl(candidate)) continue;
            return new URL(candidate, window.location.origin).toString();
        }
    }

    return "";
}

document.addEventListener("click", (event) => {
    try {
        if (!meshVaultIsEnabled()) return;
        if (!window.location.hostname.includes("cults3d.com")) return;
        const target = event.target;
        const downloadControl = target?.closest?.("a, button, [role='menuitem'], [role='button'], [data-action], [data-controller]");
        if (downloadControl) {
            const label = [
                downloadControl.getAttribute?.("aria-label") || "",
                downloadControl.getAttribute?.("title") || "",
                downloadControl.textContent || ""
            ].join(" ").toLowerCase();
            if (label.includes("download")) cacheCultsRawMeta(getCultsRawMeta());
        }

        const freeForm = target?.closest?.("form.button_to");
        if (freeForm) {
            const action = freeForm.getAttribute("action") || "";
            if (action.startsWith("/en/free_orders")) {
                cacheCultsRawMeta(getCultsRawMeta());
            }
        }

        const orderUrl = findCultsOrderTarget(event);
        if (orderUrl) {
            cacheCultsOrderMeta(orderUrl);
            return;
        }

        const absoluteUrl = findCultsDownloadTarget(event);
        if (!absoluteUrl) return;
        if (shouldLetChromeHandleCultsDownload(absoluteUrl)) {
            cacheCultsRawMeta(getCultsRawMeta());
            return;
        }

        event.preventDefault();
        event.stopPropagation();
        event.stopImmediatePropagation?.();
        const rawMeta = getCultsRawMeta();
        chrome.runtime.sendMessage({
            action: "debugCultsDownloadClick",
            downloadUrl: absoluteUrl,
            metaLength: rawMeta?.length || 0
        });
        cacheCultsRawMeta(rawMeta);
        chrome.runtime.sendMessage({
            action: "cultsDownload",
            downloadUrl: absoluteUrl,
            pageUrl: rawMeta?.sourceUrl || window.location.href,
            fallbackTitle: document.title || ""
        });
    } catch (_) {
        // No-op
    }
}, true);

document.addEventListener("submit", (event) => {
    try {
        if (!meshVaultIsEnabled()) return;
        if (!window.location.hostname.includes("cults3d.com")) return;
        const form = event.target;
        if (!form || form.nodeName !== "FORM") return;
        const downloadUrl = isCultsDownloadUrl(form.getAttribute("action") || "")
            ? new URL(form.getAttribute("action") || "", window.location.origin).toString()
            : "";
        if (downloadUrl) {
            if (shouldLetChromeHandleCultsDownload(downloadUrl)) {
                cacheCultsRawMeta(getCultsRawMeta());
                return;
            }

            event.preventDefault();
            event.stopPropagation();
            event.stopImmediatePropagation?.();
            const rawMeta = getCultsRawMeta();
            cacheCultsRawMeta(rawMeta);
            chrome.runtime.sendMessage({
                action: "cultsDownload",
                downloadUrl,
                pageUrl: rawMeta?.sourceUrl || window.location.href,
                fallbackTitle: document.title || ""
            });
            return;
        }

        if (!form.classList.contains("button_to")) return;
        const action = form.getAttribute("action") || "";
        if (!action.startsWith("/en/free_orders")) return;
        cacheCultsRawMeta(getCultsRawMeta());
    } catch (_) {
        // No-op
    }
}, true);















if (window.location.hostname.includes("grabcad.com")) {
    const grabcadAdSelectors = [
        ".gc-shared-asense-card__box",
        ".gc-adsense-container",
        ".gc_shared-asense__ignore-target",
        ".gc-shared-asense-card__info-link",
        "ins.adsbygoogle",
        "iframe[src*='doubleclick']",
        "iframe[src*='googlesyndication']"
    ];

    const HIDE_CLASS = "meshvault-hidden";

    const ensureGrabCadHideStyle = () => {
        if (document.getElementById("meshvault-hide-style-grabcad")) return;
        const style = document.createElement("style");
        style.id = "meshvault-hide-style-grabcad";
        style.textContent = `.${HIDE_CLASS} { display: none !important; }`;
        document.head.appendChild(style);
    };

    const hideNodes = (nodes) => {
        ensureGrabCadHideStyle();
        nodes.forEach((node) => {
            if (!node) return;
            node.classList.add(HIDE_CLASS);
        });
    };

    const removeGrabCadAds = () => {
        grabcadAdSelectors.forEach((selector) => {
            hideNodes(document.querySelectorAll(selector));
        });
        document.querySelectorAll(".modelCard").forEach((card) => {
            const text = (card.textContent || "").toLowerCase();
            if (!text.includes("advertisement")) return;
            hideNodes([card]);
        });
        document.querySelectorAll(".gc_shared-asense__ignore-target span").forEach((span) => {
            const text = (span.textContent || "").toLowerCase();
            if (!text.includes("advertisement")) return;
            const card = span.closest(".modelCard");
            if (card) hideNodes([card]);
        });
    };

    removeGrabCadAds();

    if (!window.__meshVaultGrabCadAdObserver) {
        window.__meshVaultGrabCadAdObserver = true;
        const observer = new MutationObserver(() => {
            removeGrabCadAds();
        });
        observer.observe(document.body, { childList: true, subtree: true });
    }
}
if (window.location.hostname.includes("cults3d.com")) {
    const cultsAdSelectors = [
        "#zone-home-selected",
        "[id^='zone-']",
        "[data-zone='true']",
        "[data-zone-publift]",
        "[id^='publift-']",
        ".cultszone",
        ".fuse-slot-comboZone",
        ".fuse-slot",
        "[id*='google_ads_iframe']",
        "iframe[src*='googlesyndication']",
        "iframe[src*='doubleclick']"
    ];

    const HIDE_CLASS = "meshvault-hidden";

    const ensureCultsHideStyle = () => {
        if (document.getElementById("meshvault-hide-style-cults")) return;
        const style = document.createElement("style");
        style.id = "meshvault-hide-style-cults";
        const selectorCss = cultsAdSelectors.map((selector) => `${selector}{display:none!important;visibility:hidden!important;pointer-events:none!important;}`).join("\n");
        style.textContent = `.${HIDE_CLASS} { display: none !important; visibility: hidden !important; pointer-events: none !important; }\n${selectorCss}`;
        document.head.appendChild(style);
    };

    const applyCultsHide = (node) => {
        if (!node || node.nodeType !== 1) return;
        node.classList.add(HIDE_CLASS);
        node.style.setProperty("display", "none", "important");
        node.style.setProperty("visibility", "hidden", "important");
        node.style.setProperty("pointer-events", "none", "important");
        node.style.setProperty("height", "0px", "important");
        node.style.setProperty("min-height", "0px", "important");
        node.style.setProperty("max-height", "0px", "important");
        node.style.setProperty("overflow", "hidden", "important");
    };

    const hideNodes = (nodes) => {
        ensureCultsHideStyle();
        nodes.forEach((node) => {
            if (!node) return;
            applyCultsHide(node);
        });
    };

    const removeCultsAds = () => {
        cultsAdSelectors.forEach((selector) => {
            hideNodes(document.querySelectorAll(selector));
        });
        hideNodes(document.querySelectorAll(`.${HIDE_CLASS}`));
    };

    removeCultsAds();

    if (!window.__meshVaultCultsAdObserver) {
        window.__meshVaultCultsAdObserver = true;
        const observer = new MutationObserver(() => {
            removeCultsAds();
        });
        observer.observe(document.body, { childList: true, subtree: true });
    }
}
if (window.location.hostname.includes("thingiverse.com")) {
    const thingiverseAdSelectors = [
        "#google_vignette",
        "[id*='google_vignette']",
        "iframe[src*='google_vignette']",
        "a[href*='google_vignette']",
        "#gpt_unit",
        "[id*='gpt_unit_']",
        "ins[id^='gpt_unit_']",
        "ins[data-vignette-loaded='true']",
        "#google_ads_iframe",
        "[id*='google_ads']",
        "[id*='ad_']",
        "[class*='ad-']",
        "[class*='ads-']",
        "[class*='adunit']",
        "[class*='ad-unit']",
        ".ad",
        ".ads",
        ".ad-banner",
        ".banner-ad",
        ".adsbygoogle",
        "iframe[src*='doubleclick']",
        "iframe[src*='googlesyndication']",
        "iframe[src*='ads']",
        ".AdCard__adCard--NT3P6",
        ".AdCard__adCard",
        ".item-card-container.AdCard__adCard--NT3P6",
        ".AdBanner__adBanner--GpB5d",
        ".Card__card--k0alX.AdBanner__adBanner--GpB5d"
    ];

    const aiBadgeSelectors = [
        ".ItemCardBadge__cardBadge--ai",
        "[class*='cardBadge--ai']"
    ];

    const HIDE_CLASS = "meshvault-hidden";
    let aiBlockEnabled = false;

    const ensureThingiverseHideStyle = () => {
        if (document.getElementById("meshvault-hide-style-thingiverse")) return;
        const style = document.createElement("style");
        style.id = "meshvault-hide-style-thingiverse";
        style.textContent = `
            .${HIDE_CLASS} { display: none !important; }
            #google_vignette, [id*="google_vignette"] { display: none !important; }
            iframe[src*="google_vignette"] { display: none !important; }
            .HomePageBanner__homeBanner--vmVQg { display: none !important; }
            [class*="HomePageBanner__homeBanner"] { display: none !important; }
        `;
        document.head.appendChild(style);
    };

    const hideNodes = (nodes) => {
        ensureThingiverseHideStyle();
        nodes.forEach((node) => {
            if (!node) return;
            node.classList.add(HIDE_CLASS);
            // Inline !important beats stylesheet !important, so set inline overrides too.
            try {
                node.style.setProperty("display", "none", "important");
                node.style.setProperty("visibility", "hidden", "important");
                node.style.setProperty("pointer-events", "none", "important");
                node.style.setProperty("width", "0", "important");
                node.style.setProperty("height", "0", "important");
            } catch (_) {
                // No-op
            }
        });
    };

    const removeThingiverseAds = () => {
        thingiverseAdSelectors.forEach((selector) => {
            hideNodes(document.querySelectorAll(selector));
        });
    };

    const clearVignetteHash = () => {
        if (window.location.hash && window.location.hash.includes("google_vignette")) {
            history.replaceState(null, "", window.location.pathname + window.location.search);
        }
    };

    const removeThingiverseAI = () => {
        if (!aiBlockEnabled) return;
        aiBadgeSelectors.forEach((selector) => {
            document.querySelectorAll(selector).forEach((badge) => {
                const card = badge.closest(".item-card-container");
                if (card) hideNodes([card]);
            });
        });
        document.querySelectorAll(".ItemCardHeader__itemCardMeta--Mtzoe").forEach((meta) => {
            const text = (meta.textContent || "").toLowerCase();
            if (!text.includes("ai generated")) return;
            const card = meta.closest(".item-card-container");
            if (card) hideNodes([card]);
        });
    };

    chrome.storage.local.get({ blockAIGenerated: null, blockAIGeneratedThingiverse: null }, (result) => {
        aiBlockEnabled = Boolean(result.blockAIGenerated ?? result.blockAIGeneratedThingiverse);
        removeThingiverseAds();
        clearVignetteHash();
        removeThingiverseAI();
    });

    chrome.storage.onChanged.addListener((changes, area) => {
        if (area !== "local") return;
        if (!Object.prototype.hasOwnProperty.call(changes, "blockAIGenerated")
            && !Object.prototype.hasOwnProperty.call(changes, "blockAIGeneratedThingiverse")) {
            return;
        }
        aiBlockEnabled = Boolean(changes.blockAIGenerated?.newValue ?? changes.blockAIGeneratedThingiverse?.newValue);
        removeThingiverseAI();
    });

    window.addEventListener("hashchange", clearVignetteHash);

    if (!window.__meshVaultThingiverseAdObserver) {
        window.__meshVaultThingiverseAdObserver = true;
        const observer = new MutationObserver(() => {
            removeThingiverseAds();
            clearVignetteHash();
            removeThingiverseAI();
        });
        observer.observe(document.body, { childList: true, subtree: true });
    }
}

if (window.location.hostname.includes("printables.com")) {
    const printablesSelectors = [
        ".cky-consent-container",
        ".cky-overlay",
        ".cky-modal",
		"modal-backdrop fade show",
//       "div[role='dialog']" Needed for settings
    ];

    const HIDE_CLASS = "meshvault-hidden";
    let aiBlockEnabled = false;

    const ensurePrintablesHideStyle = () => {
        if (document.getElementById("meshvault-hide-style-printables")) return;
        const style = document.createElement("style");
        style.id = "meshvault-hide-style-printables";
        style.textContent = `.${HIDE_CLASS} { display: none !important; }`;
        document.head.appendChild(style);
    };

    const hideNodes = (nodes) => {
        ensurePrintablesHideStyle();
        nodes.forEach((node) => {
            if (!node) return;
            node.classList.add(HIDE_CLASS);
            try {
                node.style.setProperty("display", "none", "important");
                node.style.setProperty("visibility", "hidden", "important");
                node.style.setProperty("pointer-events", "none", "important");
            } catch (_) {
                // No-op
            }
        });
    };

    const removePrintablesOverlays = () => {
        printablesSelectors.forEach((selector) => {
            hideNodes(document.querySelectorAll(selector));
        });
    };

    const findAiCheckbox = () => {
        const labels = Array.from(document.querySelectorAll("label"));
        const targetLabel = labels.find((label) => {
            const text = (label.textContent || "").trim().toLowerCase();
            return text === "exclude ai generated";
        });
        if (!targetLabel) return null;
        const forId = targetLabel.getAttribute("for");
        if (forId) {
            return document.getElementById(forId);
        }
        return targetLabel.closest("div")?.querySelector("input[type='checkbox']") || null;
    };

    const applyPrintablesAiFilter = () => {
        if (!aiBlockEnabled) return;
        const checkbox = findAiCheckbox();
        if (!checkbox || checkbox.checked) return;
        checkbox.click();
    };

    removePrintablesOverlays();
    chrome.storage.local.get({ blockAIGenerated: null, blockAIGeneratedThingiverse: null }, (result) => {
        aiBlockEnabled = Boolean(result.blockAIGenerated ?? result.blockAIGeneratedThingiverse);
        applyPrintablesAiFilter();
    });

    chrome.storage.onChanged.addListener((changes, area) => {
        if (area !== "local") return;
        if (!Object.prototype.hasOwnProperty.call(changes, "blockAIGenerated")
            && !Object.prototype.hasOwnProperty.call(changes, "blockAIGeneratedThingiverse")) {
            return;
        }
        aiBlockEnabled = Boolean(changes.blockAIGenerated?.newValue ?? changes.blockAIGeneratedThingiverse?.newValue);
        applyPrintablesAiFilter();
    });

    if (!window.__meshVaultPrintablesObserver) {
        window.__meshVaultPrintablesObserver = true;
        const observer = new MutationObserver(() => {
            removePrintablesOverlays();
            applyPrintablesAiFilter();
        });
        observer.observe(document.body, { childList: true, subtree: true });
    }
}





