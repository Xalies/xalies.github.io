(function () {
    if (window.__meshVaultThingiverseBridge) return;
    window.__meshVaultThingiverseBridge = true;

    const BRIDGE_SOURCE = "MeshVaultThingiverseBridge";
    const RECENT_CLICK_MS = 4000;
    const BLOB_CHUNK_BYTES = 256 * 1024;
    const modelFilePattern = /[\w .()[\]-]+\.(?:3mf|stl|obj|step|stp|scad|f3d|iges|igs|zip|rar|7z|gcode|bgcode)\b/i;
    let pendingClick = null;
    let lastSelectedFilename = { value: "", ts: 0 };
    let lastPosted = { key: "", ts: 0 };
    let meshVaultEnabled = true;
    const blobByUrl = new Map();
    const sendingBlobUrls = new Set();

    const now = () => Date.now();

    const isRecentClick = () => pendingClick && now() - pendingClick.ts < RECENT_CLICK_MS;
    const isEnabled = () => meshVaultEnabled !== false;

    window.addEventListener("message", (event) => {
        try {
            if (event.source !== window) return;
            const data = event.data || {};
            if (data.source !== "MeshVaultConnect" || data.type !== "meshvault-enabled") return;
            meshVaultEnabled = data.enabled !== false;
            if (!meshVaultEnabled) {
                pendingClick = null;
                sendingBlobUrls.clear();
            }
        } catch (_) {
            // No-op
        }
    });

    const getFilenameFromText = (value) => {
        if (!value || typeof value !== "string") return "";
        const match = value.replace(/\s+/g, " ").match(modelFilePattern);
        return match ? match[0].trim() : "";
    };

    const isGenericDownloadFilename = (value) => /^(?:image|download|blob|file|thingiverse-download)\.(?:zip|stl|3mf|obj)?$/i.test(String(value || "").trim())
        || /^(?:image|download|blob|file|thingiverse-download)$/i.test(String(value || "").trim());

    const rememberSelectedFilename = (filename) => {
        if (!filename || isGenericDownloadFilename(filename)) return;
        lastSelectedFilename = { value: filename, ts: now() };
    };

    const getRecentSelectedFilename = () => (
        lastSelectedFilename.value && now() - lastSelectedFilename.ts < 60000
            ? lastSelectedFilename.value
            : ""
    );

    const chooseDownloadFilename = (...candidates) => {
        const selected = pendingClick?.filename || getRecentSelectedFilename();
        if (selected && !isGenericDownloadFilename(selected)) return selected;
        for (const candidate of candidates) {
            const filename = getFilenameFromText(candidate || "") || String(candidate || "").trim();
            if (filename && !isGenericDownloadFilename(filename)) return filename;
        }
        for (const candidate of candidates) {
            const filename = getFilenameFromText(candidate || "") || String(candidate || "").trim();
            if (filename) return filename;
        }
        return selected || "";
    };

    const getFilenameFromNode = (node) => {
        if (!node || node.nodeType !== Node.ELEMENT_NODE) return "";
        return getFilenameFromText((node.getAttribute("aria-label") || "").replace(/^download\s+/i, ""))
            || getFilenameFromText(node.getAttribute("download") || "")
            || getFilenameFromText(node.getAttribute("title") || "")
            || getFilenameFromText(node.textContent || "");
    };

    const getFilenameFromClickContext = (event, button) => {
        const path = event?.composedPath ? event.composedPath() : [];
        for (const node of path) {
            const filename = getFilenameFromNode(node);
            if (filename) return filename;
            if (node === document.body) break;
        }

        const containers = [
            button?.closest?.("li"),
            button?.closest?.("tr"),
            button?.closest?.("[role='listitem']"),
            button?.closest?.("[class*='file' i]"),
            button?.closest?.("[class*='download' i]"),
            button?.parentElement
        ];

        for (const container of containers) {
            const filename = getFilenameFromNode(container);
            if (filename) return filename;
            const candidates = Array.from(container?.querySelectorAll?.("[aria-label], [download], [title], span, div") || []).slice(0, 200);
            for (const candidate of candidates) {
                const nested = getFilenameFromNode(candidate);
                if (nested) return nested;
            }
        }

        return getNearestVisibleFilename(button);
    };

    const isVisibleElement = (element) => {
        if (!element || element.nodeType !== Node.ELEMENT_NODE) return false;
        const rect = element.getBoundingClientRect();
        if (rect.width <= 0 || rect.height <= 0) return false;
        const style = window.getComputedStyle(element);
        return style.visibility !== "hidden" && style.display !== "none" && Number(style.opacity || 1) > 0;
    };

    const getNearestVisibleFilename = (button) => {
        if (!button?.getBoundingClientRect) return "";
        const buttonRect = button.getBoundingClientRect();
        const buttonCenterX = buttonRect.left + buttonRect.width / 2;
        const buttonCenterY = buttonRect.top + buttonRect.height / 2;
        const candidates = [];
        const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_ELEMENT);

        while (walker.nextNode()) {
            const node = walker.currentNode;
            if (!isVisibleElement(node)) continue;

            const filename = getFilenameFromText(node.textContent || "");
            if (!filename) continue;

            const rect = node.getBoundingClientRect();
            const centerX = rect.left + rect.width / 2;
            const centerY = rect.top + rect.height / 2;
            const verticalDistance = Math.abs(centerY - buttonCenterY);
            const horizontalDistance = Math.abs(centerX - buttonCenterX);
            const sameRowBonus = verticalDistance <= Math.max(buttonRect.height, rect.height, 24) * 1.35 ? -2000 : 0;
            const aboveBelowPenalty = centerY > buttonCenterY ? 120 : 0;
            candidates.push({
                filename,
                score: sameRowBonus + verticalDistance * 16 + horizontalDistance + aboveBelowPenalty
            });
        }

        candidates.sort((left, right) => left.score - right.score);
        return candidates[0]?.filename || "";
    };

    const decodeOfn = (value) => {
        if (!value) return "";
        try {
            return decodeURIComponent(escape(atob(value)));
        } catch (_) {
            try {
                return atob(value);
            } catch (_) {
                return "";
            }
        }
    };

    const getFilenameFromUrl = (value) => {
        try {
            const parsed = new URL(value, window.location.href);
            const ofn = parsed.searchParams.get("ofn");
            if (ofn) return decodeOfn(ofn);
            return getFilenameFromText(parsed.pathname.split("/").filter(Boolean).pop() || "");
        } catch (_) {
            return "";
        }
    };

    const getFilenameFromDisposition = (value) => {
        if (!value) return "";
        const utf = value.match(/filename\*=UTF-8''([^;]+)/i);
        if (utf) {
            try {
                return decodeURIComponent(utf[1].replace(/"/g, ""));
            } catch (_) {
                return utf[1].replace(/"/g, "");
            }
        }
        const plain = value.match(/filename="?([^";]+)"?/i);
        return plain ? plain[1].trim() : "";
    };

    const normalizeDownloadUrl = (value) => {
        if (!value || typeof value !== "string") return "";
        const trimmed = value.trim().replace(/\\\//g, "/").replace(/&amp;/g, "&");
        if (!trimmed || trimmed.startsWith("blob:") || trimmed.startsWith("data:")) return "";
        if (isIgnoredRequestUrl(trimmed)) return "";
        const match = trimmed.match(/https?:\/\/[^"'<>\\\s]*(?:thingiverse\.com\/download:|cdn\.thingiverse\.com\/assets\/|api\.thingiverse\.com\/[^"'<>\\\s]*download)[^"'<>\\\s]*/i);
        const candidate = match ? match[0] : trimmed;
        if (!/(thingiverse\.com\/download:|cdn\.thingiverse\.com\/assets\/|api\.thingiverse\.com\/.*download)/i.test(candidate)) return "";
        try {
            return new URL(candidate, window.location.href).toString();
        } catch (_) {
            return "";
        }
    };

    const isThingiverseDownloadEndpoint = (value) => /thingiverse\.com\/download:|api\.thingiverse\.com\/[^"'<>\\\s]*download/i.test(value || "");

    const isIgnoredRequestUrl = (value) => {
        try {
            const parsed = new URL(value || "", window.location.href);
            const host = parsed.hostname.toLowerCase();
            const path = parsed.pathname.toLowerCase();
            if (host.includes("fuseplatform.net")) return true;
            if (path.includes("/telemetry/") || path.includes("/analytics/") || path.includes("/collect")) return true;
            if (host.includes("googletagmanager.com") || host.includes("google-analytics.com")) return true;
            if (host.includes("doubleclick.net") || host.includes("googlesyndication.com")) return true;
            return false;
        } catch (_) {
            return false;
        }
    };

    const isLikelyFileResponse = (url, contentType, contentDisposition) => {
        if (isIgnoredRequestUrl(url)) return false;
        if (isThingiverseDownloadEndpoint(url)) return true;
        if (!isRecentClick()) return false;
        if (/^image\//i.test(contentType || "")) return false;
        if (normalizeDownloadUrl(url) && pendingClick?.filename) return true;
        if (contentDisposition && /filename|attachment/i.test(contentDisposition)) return true;
        if (/\b(application\/octet-stream|application\/zip|model\/|application\/x-zip-compressed)\b/i.test(contentType || "")) return true;
        return Boolean(getFilenameFromUrl(url));
    };

    const collectHeaders = (input, init) => {
        const headers = {};
        const add = (name, value) => {
            const key = String(name || "").toLowerCase();
            if (!/^(authorization|x-csrf-token|x-requested-with|accept)$/i.test(key)) return;
            if (value == null) return;
            headers[key] = String(value);
        };
        const read = (source) => {
            if (!source) return;
            try {
                if (source instanceof Headers) {
                    source.forEach((value, name) => add(name, value));
                } else if (Array.isArray(source)) {
                    source.forEach(([name, value]) => add(name, value));
                } else {
                    Object.entries(source).forEach(([name, value]) => add(name, value));
                }
            } catch (_) {
                // Ignore unreadable header collections.
            }
        };
        read(input?.headers);
        read(init?.headers);
        return headers;
    };

    const postDownload = (url, filename, via, headers = {}) => {
        if (!isEnabled()) return;
        if (isIgnoredRequestUrl(url)) return;
        const normalized = normalizeDownloadUrl(url);
        if (!normalized || /^blob:|^data:/i.test(normalized)) return;
        if (isRecentClick() && (pendingClick?.filename || getRecentSelectedFilename())) {
            return;
        }
        const name = chooseDownloadFilename(filename, getFilenameFromUrl(normalized), normalized);
        const key = `${normalized}|${name}`;
        const stamp = now();
        if (lastPosted.key === key && stamp - lastPosted.ts < 3000) return;
        lastPosted = { key, ts: stamp };
        window.postMessage({
            source: BRIDGE_SOURCE,
            type: "thingiverse-download",
            url: normalized,
            filename: name,
            pageUrl: window.location.href,
            via,
            headers
        }, window.location.origin);
    };

    const shouldSuppressBlobClick = (anchor) => {
        if (!isEnabled()) return false;
        if (!anchor || !/^blob:/i.test(anchor.href || "")) return false;
        const hasKnownBlob = blobByUrl.has(anchor.href);
        const hasDownloadName = Boolean(chooseDownloadFilename(anchor.getAttribute("download") || ""));
        return (hasKnownBlob && (isRecentClick() || getRecentSelectedFilename()) && (pendingClick?.filename || getRecentSelectedFilename() || hasDownloadName))
            || (isRecentClick() && lastPosted.ts && now() - lastPosted.ts < 10000);
    };

    const postBlobDownload = async (anchor, via) => {
        if (!isEnabled()) return false;
        const blobUrl = anchor?.href || "";
        if (sendingBlobUrls.has(blobUrl)) return true;
        const blob = blobByUrl.get(blobUrl);
        if (!blob) return false;
        sendingBlobUrls.add(blobUrl);
        const id = `thingiverse-blob-${now()}-${Math.random().toString(36).slice(2)}`;
        const filename = chooseDownloadFilename(anchor.getAttribute("download") || "")
            || "thingiverse-download";
        window.postMessage({
            source: BRIDGE_SOURCE,
            type: "thingiverse-blob-start",
            id,
            filename,
            pageUrl: window.location.href,
            size: blob.size || 0,
            mimeType: blob.type || "",
            via
        }, window.location.origin);

        try {
            const buffer = await blob.arrayBuffer();
            const bytes = new Uint8Array(buffer);
            for (let offset = 0; offset < bytes.length; offset += BLOB_CHUNK_BYTES) {
                const slice = bytes.subarray(offset, Math.min(offset + BLOB_CHUNK_BYTES, bytes.length));
                let binary = "";
                for (let i = 0; i < slice.length; i += 1) {
                    binary += String.fromCharCode(slice[i]);
                }
                window.postMessage({
                    source: BRIDGE_SOURCE,
                    type: "thingiverse-blob-chunk",
                    id,
                    offset,
                    bytes: slice.length,
                    data: btoa(binary)
                }, window.location.origin);
            }
            window.postMessage({
                source: BRIDGE_SOURCE,
                type: "thingiverse-blob-complete",
                id
            }, window.location.origin);
        } catch (err) {
            window.postMessage({
                source: BRIDGE_SOURCE,
                type: "thingiverse-blob-error",
                id,
                message: err?.message || "Could not read blob download."
            }, window.location.origin);
        } finally {
            setTimeout(() => sendingBlobUrls.delete(blobUrl), 10000);
        }
        return true;
    };

    const rememberDownloadClick = (event) => {
        if (!isEnabled()) return;
        const target = event.target;
        const button = target?.closest?.("button, a");
        if (!button) return;
        const label = button.getAttribute("aria-label") || "";
        const text = button.textContent || "";
        const downloadAttr = button.getAttribute("download") || "";
        const looksLikeDownload = /^download\b/i.test(label.trim())
            || /^download\b/i.test(text.trim())
            || Boolean(downloadAttr);
        if (!looksLikeDownload) {
            pendingClick = null;
            return;
        }
        pendingClick = {
            ts: now(),
            filename: getFilenameFromClickContext(event, button)
                || getFilenameFromText(label.replace(/^download\s+/i, ""))
                || getFilenameFromText(text)
                || getFilenameFromText(downloadAttr)
        };
        rememberSelectedFilename(pendingClick.filename);
        if (pendingClick.filename) {
            console.log("MeshVault Thingiverse bridge: selected filename", pendingClick.filename);
        }
    };

    const originalFetch = window.fetch;
    if (typeof originalFetch === "function") {
        window.fetch = async function () {
            const requestedUrl = typeof arguments[0] === "string"
                ? arguments[0]
                : arguments[0]?.url || "";
            const requestHeaders = collectHeaders(arguments[0], arguments[1]);
            const response = await originalFetch.apply(this, arguments);
            try {
                const clone = response.clone();
                const finalUrl = response.url || requestedUrl;
                const contentType = response.headers.get("content-type") || "";
                const contentDisposition = response.headers.get("content-disposition") || "";
                if (isEnabled() && isLikelyFileResponse(finalUrl || requestedUrl, contentType, contentDisposition) && !(isRecentClick() && pendingClick?.filename)) {
                    postDownload(finalUrl || requestedUrl, getFilenameFromDisposition(contentDisposition), "fetch", requestHeaders);
                } else if (isEnabled() && isRecentClick() && pendingClick?.filename && /json/i.test(contentType)) {
                    clone.text().then((text) => {
                        const direct = normalizeDownloadUrl(text);
                        if (direct) postDownload(direct, pendingClick?.filename || getFilenameFromUrl(direct), "fetch-json", requestHeaders);
                    }).catch(() => {});
                }
            } catch (_) {
                // Keep the site's own download behavior untouched.
            }
            return response;
        };
    }

    const OriginalXhr = window.XMLHttpRequest;
    if (typeof OriginalXhr === "function") {
        const originalOpen = OriginalXhr.prototype.open;
        const originalSend = OriginalXhr.prototype.send;
        const originalSetRequestHeader = OriginalXhr.prototype.setRequestHeader;
        OriginalXhr.prototype.open = function (method, url) {
            this.__meshVaultUrl = url || "";
            this.__meshVaultHeaders = {};
            return originalOpen.apply(this, arguments);
        };
        OriginalXhr.prototype.setRequestHeader = function (name, value) {
            const headers = collectHeaders(null, { headers: [[name, value]] });
            this.__meshVaultHeaders = Object.assign(this.__meshVaultHeaders || {}, headers);
            return originalSetRequestHeader.apply(this, arguments);
        };
        OriginalXhr.prototype.send = function () {
            this.addEventListener("loadend", () => {
                try {
                    const responseUrl = this.responseURL || this.__meshVaultUrl || "";
                    const contentType = this.getResponseHeader("content-type") || "";
                    const contentDisposition = this.getResponseHeader("content-disposition") || "";
                    if (isEnabled() && isLikelyFileResponse(responseUrl, contentType, contentDisposition) && !(isRecentClick() && pendingClick?.filename)) {
                        postDownload(responseUrl, getFilenameFromDisposition(contentDisposition), "xhr", this.__meshVaultHeaders || {});
                    } else if (isEnabled() && isRecentClick() && pendingClick?.filename && /json/i.test(contentType) && typeof this.responseText === "string") {
                        const direct = normalizeDownloadUrl(this.responseText);
                        if (direct) postDownload(direct, pendingClick?.filename || getFilenameFromUrl(direct), "xhr-json", this.__meshVaultHeaders || {});
                    }
                } catch (_) {
                    // Keep the site's own download behavior untouched.
                }
            });
            return originalSend.apply(this, arguments);
        };
    }

    if (window.HTMLAnchorElement?.prototype?.click) {
        const originalAnchorClick = window.HTMLAnchorElement.prototype.click;
        window.HTMLAnchorElement.prototype.click = function () {
            if (shouldSuppressBlobClick(this)) {
                postBlobDownload(this, "anchor-click");
                return undefined;
            }
            return originalAnchorClick.apply(this, arguments);
        };
    }

    if (window.URL?.createObjectURL) {
        const originalCreateObjectURL = window.URL.createObjectURL.bind(window.URL);
        window.URL.createObjectURL = function (object) {
            const objectUrl = originalCreateObjectURL(object);
            try {
                if (object instanceof Blob) {
                    blobByUrl.set(objectUrl, object);
                }
            } catch (_) {
                // Ignore non-Blob object URLs.
            }
            return objectUrl;
        };
    }

    if (window.URL?.revokeObjectURL) {
        const originalRevokeObjectURL = window.URL.revokeObjectURL.bind(window.URL);
        window.URL.revokeObjectURL = function (objectUrl) {
            setTimeout(() => blobByUrl.delete(objectUrl), 30000);
            return originalRevokeObjectURL(objectUrl);
        };
    }

    document.addEventListener("click", (event) => {
        const anchor = event.target?.closest?.("a[href^='blob:']");
        if (!shouldSuppressBlobClick(anchor)) return;
        event.preventDefault();
        event.stopImmediatePropagation();
        postBlobDownload(anchor, "anchor-event");
    }, true);

    document.addEventListener("pointerdown", rememberDownloadClick, true);
    document.addEventListener("click", rememberDownloadClick, true);
})();
