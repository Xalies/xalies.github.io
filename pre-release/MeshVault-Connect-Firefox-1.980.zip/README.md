# MeshVault Connect

## Tester metadata validation

MeshVault Connect includes a no-download validation check for reviewers.

1. Load the unpacked extension in Chrome.
2. Open any supported model page in the same Chrome window, such as Printables, Thingiverse, MakerWorld, Thangs, Cults3D, GrabCAD, MyMiniFactory, or Tinkercad.
3. Open MeshVault Connect options.
4. Click **Validate metadata capture**.

The validation result shows whether the extension found a supported scraper, where the metadata came from, the model page URL, and the normalized metadata JSON that would be sent with an import. This check does not upload a file or start a model download.

