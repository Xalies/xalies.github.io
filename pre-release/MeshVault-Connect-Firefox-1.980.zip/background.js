const DESKTOP_BASE_URL = "http://localhost:24268";
const DEFAULT_SERVER_BASE_URL = "http://localhost:5225";

const SITE_SCRAPERS = {
    "printables.com": "scrapers/printables.js",
    "thingiverse.com": "scrapers/thingiverse.js",
    "makerworld.com": "scrapers/makerworld.js",
    "thangs.com": "scrapers/thangs.js",
    "cults3d.com": "scrapers/cults3d.js",
    "grabcad.com": "scrapers/grabcad.js",
    "myminifactory.com": "scrapers/myminifactory.js",
    "tinkercad.com": "scrapers/tinkercad.js"
};

const ACTIVE_ICON_PATHS = {
    "16": "icons/icon16.png",
    "32": "icons/icon32.png",
    "48": "icons/icon48.png",
    "128": "icons/icon128.png"
};

const INACTIVE_ICON_PATHS = {
    "16": "icons/icon16_gray.png",
    "32": "icons/icon32_gray.png",
    "48": "icons/icon48_gray.png",
    "128": "icons/icon128_gray.png"
};

const DISABLED_ICON_PATHS = {
    "16": "icons/icon16_disabled.png",
    "32": "icons/icon32_disabled.png",
    "48": "icons/icon48_disabled.png",
    "128": "icons/icon128_disabled.png"
};

const MODEL_EXTENSIONS = new Set([
    "3dm", "3ds", "3mf", "amf", "catpart", "catproduct", "dae", "dwfx", "dwg",
    "f3d", "fbx", "fcstd", "glb", "gltf", "gcode", "gco", "iges", "igs", "obj",
    "off", "ply", "scad", "sldasm", "sldprt", "step", "stl", "stp", "x3d", "zip"
]);

const serviceWorkerStartedAt = Date.now();
const STALE_DOWNLOAD_GRACE_MS = 15000;
const TOGGLE_CONTEXT_MENU_ID = "meshvault-toggle-enabled";
const TOGGLE_SITE_CONTEXT_MENU_ID = "meshvault-toggle-site-enabled";
const CANCEL_CONTEXT_MENU_ID = "meshvault-cancel-download";
const CLEAR_METADATA_CONTEXT_MENU_ID = "meshvault-clear-metadata";

let pendingDownload = null;
let pendingResolver = null;
let promptWindowId = null;
let activeDownloads = 0;
let extensionEnabled = true;
let disabledSites = {};
let cultsFallback = null;
const pageUrlByTab = new Map();
const metadataByPageUrl = new Map();
const cultsOrderMetadataByUrl = new Map();
let lastSupportedPageUrl = "";
const offlineNotifiedSites = new Set();
const capturedBlobSessions = new Map();
const activeAbortControllers = new Set();
const browserFallbackDownloadUrls = new Map();
const BROWSER_FALLBACK_IGNORE_MS = 30000;

chrome.storage.local.get({ extensionEnabled: true, disabledSites: {} }, (settings) => {
    extensionEnabled = settings.extensionEnabled !== false;
    disabledSites = normalizeDisabledSites(settings.disabledSites);
    updateBadge();
    refreshAllTabIcons();
    updateToggleContextMenu();
});

chrome.runtime.onInstalled.addListener(() => {
    chrome.storage.local.get({
        extensionEnabled: true,
        targetFolder: "Unsorted",
        promptPerDownload: true,
        notifyDesktopOffline: true,
        meshVaultTargetMode: "desktop",
        meshVaultServerBaseUrl: DEFAULT_SERVER_BASE_URL,
        meshVaultServerToken: "",
        disabledSites: {}
    }, (settings) => chrome.storage.local.set(settings));
    updateToggleContextMenu();
    refreshAllTabIcons();
});

chrome.runtime.onStartup.addListener(() => {
    updateToggleContextMenu();
    refreshAllTabIcons();
});

chrome.action.onClicked.addListener(() => {
    chrome.runtime.openOptionsPage();
});

chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local") return;
    if (!changes.extensionEnabled && !changes.disabledSites) return;
    if (changes.extensionEnabled) extensionEnabled = changes.extensionEnabled.newValue !== false;
    if (changes.disabledSites) disabledSites = normalizeDisabledSites(changes.disabledSites.newValue);
    if (changes.extensionEnabled && !extensionEnabled) {
        activeDownloads = 0;
        resolvePrompt(null);
        capturedBlobSessions.clear();
        cancelActiveMeshVaultDownloads();
    }
    updateBadge();
    refreshAllTabIcons();
    updateToggleContextMenu();
});

chrome.contextMenus.onClicked.addListener((info) => {
    if (info.menuItemId === TOGGLE_CONTEXT_MENU_ID) {
        setExtensionEnabled(!extensionEnabled);
        return;
    }
    if (info.menuItemId === TOGGLE_SITE_CONTEXT_MENU_ID) {
        toggleSiteEnabled(info.pageUrl || "");
        return;
    }
    if (info.menuItemId === CANCEL_CONTEXT_MENU_ID) {
        cancelActiveMeshVaultDownloads();
        return;
    }
    if (info.menuItemId === CLEAR_METADATA_CONTEXT_MENU_ID) {
        clearAllStoredMetadata();
    }
});

chrome.downloads.onCreated.addListener(async (downloadItem) => {
    if (!await isExtensionEnabled()) return;
    const downloadUrl = getDownloadItemUrl(downloadItem);
    if (!downloadUrl || downloadUrl.startsWith("blob:")) return;
    if (isIgnoredDownloadUrl(downloadUrl)) return;
    if (isStaleRestoredDownload(downloadItem)) {
        console.info("MeshVault Connect ignored restored browser download:", downloadUrl);
        return;
    }

    const referrer = downloadItem.referrer || "";
    const tab = typeof downloadItem.tabId === "number" && downloadItem.tabId >= 0
        ? await chrome.tabs.get(downloadItem.tabId).catch(() => null)
        : null;
    rememberTabPage(downloadItem.tabId, tab?.url || "");
    const pageUrl = chooseTriggerPageUrl(downloadItem.tabId, tab?.url || "", referrer);
    const statusTabId = await resolveStatusTabId(downloadItem.tabId, pageUrl, tab?.url || "");

    if (isSiteDisabledForUrl(pageUrl || downloadUrl)) return;
    if (!isSupportedDownload(downloadItem, pageUrl)) return;

    const availability = await getMeshVaultAvailability();
    if (!availability.available) {
        if (availability.readOnly) {
            await maybeNotifyReadOnly(pageUrl || downloadUrl);
            return;
        }

        await maybeNotifyOffline(pageUrl || downloadUrl);
        return;
    }

    cancelBrowserDownload(downloadItem.id);
    activeDownloads += 1;
    updateBadge();
    updateToggleContextMenu();

    const fallbackTitle = getFileName(downloadItem.filename) || getFileNameFromUrl(downloadUrl) || documentTitleFallback(tab);
    processDownload({
        fileUrl: normalizeDownloadUrl(downloadUrl, pageUrl),
        tabId: statusTabId,
        fallbackTitle,
        pageUrl,
        expectedBytes: Math.max(downloadItem.totalBytes || 0, downloadItem.fileSize || 0)
    }).finally(() => {
        activeDownloads = Math.max(0, activeDownloads - 1);
        updateBadge();
        updateToggleContextMenu();
    });
});

chrome.windows.onRemoved.addListener((windowId) => {
    if (windowId !== promptWindowId) return;
    promptWindowId = null;
    if (pendingResolver) pendingResolver(null);
    pendingResolver = null;
    pendingDownload = null;
});

chrome.runtime.onConnect.addListener((port) => {
    if (port.name !== "meshvault-prompt") return;
    port.onMessage.addListener(() => {
        // Prompt heartbeats keep the MV3 worker awake while the user chooses a folder.
    });
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.url || tab?.url) {
        rememberTabPage(tabId, changeInfo.url || tab.url || "");
        updateActionIconForTab(tabId, changeInfo.url || tab.url || "");
    }
});

chrome.tabs.onActivated.addListener(async ({ tabId }) => {
    await updateActionIconForTabId(tabId);
});

chrome.windows.onFocusChanged.addListener(async (windowId) => {
    if (windowId === chrome.windows.WINDOW_ID_NONE) return;
    const tabs = await chrome.tabs.query({ active: true, windowId }).catch(() => []);
    if (tabs[0]?.id != null) await updateActionIconForTabId(tabs[0].id);
});

chrome.tabs.onRemoved.addListener((tabId) => {
    pageUrlByTab.delete(tabId);
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    (async () => {
        if (!await shouldHandleMessageWhenDisabled(message)) return;

        if (message?.action === "supportedPageLoaded") {
            rememberTabPage(sender?.tab?.id, message.pageUrl || sender?.tab?.url || sender?.url || "");
            updateActionIconForTab(sender?.tab?.id, message.pageUrl || sender?.tab?.url || sender?.url || "");
            if (isSiteDisabledForUrl(message.pageUrl || sender?.tab?.url || sender?.url || "")) return;
            const availability = await getMeshVaultAvailability();
            if (!availability.available) {
                if (availability.readOnly) await maybeNotifyReadOnly(message.pageUrl || sender?.tab?.url || sender?.url || "");
                else await maybeNotifyOffline(message.pageUrl || sender?.tab?.url || sender?.url || "");
            }
            return;
        }

        if (message?.action === "supportedModelPageLoaded" || message?.action === "modelPageChanged") {
            rememberTabPage(sender?.tab?.id, message.pageUrl || sender?.tab?.url || sender?.url || "");
            updateActionIconForTab(sender?.tab?.id, message.pageUrl || sender?.tab?.url || sender?.url || "");
            return;
        }

        if (message?.action === "cachePageMetadata") {
            if (isSiteDisabledForUrl(message.pageUrl || sender?.tab?.url || sender?.url || "")) return;
            rememberTabPage(sender?.tab?.id, message.pageUrl || sender?.tab?.url || sender?.url || "");
            rememberPageMetadata(message.pageUrl || sender?.tab?.url || sender?.url || "", message.rawMeta);
            return;
        }

        if (message?.action === "cacheThangsMeta" && message.rawMeta) {
            if (isSiteDisabledForUrl(message.pageUrl || sender?.tab?.url || sender?.url || "")) return;
            rememberTabPage(sender?.tab?.id, message.pageUrl || sender?.tab?.url || sender?.url || "");
            rememberPageMetadata(message.pageUrl || sender?.tab?.url || sender?.url || "", message.rawMeta);
            return;
        }

        if (message?.action === "getPendingDownload") {
            sendResponse({
                pending: Boolean(pendingDownload),
                title: pendingDownload?.fallbackTitle || "",
                url: pendingDownload?.fileUrl || ""
            });
            return;
        }

        if (message?.action === "cancelPrompt") {
            resolvePrompt(null);
            return;
        }

        if (message?.action === "setDownloadFolder") {
            if (!pendingResolver) {
                sendResponse({
                    ok: false,
                    message: "This save prompt expired. Start the download again."
                });
                return;
            }
            const folder = String(message.folder || "Unsorted").trim() || "Unsorted";
            chrome.storage.local.set({ lastPromptFolder: folder }, () => void chrome.runtime.lastError);
            resolvePrompt(folder);
            sendResponse({ ok: true });
            return;
        }

        if (message?.action === "validateMetadataCapture") {
            sendResponse(await validateMetadataCapture());
            return;
        }

        if (message?.action === "cacheCultsMeta" && message.rawMeta) {
            if (isSiteDisabledForUrl(message.pageUrl || sender?.tab?.url || sender?.url || "")) return;
            clearAllStoredMetadata(false);
            cultsFallback = {
                rawMeta: message.rawMeta,
                pageUrl: message.pageUrl || message.rawMeta?.sourceUrl || sender?.tab?.url || "",
                ts: Date.now()
            };
            return;
        }

        if (message?.action === "cacheCultsOrderMeta" && message.rawMeta && message.orderUrl) {
            if (isSiteDisabledForUrl(message.pageUrl || message.orderUrl || sender?.tab?.url || sender?.url || "")) return;
            clearAllStoredMetadata(false);
            rememberCultsOrderMetadata(message.orderUrl, message.rawMeta);
            cultsFallback = {
                rawMeta: message.rawMeta,
                pageUrl: message.pageUrl || message.rawMeta?.sourceUrl || sender?.tab?.url || "",
                ts: Date.now()
            };
            return;
        }

        if (message?.action === "cultsDownload" && message.downloadUrl) {
            if (isSiteDisabledForUrl(message.pageUrl || sender?.tab?.url || sender?.url || "")) return;
            rememberTabPage(sender?.tab?.id, message.pageUrl || sender?.tab?.url || sender?.url || "");
            await startExplicitDownload(message.downloadUrl, sender?.tab?.id ?? -1, message.fallbackTitle || "", chooseTriggerPageUrl(sender?.tab?.id, sender?.tab?.url || "", message.pageUrl || ""));
            return;
        }

        if (message?.action === "thingiverseDownloadAll" && message.pageUrl) {
            if (isSiteDisabledForUrl(message.pageUrl || sender?.tab?.url || sender?.url || "")) return;
            rememberTabPage(sender?.tab?.id, message.pageUrl || sender?.tab?.url || sender?.url || "");
            const zipUrl = buildThingiverseZipUrl(message.pageUrl);
            if (zipUrl) await startExplicitDownload(zipUrl, sender?.tab?.id ?? -1, message.fallbackTitle || "", message.pageUrl);
            return;
        }

        if (message?.action === "thingiverseBlobStart" && message.id) {
            if (isSiteDisabledForUrl(message.pageUrl || sender?.tab?.url || sender?.url || "")) return;
            rememberTabPage(sender?.tab?.id, message.pageUrl || sender?.tab?.url || sender?.url || "");
            startThingiverseBlobSession(message, sender?.tab?.id ?? -1, sender?.tab?.url || "");
            sendResponse({ ok: true });
            return;
        }

        if (message?.action === "thingiverseBlobChunk" && message.id) {
            appendThingiverseBlobChunk(message);
            sendResponse({ ok: true });
            return;
        }

        if (message?.action === "thingiverseBlobComplete" && message.id) {
            await completeThingiverseBlobSession(message.id);
            sendResponse({ ok: true });
            return;
        }

        if (message?.action === "thingiverseBlobError" && message.id) {
            failThingiverseBlobSession(message.id, message.message || "Could not read blob download.");
            sendResponse({ ok: true });
            return;
        }

        if (message?.action === "uploadToMeshVault" && message.url) {
            if (isSiteDisabledForUrl(message.pageUrl || sender?.tab?.url || sender?.url || "")) return;
            rememberTabPage(sender?.tab?.id, message.pageUrl || sender?.tab?.url || sender?.url || "");
            await startExplicitDownload(message.url, sender?.tab?.id ?? -1, message.filename || "", chooseTriggerPageUrl(sender?.tab?.id, sender?.tab?.url || "", message.pageUrl || ""), message.metadata || "", sanitizeDownloadHeaders(message.url, message.headers));
            sendResponse({ ok: true });
            return;
        }

    })().catch((err) => console.warn("MeshVault Connect message failed:", err));

    return true;
});

async function startExplicitDownload(fileUrl, tabId, fallbackTitle, pageUrl, rawMeta = "", requestHeaders = {}) {
    if (!await isExtensionEnabled()) {
        openUrlInBrowser(tabId, fileUrl);
        return;
    }
    if (isSiteDisabledForUrl(pageUrl || fileUrl)) {
        openUrlInBrowser(tabId, fileUrl);
        return;
    }

    const availability = await getMeshVaultAvailability();
    if (!availability.available) {
        openUrlInBrowser(tabId, fileUrl);
        if (availability.readOnly) {
            await maybeNotifyReadOnly(pageUrl || fileUrl);
        }
        return;
    }

    activeDownloads += 1;
    updateBadge();
    updateToggleContextMenu();
    processDownload({ fileUrl, tabId, fallbackTitle, pageUrl, rawMeta, requestHeaders })
        .finally(() => {
            activeDownloads = Math.max(0, activeDownloads - 1);
            updateBadge();
            updateToggleContextMenu();
        });
}

function startThingiverseBlobSession(message, tabId, tabUrl) {
    if (!extensionEnabled) return;
    const id = String(message.id || "");
    if (!id) return;
    capturedBlobSessions.set(id, {
        id,
        tabId,
        chunks: new Map(),
        receivedBytes: 0,
        expectedBytes: Math.max(Number(message.size || 0), 0),
        mimeType: message.mimeType || "",
        fallbackTitle: message.filename || "thingiverse-download",
        pageUrl: chooseTriggerPageUrl(tabId, tabUrl || "", message.pageUrl || ""),
        rawMeta: message.metadata || "",
        startedAt: Date.now()
    });
    activeDownloads += 1;
    updateBadge();
    updateToggleContextMenu();
    sendDownloadStatus(tabId, {
        state: "working",
        title: "MeshVault",
        phase: "Receiving",
        message: message.size > 0
            ? `Receiving ${formatBytes(message.size)} from Thingiverse...`
            : "Receiving Thingiverse file..."
    });
}

function appendThingiverseBlobChunk(message) {
    const session = capturedBlobSessions.get(String(message.id || ""));
    if (!session || typeof message.data !== "string") return;
    const offset = Math.max(Number(message.offset || 0), 0);
    const existing = session.chunks.get(offset);
    session.chunks.set(offset, message.data);
    if (!existing) {
        session.receivedBytes += Math.max(Number(message.bytes || 0), 0);
    }
    const percent = session.expectedBytes > 0
        ? Math.min(100, Math.floor((session.receivedBytes / session.expectedBytes) * 100))
        : null;
    sendDownloadStatus(session.tabId, {
        state: "working",
        title: "MeshVault",
        phase: "Receiving",
        message: session.expectedBytes > 0
            ? `${percent}% - ${formatBytes(session.receivedBytes)} of ${formatBytes(session.expectedBytes)}`
            : `Received ${formatBytes(session.receivedBytes)}...`,
        percent
    });
}

async function completeThingiverseBlobSession(id) {
    const session = capturedBlobSessions.get(String(id || ""));
    if (!session) return;
    capturedBlobSessions.delete(session.id);
    try {
        const orderedChunks = Array.from(session.chunks.entries())
            .sort(([left], [right]) => left - right)
            .map(([, value]) => base64ToUint8Array(value));
        const blob = new Blob(orderedChunks, {
            type: session.mimeType || "application/octet-stream"
        });
        await processCapturedBlob({
            blob,
            tabId: session.tabId,
            fallbackTitle: session.fallbackTitle,
            pageUrl: session.pageUrl,
            rawMeta: session.rawMeta
        });
    } catch (err) {
        sendDownloadStatus(session.tabId, {
            state: "error",
            title: "MeshVault",
            phase: "Failed",
            message: err?.message || "Could not import Thingiverse blob download."
        });
        notify("MeshVault Connect", err?.message || "Could not import Thingiverse blob download.");
    } finally {
        activeDownloads = Math.max(0, activeDownloads - 1);
        updateBadge();
        updateToggleContextMenu();
    }
}

function failThingiverseBlobSession(id, message) {
    const session = capturedBlobSessions.get(String(id || ""));
    if (session) {
        capturedBlobSessions.delete(session.id);
        activeDownloads = Math.max(0, activeDownloads - 1);
        updateBadge();
        updateToggleContextMenu();
        sendDownloadStatus(session.tabId, {
            state: "error",
            title: "MeshVault",
            phase: "Failed",
            message
        });
    }
    notify("MeshVault Connect", message);
}

function base64ToUint8Array(value) {
    const binary = atob(value || "");
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i += 1) {
        bytes[i] = binary.charCodeAt(i);
    }
    return bytes;
}

function sanitizeDownloadHeaders(fileUrl, headers) {
    if (!headers || typeof headers !== "object") return {};
    try {
        const host = new URL(fileUrl).hostname.toLowerCase();
        if (host !== "thingiverse.com" && !host.endsWith(".thingiverse.com")) {
            return {};
        }
    } catch (_) {
        return {};
    }

    const allowed = new Set(["authorization", "x-csrf-token", "x-requested-with", "accept"]);
    const sanitized = {};
    for (const [name, value] of Object.entries(headers)) {
        const key = String(name || "").toLowerCase();
        if (!allowed.has(key) || value == null) continue;
        sanitized[key] = String(value);
    }
    return sanitized;
}

async function processDownload({ fileUrl, tabId, fallbackTitle, pageUrl, expectedBytes = 0, rawMeta = "", requestHeaders = {} }) {
    let abortController = null;
    try {
        if (!await isExtensionEnabled()) return;
        sendDownloadStatus(tabId, {
            state: "working",
            title: "MeshVault",
            phase: "Preparing",
            message: "Gathering model metadata..."
        });

        const metadata = await getImportMetadata({ rawMeta, tabId, pageUrl });
        const promptEnabled = await getStoredBoolean("promptPerDownload", true);
        let targetFolder = await getStoredString("targetFolder", "Unsorted");

        if (promptEnabled) {
            sendDownloadStatus(tabId, {
                state: "working",
                title: "MeshVault",
                phase: "Waiting",
                message: "Choose a library folder to continue."
            });
            const prompted = await promptForFolder({ fileUrl, fallbackTitle });
            if (!prompted) {
                sendDownloadStatus(tabId, { state: "hide" });
                return;
            }
            targetFolder = prompted;
        }

        abortController = createTrackedAbortController();
        await uploadToMeshVault(
            fileUrl,
            metadata,
            fallbackTitle,
            targetFolder,
            expectedBytes,
            pageUrl,
            requestHeaders,
            abortController,
            (status) => sendDownloadStatus(tabId, status));
        sendDownloadStatus(tabId, {
            state: "success",
            title: "MeshVault",
            phase: "Saved",
            message: "Saved to your library."
        });
    } catch (err) {
        console.warn("MeshVault Connect upload failed:", err);
        if (err?.meshVaultReadOnly) {
            await fallbackToBrowserDownload(fileUrl, fallbackTitle, tabId);
            return;
        }

        sendDownloadStatus(tabId, {
            state: "error",
            title: "MeshVault Connect",
            phase: err?.name === "AbortError" ? "Cancelled" : "Failed",
            message: err?.name === "AbortError" ? "Download cancelled." : (err?.message || "Could not save this download.")
        });
        if (err?.name !== "AbortError") notify("MeshVault Connect", err?.message || "Could not save this download.");
    } finally {
        releaseTrackedAbortController(abortController);
    }
}

async function processCapturedBlob({ blob, tabId, fallbackTitle, pageUrl, rawMeta = "" }) {
    let abortController = null;
    try {
        if (!await isExtensionEnabled()) return;
        sendDownloadStatus(tabId, {
            state: "working",
            title: "MeshVault",
            phase: "Preparing",
            message: "Gathering model metadata..."
        });

        const metadata = await getImportMetadata({ rawMeta, tabId, pageUrl });
        const promptEnabled = await getStoredBoolean("promptPerDownload", true);
        let targetFolder = await getStoredString("targetFolder", "Unsorted");

        if (promptEnabled) {
            sendDownloadStatus(tabId, {
                state: "working",
                title: "MeshVault",
                phase: "Waiting",
                message: "Choose a library folder to continue."
            });
            const prompted = await promptForFolder({ fileUrl: pageUrl, fallbackTitle });
            if (!prompted) {
                sendDownloadStatus(tabId, { state: "hide" });
                return;
            }
            targetFolder = prompted;
        }

        abortController = createTrackedAbortController();
        await uploadBlobToMeshVault(
            blob,
            metadata,
            fallbackTitle,
            targetFolder,
            pageUrl,
            abortController,
            (status) => sendDownloadStatus(tabId, status));
        sendDownloadStatus(tabId, {
            state: "success",
            title: "MeshVault",
            phase: "Saved",
            message: "Saved to your MeshVault library."
        });
    } catch (err) {
        console.warn("MeshVault captured blob import failed:", err);
        sendDownloadStatus(tabId, {
            state: "error",
            title: "MeshVault",
            phase: err?.name === "AbortError" ? "Cancelled" : "Failed",
            message: err?.name === "AbortError" ? "Download cancelled." : (err?.message || "Could not save this download.")
        });
        if (err?.name !== "AbortError") notify("MeshVault Connect", err?.message || "Could not save this download.");
    } finally {
        releaseTrackedAbortController(abortController);
    }
}

async function uploadToMeshVault(fileUrl, rawMeta, fallbackTitle, targetFolder, expectedBytes, fallbackPageUrl, requestHeaders = {}, abortController, onStatus = () => {}) {
    onStatus({
        state: "working",
        title: "MeshVault",
        phase: "Downloading",
        message: "Starting download..."
    });
    const response = await fetch(fileUrl, {
        credentials: "include",
        headers: requestHeaders || {},
        signal: abortController?.signal
    });
    if (!response.ok) throw new Error(`Download failed: ${response.status} ${response.statusText}`);

    const blob = await readResponseBlob(response, expectedBytes, onStatus);
    if (expectedBytes && blob.size && blob.size < Math.min(expectedBytes, 1024)) {
        console.warn("MeshVault Connect received a very small response for", fileUrl);
    }

    const finalUrl = response.url || fileUrl;
    const contentDisposition = response.headers.get("Content-Disposition") || "";
    const dispositionName = parseDispositionFilename(contentDisposition);
    const contentType = response.headers.get("Content-Type") || "";
    const initialFilename = ensureFilename(dispositionName || getFileNameFromUrl(finalUrl) || fallbackTitle, finalUrl, contentType);
    const metadata = buildImportMetadata(rawMeta, {
        fileName: initialFilename,
        folder: targetFolder || "Unsorted",
        fallbackTitle,
        sourceUrl: fallbackPageUrl || finalUrl,
        downloadUrl: finalUrl
    });
    const filename = chooseFinalImportFilename(initialFilename, metadata, fallbackPageUrl, finalUrl, contentType);
    metadata.fileName = filename;
    const formData = new FormData();
    formData.append("file", blob, filename);
    formData.append("metadata", JSON.stringify(metadata));

    onStatus({
        state: "working",
        title: "MeshVault",
        phase: "Importing",
        message: "Sending to MeshVault and refreshing the library..."
    });
    const target = await getMeshVaultTarget();
    const uploadResponse = await fetch(`${target.baseUrl}/upload`, {
        method: "POST",
        body: formData,
        headers: target.headers,
        signal: abortController?.signal
    });

    if (!uploadResponse.ok) {
        throw await createUploadError(uploadResponse);
    }
}

async function uploadBlobToMeshVault(blob, rawMeta, fallbackTitle, targetFolder, fallbackPageUrl, abortController, onStatus = () => {}) {
    const initialFilename = ensureFilename(fallbackTitle, fallbackPageUrl, blob.type || "");
    const metadata = buildImportMetadata(rawMeta, {
        fileName: initialFilename,
        folder: targetFolder || "Unsorted",
        fallbackTitle,
        sourceUrl: fallbackPageUrl || "",
        downloadUrl: fallbackPageUrl || ""
    });
    const filename = chooseFinalImportFilename(initialFilename, metadata, fallbackPageUrl, fallbackPageUrl, blob.type || "");
    metadata.fileName = filename;
    const formData = new FormData();
    formData.append("file", blob, filename);
    formData.append("metadata", JSON.stringify(metadata));

    onStatus({
        state: "working",
        title: "MeshVault",
        phase: "Importing",
        message: "Sending to MeshVault and refreshing the library..."
    });
    const target = await getMeshVaultTarget();
    const uploadResponse = await fetch(`${target.baseUrl}/upload`, {
        method: "POST",
        body: formData,
        headers: target.headers,
        signal: abortController?.signal
    });

    if (!uploadResponse.ok) {
        throw await createUploadError(uploadResponse);
    }
}

async function createUploadError(response) {
    const message = await formatUploadError(response);
    const error = new Error(message);
    error.meshVaultReadOnly = response.status === 402;
    error.status = response.status;
    return error;
}

async function formatUploadError(response) {
    const text = await response.text().catch(() => "");
    if (response.status === 401) return "MeshVault Server rejected the server token.";
    if (response.status === 402) return "MeshVault Server is read-only. Activate MeshVault Pro on the server to import downloads.";
    if (!text) return `MeshVault import failed: ${response.status}`;
    try {
        const payload = JSON.parse(text);
        const detail = payload.error || payload.message || text;
        return `MeshVault import failed: ${response.status} ${detail}`;
    } catch {
        return `MeshVault import failed: ${response.status} ${text}`;
    }
}

async function fallbackToBrowserDownload(fileUrl, fallbackTitle, tabId) {
    rememberBrowserFallbackDownload(fileUrl);
    await chrome.downloads.download({ url: fileUrl, saveAs: false });
    sendDownloadStatus(tabId, {
        state: "success",
        title: "MeshVault Connect",
        phase: "Downloaded",
        message: "MeshVault Server is read-only. The file was downloaded normally."
    });
    notify("MeshVault Connect", "MeshVault Server is read-only, so the file was downloaded normally.");
}

function rememberBrowserFallbackDownload(url) {
    const key = normalizeDownloadIgnoreKey(url);
    if (!key) return;
    browserFallbackDownloadUrls.set(key, Date.now() + BROWSER_FALLBACK_IGNORE_MS);
}

function normalizeDownloadIgnoreKey(url) {
    try {
        return new URL(url || "").href;
    } catch {
        return String(url || "");
    }
}

async function readResponseBlob(response, expectedBytes, onStatus) {
    const contentType = response.headers.get("Content-Type") || "";
    const headerBytes = Number(response.headers.get("Content-Length") || 0);
    const totalBytes = headerBytes > 0 ? headerBytes : Math.max(expectedBytes || 0, 0);

    if (!response.body?.getReader) {
        const blob = await response.blob();
        onStatus({
            state: "working",
            title: "MeshVault",
            phase: "Downloaded",
            message: `Downloaded ${formatBytes(blob.size)}.`
        });
        return blob;
    }

    const reader = response.body.getReader();
    const chunks = [];
    let receivedBytes = 0;
    let lastUpdateAt = 0;
    let lastPercent = -1;

    while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        chunks.push(value);
        receivedBytes += value.byteLength;

        const percent = totalBytes > 0
            ? Math.min(100, Math.floor((receivedBytes / totalBytes) * 100))
            : null;
        const now = Date.now();
        if (now - lastUpdateAt > 250 || (percent !== null && percent !== lastPercent)) {
            lastUpdateAt = now;
            lastPercent = percent ?? lastPercent;
            onStatus({
                state: "working",
                title: "MeshVault",
                phase: "Downloading",
                message: totalBytes > 0
                    ? `${percent}% - ${formatBytes(receivedBytes)} of ${formatBytes(totalBytes)}`
                    : `Downloaded ${formatBytes(receivedBytes)}...`,
                percent
            });
        }
    }

    onStatus({
        state: "working",
        title: "MeshVault",
        phase: "Downloaded",
        message: `Downloaded ${formatBytes(receivedBytes)}.`
    });
    return new Blob(chunks, { type: contentType });
}

async function getImportMetadata({ rawMeta = "", tabId, pageUrl }) {
    if (rawMeta) return rawMeta;

    if (isMakerWorldModelPage(pageUrl)) {
        return await fetchSiteMetadata(pageUrl) ||
            await scrapeMetadata(tabId) ||
            "";
    }

    if (isTinkercadModelPage(pageUrl)) {
        return await fetchSiteMetadata(pageUrl) ||
            getCachedPageMetadata(pageUrl) ||
            await scrapeMetadata(tabId) ||
            "";
    }

    return await scrapeMetadata(tabId) ||
        getCachedPageMetadata(pageUrl) ||
        getCultsOrderMetadata(pageUrl) ||
        await fetchSiteMetadata(pageUrl) ||
        getFreshCultsMetadata(pageUrl) ||
        "";
}

async function validateMetadataCapture() {
    const tab = await findMetadataValidationTab();
    const pageUrl = tab?.url || lastSupportedPageUrl || "";
    const scraperFile = getScraperFile(pageUrl);
    const supported = Boolean(scraperFile && isSupportedSitePage(pageUrl));
    const baseResult = {
        checkedAtUtc: new Date().toISOString(),
        extensionEnabled,
        supported,
        pageUrl,
        tabTitle: tab?.title || "",
        sourceSite: getSourceSite(pageUrl),
        scraperFile,
        metadataSource: "",
        rawMetadataType: "",
        rawMetadataPreview: "",
        metadata: null,
        ok: false,
        message: ""
    };

    if (!tab?.id || !supported) {
        return {
            ...baseResult,
            message: "Open a supported model page in this browser window, then run validation again."
        };
    }

    let rawMeta = await scrapeMetadata(tab.id);
    let metadataSource = rawMeta ? "active page scraper" : "";
    const fetchedMeta = await fetchSiteMetadata(pageUrl);

    if (isTinkercadModelPage(pageUrl) && fetchedMeta) {
        rawMeta = fetchedMeta;
        metadataSource = "site metadata fetch";
    }

    if (!rawMeta) {
        rawMeta = getCachedPageMetadata(pageUrl);
        metadataSource = rawMeta ? "extension metadata cache" : "";
    }

    if (!rawMeta) {
        rawMeta = fetchedMeta;
        metadataSource = rawMeta ? "site metadata fetch" : "";
    } else if (fetchedMeta) {
        const enriched = mergeValidationMetadata(rawMeta, fetchedMeta);
        if (enriched !== rawMeta) {
            rawMeta = enriched;
            metadataSource = `${metadataSource} + site metadata fetch`;
        }
    }

    if (!rawMeta) {
        return {
            ...baseResult,
            message: "The supported page was found, but no metadata was collected from it yet."
        };
    }

    const metadata = buildImportMetadata(rawMeta, {
        fileName: "validation-sample.stl",
        folder: "Validation",
        fallbackTitle: tab.title || "MeshVault validation sample",
        sourceUrl: pageUrl,
        downloadUrl: ""
    });

    return {
        ...baseResult,
        metadataSource,
        rawMetadataType: Array.isArray(rawMeta) ? "array" : typeof rawMeta,
        rawMetadataPreview: previewRawMetadata(rawMeta),
        metadata,
        ok: true,
        message: "Metadata was collected."
    };
}

function mergeValidationMetadata(primary, fallback) {
    if (!primary || !fallback || typeof primary !== "object" || typeof fallback !== "object" || Array.isArray(primary) || Array.isArray(fallback)) {
        return primary;
    }

    const merged = { ...primary };
    for (const key of ["thumbnailUrl", "image", "summary", "description", "author", "authorUrl"]) {
        if (!merged[key] && fallback[key]) merged[key] = fallback[key];
    }
    if ((!Array.isArray(merged.images) || merged.images.length === 0) && Array.isArray(fallback.images) && fallback.images.length > 0) {
        merged.images = fallback.images;
    }
    if ((!Array.isArray(merged.tags) || merged.tags.length === 0) && Array.isArray(fallback.tags) && fallback.tags.length > 0) {
        merged.tags = fallback.tags;
    }
    return merged;
}

async function findMetadataValidationTab() {
    const tabs = await chrome.tabs.query({ currentWindow: true }).catch(() => []);
    const supportedTabs = tabs.filter((tab) => isSupportedSitePage(tab?.url || ""));
    if (!supportedTabs.length) return null;

    return supportedTabs.find((tab) => tab.active)
        || supportedTabs.find((tab) => (tab.url || "").replace(/\/$/, "") === lastSupportedPageUrl.replace(/\/$/, ""))
        || supportedTabs[0];
}

function previewRawMetadata(rawMeta) {
    try {
        const text = typeof rawMeta === "string" ? rawMeta : JSON.stringify(rawMeta, null, 2);
        return text.length > 1800 ? `${text.slice(0, 1800)}...` : text;
    } catch {
        return "";
    }
}

async function scrapeMetadata(tabId) {
    if (typeof tabId !== "number" || tabId < 0) return "";
    const tab = await chrome.tabs.get(tabId).catch(() => null);
    const scraperFile = getScraperFile(tab?.url || "");
    if (!scraperFile) return "";

    await chrome.scripting.executeScript({ target: { tabId }, files: [scraperFile] }).catch(() => null);
    const result = await chrome.scripting.executeScript({
        target: { tabId },
        func: () => {
            try {
                return typeof window.MeshVaultScrape === "function" ? window.MeshVaultScrape() : "";
            } catch {
                return "";
            }
        }
    }).catch(() => null);

    return result?.[0]?.result || "";
}

function getFreshCultsMetadata(pageUrl) {
    if (!cultsFallback || Date.now() - cultsFallback.ts > 10000) return "";
    if (pageUrl && cultsFallback.pageUrl) {
        const requested = pageUrl.replace(/\/$/, "");
        const cached = cultsFallback.pageUrl.replace(/\/$/, "");
        if (requested !== cached && requested.includes("/3d-model/")) return "";
    }
    return cultsFallback.rawMeta || "";
}

function rememberTabPage(tabId, url) {
    if (typeof tabId !== "number" || tabId < 0 || !isUsefulPageUrl(url)) return;
    pageUrlByTab.set(tabId, url);
    if (isSupportedUrl(url)) {
        lastSupportedPageUrl = url;
    }
}

function rememberPageMetadata(pageUrl, rawMeta) {
    if (!pageUrl || !rawMeta) return;
    clearAllStoredMetadata(false);
    metadataByPageUrl.set(pageUrl.replace(/\/$/, ""), {
        rawMeta,
        ts: Date.now()
    });
}

function getCachedPageMetadata(pageUrl) {
    const key = (pageUrl || "").replace(/\/$/, "");
    const direct = metadataByPageUrl.get(key);
    if (direct && Date.now() - direct.ts < 120000) return direct.rawMeta;

    const baseKey = key.replace(/\/files$/i, "");
    const base = metadataByPageUrl.get(baseKey);
    if (base && Date.now() - base.ts < 120000) return base.rawMeta;

    return "";
}

function rememberCultsOrderMetadata(orderUrl, rawMeta) {
    const keys = getCultsOrderMetadataKeys(orderUrl);
    if (!keys.length || !rawMeta) return;
    const entry = {
        rawMeta,
        ts: Date.now()
    };
    keys.forEach((key) => cultsOrderMetadataByUrl.set(key, entry));
}

function getCultsOrderMetadata(pageUrl) {
    for (const key of getCultsOrderMetadataKeys(pageUrl)) {
        const entry = cultsOrderMetadataByUrl.get(key);
        if (entry && Date.now() - entry.ts < 30 * 60 * 1000) return entry.rawMeta;
    }
    return "";
}

function getCultsOrderMetadataKeys(url) {
    if (!url) return [];
    try {
        const parsed = new URL(url);
        if (!parsed.hostname.toLowerCase().includes("cults3d.com")) return [];
        const path = parsed.pathname.replace(/\/$/, "");
        const orderId = path.match(/\/orders\/(\d+)/i)?.[1] || "";
        const keys = [parsed.origin + path];
        if (orderId) keys.push(`order:${orderId}`);
        return keys;
    } catch {
        const orderId = String(url).match(/\/orders\/(\d+)/i)?.[1] || "";
        return orderId ? [`order:${orderId}`] : [];
    }
}

async function fetchSiteMetadata(pageUrl) {
    if (!pageUrl) return "";
    if (pageUrl.includes("printables.com/model/")) return await fetchPrintablesMetadata(pageUrl);
    if (pageUrl.includes("makerworld.com/") && pageUrl.includes("/models/")) return await fetchMakerWorldMetadata(pageUrl);
    if (pageUrl.includes("thingiverse.com/thing:")) return await fetchThingiverseMetadata(pageUrl);
    if (pageUrl.includes("thangs.com/") && pageUrl.includes("/3d-model/")) return await fetchThangsMetadata(pageUrl);
    if (pageUrl.includes("grabcad.com/") && pageUrl.includes("/library/")) return await fetchGrabCadMetadata(pageUrl);
    if (pageUrl.includes("myminifactory.com/") && /\/objects?\//i.test(pageUrl)) return await fetchMyMiniFactoryMetadata(pageUrl);
    if (pageUrl.includes("tinkercad.com/") && /\/things\//i.test(pageUrl)) return await fetchTinkercadMetadata(pageUrl);
    return "";
}

async function fetchTinkercadMetadata(pageUrl) {
    try {
        const normalizedPageUrl = normalizeTinkercadPageUrl(pageUrl);
        const response = await fetch(normalizedPageUrl, { credentials: "include" });
        if (!response.ok) return "";
        const html = await response.text();
        const metaDescription = htmlToSimpleText(extractNamedMetaContent(html, "description") || extractMetaContent(html, "og:description"));
        const parsedMeta = parseTinkercadMetaDescription(metaDescription);
        const title = cleanTinkercadTitle(parsedMeta.title || htmlToSimpleText(extractMetaContent(html, "og:title") || extractHtmlTitle(html)));
        if (!parsedMeta.title && isGenericTinkercadTitle(title)) return "";
        const description = isTinkercadBoilerplateDescription(metaDescription) ? "" : metaDescription;
        const image = extractMetaContent(html, "og:image") || extractNamedMetaContent(html, "twitter:image") || "";
        return {
            sourceSite: "Tinkercad",
            sourceUrl: normalizedPageUrl,
            title,
            author: parsedMeta.author || "",
            authorUrl: "",
            summary: description,
            description: description ? plainTextToSimpleHtml(description) : "",
            tags: ["Tinkercad"],
            license: "",
            category: "",
            thumbnailUrl: image,
            images: image ? [image] : [],
            sourceMetadataMethod: "tinkercad-background-html"
        };
    } catch {
        return "";
    }
}

function normalizeTinkercadPageUrl(url) {
    try {
        const parsed = new URL(url || "");
        parsed.hash = "";
        parsed.search = "";
        const thingPath = parsed.pathname.match(/\/things\/[^/]+/i)?.[0] || "";
        parsed.pathname = thingPath || parsed.pathname.replace(/\/edit\/?$/i, "").replace(/\/$/, "");
        return parsed.toString();
    } catch {
        return url || "";
    }
}

function cleanTinkercadTitle(value) {
    return String(value || "")
        .replace(/^3D design\s+/i, "")
        .replace(/\s*\|\s*Tinkercad\s*$/i, "")
        .replace(/\s*-\s*Tinkercad\s*$/i, "")
        .trim();
}

function isGenericTinkercadTitle(value) {
    const clean = cleanTinkercadTitle(value).toLowerCase();
    return !clean || clean === "tinkercad" || clean === "login";
}

function parseTinkercadMetaDescription(value) {
    const text = String(value || "").replace(/\s+/g, " ").trim();
    const match = text.match(/^3D design\s+(.+?)\s+created by\s+(.+?)\s+with Tinkercad\.?$/i);
    return {
        title: match ? match[1].trim() : "",
        author: match ? match[2].trim() : ""
    };
}

function isTinkercadBoilerplateDescription(value) {
    return /^3D design\s+.+?\s+created by\s+.+?\s+with Tinkercad\.?$/i.test(String(value || "").replace(/\s+/g, " ").trim());
}

function plainTextToSimpleHtml(text) {
    const escaped = String(text || "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;");
    return escaped ? `<p>${escaped.replace(/\n{2,}/g, "</p><p>").replace(/\n/g, "<br>")}</p>` : "";
}

async function fetchMyMiniFactoryMetadata(pageUrl) {
    try {
        const response = await fetch(pageUrl, { credentials: "include" });
        if (!response.ok) return "";
        const html = await response.text();
        const title = htmlToSimpleText(extractMetaContent(html, "og:title") || extractHtmlTitle(html));
        const parsed = parseMyMiniFactoryTitleFromText(title);
        const description = htmlToSimpleText(extractMetaContent(html, "description") || extractMetaContent(html, "og:description"));
        const image = extractMetaContent(html, "og:image") || extractMetaContent(html, "twitter:image") || "";
        return {
            sourceSite: "MyMiniFactory",
            sourceModelId: extractMyMiniFactoryObjectIdFromUrl(pageUrl),
            sourceUrl: pageUrl,
            title: parsed.title,
            author: parsed.author,
            authorUrl: "",
            summary: description,
            description: description ? `<p>${escapeHtml(description)}</p>` : "",
            tags: [],
            license: "",
            category: "",
            thumbnailUrl: image,
            images: image ? [image] : [],
            sourceMetadataMethod: "myminifactory-background-html"
        };
    } catch {
        return "";
    }
}

function parseMyMiniFactoryTitleFromText(rawTitle) {
    let title = String(rawTitle || "")
        .replace(/\s+/g, " ")
        .replace(/^3D Printable\s+/i, "")
        .replace(/\s*-\s*MyMiniFactory.*$/i, "")
        .trim();
    let author = "";
    const byMatch = title.match(/^(.*?)\s+by\s+(.+)$/i);
    if (byMatch) {
        title = (byMatch[1] || "").trim();
        author = (byMatch[2] || "").trim();
    }
    return { title, author };
}

function extractMyMiniFactoryObjectIdFromUrl(pageUrl) {
    try {
        const last = new URL(pageUrl).pathname.split("/").filter(Boolean).pop() || "";
        return last.match(/-(\d+)$/)?.[1] || "";
    } catch {
        return "";
    }
}

async function fetchGrabCadMetadata(pageUrl) {
    try {
        const response = await fetch(pageUrl, { credentials: "include" });
        if (!response.ok) return "";
        const html = await response.text();
        const title = htmlToSimpleText(extractMetaContent(html, "og:title") || extractHtmlTitle(html));
        const parsed = parseGrabCadTitleFromText(title);
        const description = htmlToSimpleText(extractMetaContent(html, "description") || extractMetaContent(html, "og:description"));
        const image = extractMetaContent(html, "og:image") || extractMetaContent(html, "twitter:image") || "";
        return {
            sourceSite: "GrabCAD",
            sourceModelId: extractGrabCadModelIdFromUrl(pageUrl),
            sourceUrl: pageUrl,
            title: parsed.title,
            author: parsed.author,
            authorUrl: "",
            summary: description,
            description: description ? `<p>${escapeHtml(description)}</p>` : "",
            tags: [],
            license: "",
            category: "",
            thumbnailUrl: image,
            images: image ? [image] : [],
            sourceMetadataMethod: "grabcad-background-html"
        };
    } catch {
        return "";
    }
}

function parseGrabCadTitleFromText(rawTitle) {
    let title = String(rawTitle || "")
        .replace(/\s+/g, " ")
        .replace(/\s*\|\s*3D CAD Model Library\s*\|\s*GrabCAD.*$/i, "")
        .replace(/\s*-\s*GrabCAD.*$/i, "")
        .trim();
    let author = "";
    const byMatch = title.match(/^(.*?)\s+by\s+(.+)$/i);
    if (byMatch) {
        title = (byMatch[1] || "").trim();
        author = (byMatch[2] || "").trim();
    }
    return { title, author };
}

function extractGrabCadModelIdFromUrl(pageUrl) {
    try {
        const last = new URL(pageUrl).pathname.split("/").filter(Boolean).pop() || "";
        return last.match(/-(\d+)$/)?.[1] || last;
    } catch {
        return "";
    }
}

async function fetchThangsMetadata(pageUrl) {
    try {
        const response = await fetch(pageUrl, { credentials: "include" });
        if (!response.ok) return "";
        const html = await response.text();
        const title = htmlToSimpleText(extractMetaContent(html, "og:title") || extractHtmlTitle(html));
        const parsed = parseThangsTitleFromText(title);
        const description = htmlToSimpleText(extractMetaContent(html, "description") || extractMetaContent(html, "og:description"));
        const image = extractMetaContent(html, "og:image") || extractMetaContent(html, "twitter:image") || "";
        return {
            sourceUrl: pageUrl,
            title: parsed.title,
            author: parsed.author || extractThangsDesignerFromUrl(pageUrl),
            authorUrl: `https://thangs.com/designer/${encodeURIComponent(parsed.author || extractThangsDesignerFromUrl(pageUrl))}`,
            summary: description,
            description: description ? `<p>${escapeHtml(description)}</p>` : "",
            tags: [],
            thumbnailUrl: image,
            images: image ? [image] : [],
            sourceMetadataMethod: "thangs-background-html"
        };
    } catch {
        return "";
    }
}

function parseThangsTitleFromText(rawTitle) {
    let base = String(rawTitle || "").replace(/\s+/g, " ").trim();
    if (base.includes(" on Thangs")) base = base.split(" on Thangs")[0].trim();
    const marker = " - 3D model by ";
    if (!base.includes(marker)) return { title: base, author: "" };
    const parts = base.split(marker);
    return {
        title: (parts[0] || "").trim(),
        author: (parts.slice(1).join(marker) || "").trim()
    };
}

function extractThangsModelIdFromUrl(pageUrl) {
    try {
        const last = new URL(pageUrl).pathname.split("/").filter(Boolean).pop() || "";
        return last.match(/-(\d+)$/)?.[1] || "";
    } catch {
        return "";
    }
}

function extractThangsDesignerFromUrl(pageUrl) {
    try {
        const parts = new URL(pageUrl).pathname.split("/").filter(Boolean);
        const index = parts.findIndex((part) => part.toLowerCase() === "designer");
        return index >= 0 ? decodeURIComponent(parts[index + 1] || "") : "";
    } catch {
        return "";
    }
}

function extractHtmlTitle(html) {
    const match = String(html || "").match(/<title[^>]*>([\s\S]*?)<\/title>/i);
    return match ? decodeHtmlEntities(match[1]) : "";
}

async function fetchPrintablesMetadata(pageUrl) {
    try {
        const baseUrl = pageUrl.replace(/\/files\/?$/i, "").replace(/\/$/, "");
        const response = await fetch(baseUrl, { credentials: "include" });
        if (!response.ok) return "";

        const html = await response.text();
        const model = extractPrintablesModelFromHtml(html);
        if (!model) return "";

        const mediaRoot = extractPrintablesEnv(html, "PUBLIC_MEDIA_ROOT_URL") || "https://media.printables.com";
        const authorHandle = model.user?.handle || model.user?.publicUsername || "";
        const sourceImages = Array.isArray(model.images) ? model.images : [];
        const thumbnailSource = sourceImages[0] || model.image;
        const thumbnailImageKey = getPrintablesComparableImageKey(thumbnailSource);
        const thumbnailUrl = buildPrintablesImageUrl(thumbnailSource, mediaRoot, "large")
            || buildPrintablesImageUrl(model.image, mediaRoot, "cover")
            || "";
        const images = sourceImages
            .filter((image) => getPrintablesComparableImageKey(image) !== thumbnailImageKey)
            .map((image) => buildPrintablesImageUrl(image, mediaRoot, "large"))
            .filter(Boolean);

        return {
            sourceUrl: pageUrl,
            title: model.name || "",
            author: model.user?.publicUsername || authorHandle,
            authorUrl: authorHandle ? `https://www.printables.com/@${authorHandle}` : "",
            summary: model.summary || "",
            description: model.description || "",
            tags: Array.isArray(model.tags) ? model.tags.map((tag) => tag?.name).filter(Boolean) : [],
            thumbnailUrl,
            images,
            publishedAtUtc: model.datePublished || model.firstPublish || "",
            modifiedAtUtc: model.modified || "",
            sourceMetadataMethod: "printables-background-html"
        };
    } catch {
        return "";
    }
}

function extractPrintablesModelFromHtml(html) {
    const scriptPattern = /<script\b[^>]*type=["']application\/json["'][^>]*data-sveltekit-fetched[^>]*>([\s\S]*?)<\/script>/gi;
    let match;
    while ((match = scriptPattern.exec(html)) !== null) {
        try {
            const wrapper = JSON.parse(decodeHtmlEntities(match[1].trim()));
            const body = typeof wrapper.body === "string" ? JSON.parse(wrapper.body) : wrapper.body;
            const model = body?.data?.model;
            if (model?.id && model?.name) return model;
        } catch {
            // Keep scanning other embedded fetch payloads.
        }
    }

    return null;
}

function extractPrintablesEnv(html, key) {
    const needle = `"${key}":"`;
    const start = html.indexOf(needle);
    if (start < 0) return "";
    const valueStart = start + needle.length;
    const valueEnd = html.indexOf('"', valueStart);
    return valueEnd > valueStart ? html.slice(valueStart, valueEnd) : "";
}

function absolutizePrintablesMediaPath(path, mediaRoot) {
    if (!path) return "";
    if (/^https?:\/\//i.test(path)) return path;
    return `${mediaRoot.replace(/\/$/, "")}/${String(path).replace(/^\//, "")}`;
}

function buildPrintablesImageUrl(image, mediaRoot, size) {
    const path = getPrintablesImagePath(image);
    if (!path) return "";
    const absolute = absolutizePrintablesMediaPath(path, mediaRoot);
    if (!absolute || absolute.includes("/thumbs/")) return absolute;

    try {
        const url = new URL(absolute);
        const parts = url.pathname.split("/");
        const file = parts.pop();
        if (!file) return absolute;
        const format = getPrintablesThumbnailFormat(file);
        const thumbnailFile = getPrintablesThumbnailFileName(file, format);
        const thumbSize = size === "cover" ? "1200x630" : "1280x960";
        url.pathname = `${parts.join("/")}/thumbs/${size === "cover" ? "cover" : "inside"}/${thumbSize}/${format}/${thumbnailFile}`;
        return url.toString();
    } catch {
        return absolute;
    }
}

function getPrintablesImagePath(image) {
    if (!image) return "";
    if (typeof image === "string") return image;

    return image.filePath ||
        image.path ||
        image.url ||
        image.imageUrl ||
        image.fileUrl ||
        image.originalUrl ||
        image.original ||
        image.file?.filePath ||
        image.file?.path ||
        image.file?.url ||
        image.file?.downloadUrl ||
        image.image?.filePath ||
        image.image?.path ||
        image.image?.url ||
        "";
}

function getPrintablesComparableImageKey(image) {
    const path = getPrintablesImagePath(image);
    if (!path) return "";
    try {
        const url = new URL(path, "https://media.printables.com");
        return url.pathname
            .replace(/\/thumbs\/(?:cover|inside)\/[^/]+\/[^/]+\//i, "/")
            .replace(/\.[^.\/]+$/i, "")
            .toLowerCase();
    } catch {
        return String(path)
            .replace(/\/thumbs\/(?:cover|inside)\/[^/]+\/[^/]+\//i, "/")
            .replace(/\.[^.\/?#]+(?:[?#].*)?$/i, "")
            .toLowerCase();
    }
}

function getPrintablesThumbnailFormat(fileName) {
    const lower = (fileName || "").toLowerCase();
    if (lower.endsWith(".png")) return "png";
    if (lower.endsWith(".webp")) return "webp";
    if (lower.endsWith(".jpg")) return "jpg";
    return "jpeg";
}

function getPrintablesThumbnailFileName(fileName, format) {
    if (format === "jpeg") {
        return fileName.replace(/\.[^.]+$/, ".jpg");
    }

    return fileName;
}

function decodeHtmlEntities(value) {
    return String(value || "")
        .replace(/&quot;/g, '"')
        .replace(/&#34;/g, '"')
        .replace(/&#039;/g, "'")
        .replace(/&apos;/g, "'")
        .replace(/&nbsp;/g, " ")
        .replace(/&amp;/g, "&")
        .replace(/&lt;/g, "<")
        .replace(/&gt;/g, ">");
}

async function fetchThingiverseMetadata(pageUrl) {
    try {
        const response = await fetch(pageUrl.replace(/#.*$/, ""), { credentials: "include" });
        if (!response.ok) return "";

        const html = await response.text();
        const product = extractThingiverseProductFromHtml(html);
        if (!product) return "";

        return buildThingiverseMetadata(product, pageUrl, html);
    } catch {
        return "";
    }
}

function extractThingiverseProductFromHtml(html) {
    const scripts = String(html || "").match(/<script[^>]+type=["']application\/ld\+json["'][^>]*>[\s\S]*?<\/script>/gi) || [];
    for (const script of scripts) {
        const body = script.replace(/^<script[^>]*>/i, "").replace(/<\/script>$/i, "").trim();
        try {
            const data = JSON.parse(decodeHtmlEntities(body));
            const items = Array.isArray(data) ? data : [data];
            const product = items.find((item) => item?.["@type"] === "Product" && (item.sku || item.mpn || item.name));
            if (product) return product;
        } catch {
            // Keep scanning other JSON-LD blocks.
        }
    }

    return null;
}

function buildThingiverseMetadata(product, pageUrl, html) {
    const parsedTitle = parseThingiverseTitle(extractMetaContent(html, "og:title") || product.name || "");
    const author = product.mainEntityOfPage?.author || product.brand || {};
    const description = thingiversePlainTextDescriptionToHtml(product.description || extractMetaContent(html, "og:description") || extractNamedMetaContent(html, "description") || "");
    const images = collectThingiverseHtmlImages(product, html);
    const thumbnailUrl = filterThingiverseImageUrl(product.thumbnailUrl) || images[0] || filterThingiverseImageUrl(extractMetaContent(html, "og:image")) || "";

    return {
        sourceUrl: pageUrl.replace(/\/$/, ""),
        title: parsedTitle.title || product.name || "",
        author: author.name || parsedTitle.author || "",
        authorUrl: author.url || (author.name ? `https://www.thingiverse.com/${encodeURIComponent(author.name)}` : ""),
        summary: makePlainSummary(description, product.name || ""),
        description,
        tags: uniqueValues(String(product.category || "").split(",").map((part) => part.trim())),
        thumbnailUrl,
        images,
        publishedAtUtc: normalizeThingiverseDate(product.mainEntityOfPage?.datePublished),
        modifiedAtUtc: normalizeThingiverseDate(product.mainEntityOfPage?.dateModified),
        sourceMetadataMethod: "thingiverse-background-json-ld",
        stats: {
            likes: getThingiverseInteractionCount(product, "LikeAction"),
            comments: getThingiverseInteractionCount(product, "CommentAction")
        }
    };
}

function parseThingiverseTitle(rawTitle) {
    let base = String(rawTitle || "").replace(/\s+-\s+Thingiverse\s*$/i, "").trim();
    let title = base;
    let author = "";
    const byIndex = base.lastIndexOf(" by ");
    if (byIndex >= 0) {
        title = base.slice(0, byIndex).trim();
        author = base.slice(byIndex + 4).trim();
    }

    return { title, author };
}

function collectThingiverseHtmlImages(product, html) {
    const urls = [];
    const add = (url) => {
        if (!url || typeof url !== "string") return;
        const clean = filterThingiverseImageUrl(url);
        if (!clean) return;
        urls.push(clean);
    };

    (Array.isArray(product.image) ? product.image : [product.image]).forEach(add);
    add(product.thumbnailUrl);
    add(extractMetaContent(html, "og:image"));

    return uniqueValues(urls).slice(0, 12);
}

function filterThingiverseImageUrl(url) {
    const clean = unwrapThingiverseResizeUrl(decodeHtmlEntities(url).trim());
    if (!/^https?:\/\//i.test(clean)) return "";
    const lower = clean.toLowerCase();
    if (lower.includes("/site/img/thingiverseopengraph") || lower.includes("/site/img/favicons/")) return "";
    if (/\/(?:avatar|avatars|profile|profiles|user|users|favicons?|logo|logos?)\b/.test(lower)) return "";
    return clean;
}

function unwrapThingiverseResizeUrl(url) {
    try {
        const parsed = new URL(url);
        if (parsed.hostname.toLowerCase() !== "resize.thingiverse.com") return url;
        return parsed.searchParams.get("url") || url;
    } catch {
        return url;
    }
}

function thingiversePlainTextDescriptionToHtml(text) {
    const clean = normalizeThingiverseText(text);
    if (!clean) return "";

    const sectionNames = ["Features", "Print Settings", "How it's made", "How it’s made", "Post-Printing", "Custom Section", "Instructions"];
    const pattern = new RegExp(`(${sectionNames.map((name) => name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")).join("|")})`, "gi");
    const parts = clean
        .replace(pattern, "\n\n$1\n")
        .split(/\n{2,}/)
        .map((part) => part.trim())
        .filter(Boolean);

    return parts.map((part) => {
        if (sectionNames.some((name) => name.toLowerCase() === part.toLowerCase())) {
            return `<h3>${escapeHtml(part)}</h3>`;
        }

        return `<p>${escapeHtml(part)}</p>`;
    }).join("");
}

function normalizeThingiverseDate(value) {
    if (!value) return "";
    const parsed = new Date(value);
    return Number.isNaN(parsed.getTime()) ? "" : parsed.toISOString();
}

function normalizeThingiverseText(value) {
    return decodeHtmlEntities(value)
        .replace(/\u00a0/g, " ")
        .replace(/\uFFFD/g, "")
        .replace(/\s+/g, " ")
        .trim();
}

function getThingiverseInteractionCount(product, interactionName) {
    const stats = product.mainEntityOfPage?.interactionStatistic;
    if (!Array.isArray(stats)) return null;
    const stat = stats.find((item) => String(item.interactionType || "").includes(interactionName));
    return asNumberOrNull(stat?.userInteractionCount);
}

function extractThingiverseId(url) {
    return String(url || "").match(/thing:(\d+)/i)?.[1] || "";
}

function extractNamedMetaContent(html, name) {
    const escaped = name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    const pattern = new RegExp(`<meta[^>]+name=["']${escaped}["'][^>]+content=["']([^"']*)["']`, "i");
    const match = String(html || "").match(pattern);
    return match ? decodeHtmlEntities(match[1]) : "";
}

function escapeHtml(value) {
    return String(value || "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;");
}

async function fetchMakerWorldMetadata(pageUrl) {
    try {
        const response = await fetch(pageUrl.replace(/#.*$/, ""), { credentials: "include" });
        if (!response.ok) return "";

        const html = await response.text();
        const design = extractMakerWorldDesignFromHtml(html, pageUrl);
        if (!design) return "";

        return buildMakerWorldMetadata(design, pageUrl, html);
    } catch {
        return "";
    }
}

function extractMakerWorldDesignFromHtml(html, pageUrl = "") {
    const match = html.match(/<script[^>]+id=["']__NEXT_DATA__["'][^>]*>([\s\S]*?)<\/script>/i);
    if (!match) return null;

    try {
        const data = JSON.parse(decodeHtmlEntities(match[1]));
        const design = data?.props?.pageProps?.design;
        if (!design?.id || !design?.title) return null;
        return makerWorldDesignMatchesPageUrl(design, pageUrl) ? design : null;
    } catch {
        return null;
    }
}

function makerWorldDesignMatchesPageUrl(design, pageUrl) {
    const pageModelId = extractMakerWorldModelIdFromUrl(pageUrl);
    if (!pageModelId) return true;
    const designIds = [
        design.modelId,
        design.id,
        design.designId
    ].map((value) => String(value || "").trim()).filter(Boolean);
    return designIds.includes(pageModelId);
}

function extractMakerWorldModelIdFromUrl(pageUrl) {
    try {
        const path = new URL(pageUrl || "").pathname;
        return path.match(/\/models\/(\d+)/i)?.[1] || "";
    } catch {
        return String(pageUrl || "").match(/\/models\/(\d+)/i)?.[1] || "";
    }
}

function buildMakerWorldMetadata(design, pageUrl, html) {
    const creator = design.designCreator || {};
    const authorHandle = creator.handle || "";
    const description = cleanMakerWorldDescriptionHtml(design.summaryTranslated || design.summary || "");
    const images = collectMakerWorldImages(design);
    const thumbnailUrl = design.coverUrl || images[0] || extractMetaContent(html, "og:image") || "";
    const tags = Array.isArray(design.tagsOriginal) && design.tagsOriginal.length > 0
        ? design.tagsOriginal.map(getMakerWorldTagName).filter(Boolean)
        : Array.isArray(design.tags)
            ? design.tags.map(getMakerWorldTagName).filter(Boolean)
            : [];

    return {
        sourceUrl: pageUrl,
        title: design.titleTranslated || design.title || "",
        author: creator.name || "",
        authorUrl: authorHandle ? `https://makerworld.com/en/@${authorHandle}` : "",
        summary: makePlainSummary(description, design.title || ""),
        description,
        tags: uniqueValues(tags),
        thumbnailUrl,
        images,
        publishedAtUtc: design.createTime || "",
        modifiedAtUtc: design.updateTime || "",
        sourceMetadataMethod: "makerworld-background-next-data",
        makerWorld: {
            modelId: design.modelId || "",
            defaultProfileId: design.defaultInstanceId || "",
            printProfiles: Array.isArray(design.instances)
                ? design.instances.map(toMakerWorldProfileSummary).filter(Boolean)
                : [],
            modelFiles: design.designExtension?.model_files?.map(toMakerWorldFileSummary).filter(Boolean) || []
        },
        stats: {
            likes: asNumberOrNull(design.likeCount),
            downloads: asNumberOrNull(design.downloadCount),
            rawModelDownloads: asNumberOrNull(design.rawModelFileDownloadCount),
            prints: asNumberOrNull(design.printCount),
            comments: asNumberOrNull(design.commentCount),
            collections: asNumberOrNull(design.collectionCount)
        }
    };
}

function collectMakerWorldImages(design) {
    const urls = [];
    const add = (url) => {
        if (!url || typeof url !== "string") return;
        const clean = url.replace(/&amp;/g, "&").trim();
        if (/^https?:\/\//i.test(clean)) urls.push(clean);
    };

    add(design.coverUrl);
    add(design.coverPortrait);
    add(design.coverLandscape);
    if (Array.isArray(design.designExtension?.design_pictures)) {
        design.designExtension.design_pictures.forEach((picture) => add(picture?.url || picture?.imageUrl || picture?.cover));
    }
    if (Array.isArray(design.instances)) {
        design.instances.forEach((profile) => {
            add(profile?.cover);
            if (Array.isArray(profile?.pictures)) {
                profile.pictures.forEach((picture) => add(picture?.url || picture?.imageUrl || picture?.cover));
            }
        });
    }

    return uniqueValues(urls).slice(0, 12);
}

function cleanMakerWorldDescriptionHtml(html) {
    return String(html || "")
        .replace(/<script\b[\s\S]*?<\/script>/gi, "")
        .replace(/<style\b[\s\S]*?<\/style>/gi, "")
        .replace(/<commercialme\b[\s\S]*?<\/commercialme>/gi, "")
        .replace(/<boostme\b[\s\S]*?<\/boostme>/gi, "")
        .replace(/<p>\s*commercial licensing available\s*<\/p>/gi, "")
        .trim();
}

function makePlainSummary(html, fallback) {
    const blocks = String(html || "").match(/<(?:p|li)\b[^>]*>[\s\S]*?<\/(?:p|li)>/gi) || [];
    for (const block of blocks) {
        const text = htmlToSimpleText(block);
        if (text) return text;
    }

    return fallback || "";
}

function htmlToSimpleText(html) {
    return decodeHtmlEntities(String(html || "")
        .replace(/<br\s*\/?>/gi, " ")
        .replace(/<[^>]*>/g, " "))
        .replace(/\u00a0/g, " ")
        .replace(/\uFFFD/g, "")
        .replace(/\)([A-Z])/g, ") $1")
        .replace(/\s+/g, " ")
        .trim();
}

function getMakerWorldTagName(tag) {
    if (!tag) return "";
    if (typeof tag === "string") return tag.trim();
    return (tag.name || tag.tagName || tag.displayName || tag.value || tag.label || "").trim();
}

function toMakerWorldProfileSummary(profile) {
    if (!profile) return null;
    const compatibility = profile.extention?.modelInfo?.compatibility || {};
    return {
        profileId: profile.profileId || "",
        title: profile.title || "",
        cover: profile.cover || "",
        printer: compatibility.devProductName || "",
        nozzleDiameter: compatibility.nozzleDiameter ?? null,
        weightGrams: profile.weight ?? null,
        needsAms: Boolean(profile.needAms),
        downloadCount: asNumberOrNull(profile.downloadCount),
        printCount: asNumberOrNull(profile.printCount)
    };
}

function toMakerWorldFileSummary(file) {
    if (!file) return null;
    return {
        name: file.modelName || file.modelFileName || "",
        type: file.modelType || "",
        sizeBytes: asNumberOrNull(file.modelSize),
        updatedAtUtc: file.modelUpdateTime || "",
        thumbnailUrl: file.thumbnailUrl || ""
    };
}

function extractMetaContent(html, propertyName) {
    const escaped = propertyName.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    const pattern = new RegExp(`<meta[^>]+property=["']${escaped}["'][^>]+content=["']([^"']*)["']`, "i");
    const match = String(html || "").match(pattern);
    return match ? decodeHtmlEntities(match[1]) : "";
}

function uniqueValues(values) {
    const seen = new Set();
    return values
        .map((value) => String(value || "").trim())
        .filter((value) => {
            if (!value) return false;
            const key = value.toLowerCase();
            if (seen.has(key)) return false;
            seen.add(key);
            return true;
        });
}

function asNumberOrNull(value) {
    const number = Number(value);
    return Number.isFinite(number) ? number : null;
}

function chooseTriggerPageUrl(tabId, tabUrl, referrer) {
    const candidates = [
        tabUrl,
        typeof tabId === "number" ? pageUrlByTab.get(tabId) : "",
        referrer,
        lastSupportedPageUrl
    ];

    return candidates.find(isUsefulPageUrl) || candidates.find(Boolean) || "";
}

async function resolveStatusTabId(downloadTabId, pageUrl, tabUrl) {
    if (typeof downloadTabId === "number" && downloadTabId >= 0) return downloadTabId;

    const matched = await findTabForPageUrl(pageUrl);
    if (matched != null) return matched;

    const matchedKnown = await findTabForPageUrl(tabUrl);
    if (matchedKnown != null) return matchedKnown;

    return typeof downloadTabId === "number" ? downloadTabId : -1;
}

async function findTabForPageUrl(pageUrl) {
    if (!pageUrl) return null;
    let target;
    try {
        target = new URL(pageUrl);
    } catch {
        return null;
    }

    const targetModelKey = getModelPageKey(target.href);
    const tabs = await chrome.tabs.query({}).catch(() => []);
    for (const tab of tabs) {
        if (typeof tab.id !== "number" || !tab.url) continue;
        const tabModelKey = getModelPageKey(tab.url);
        if (targetModelKey && tabModelKey === targetModelKey) return tab.id;
        try {
            const candidate = new URL(tab.url);
            if (candidate.href === target.href) return tab.id;
            if (candidate.origin === target.origin && candidate.pathname === target.pathname) return tab.id;
        } catch {
            // Keep looking.
        }
    }
    return null;
}

function getModelPageKey(url) {
    try {
        const parsed = new URL(url);
        const host = parsed.hostname.toLowerCase();
        const path = parsed.pathname.toLowerCase();
        if (host.includes("printables.com")) return path.match(/\/model\/[^/]+/)?.[0] || "";
        if (host.includes("thingiverse.com")) return path.match(/\/thing:\d+/)?.[0] || "";
        if (host.includes("makerworld.com")) return path.match(/\/models\/[^/]+/)?.[0] || "";
        if (host.includes("thangs.com")) return path.match(/\/3d-model\/[^/]+/)?.[0] || "";
        if (host.includes("cults3d.com")) return path.match(/\/3d-model\/[^/]+\/[^/]+/)?.[0] || "";
        if (host.includes("grabcad.com")) return path.match(/\/library\/[^/]+/)?.[0] || "";
        if (host.includes("myminifactory.com")) return path.match(/\/objects?\/[^/]+/)?.[0] || "";
        if (host.includes("tinkercad.com")) return path.match(/\/things\/[^/]+/)?.[0] || "";
        return "";
    } catch {
        return "";
    }
}

function isUsefulPageUrl(url) {
    if (!url || !/^https?:\/\//i.test(url)) return false;
    try {
        const parsed = new URL(url);
        if (!isSupportedUrl(url)) return false;
        return parsed.pathname && parsed.pathname !== "/";
    } catch {
        return false;
    }
}

function buildImportMetadata(rawMeta, defaults) {
    const scraped = normalizeScrapedMetadata(rawMeta, defaults.fallbackTitle, defaults.sourceUrl);
    const sourceUrl = chooseSourcePageUrl(scraped.sourceUrl, defaults.sourceUrl);
    const title = chooseMetadataTitle(scraped.title, defaults.fallbackTitle, defaults.fileName, sourceUrl);
    const metadata = {
        schemaVersion: 1,
        fileName: defaults.fileName || "",
        folder: defaults.folder || "Unsorted",
        sourceUrl,
        downloadUrl: defaults.downloadUrl || "",
        title,
        author: scraped.author || "",
        authorUrl: scraped.authorUrl || "",
        description: scraped.description || "",
        printSettingsJson: scraped.printSettingsJson || "",
        tags: scraped.tags || [],
        thumbnailUrl: scraped.thumbnailUrl || "",
        capturedAtUtc: new Date().toISOString(),
        summary: scraped.summary || "",
        images: scraped.images || []
    };
    logImportMetadataImages(metadata, scraped);
    return metadata;
}

function logImportMetadataImages(metadata, scraped) {
    try {
        console.log("MeshVault Connect scraped images", {
            sourceSite: scraped.sourceSite || getSourceSite(metadata.sourceUrl),
            title: metadata.title,
            sourceUrl: metadata.sourceUrl,
            thumbnailUrl: metadata.thumbnailUrl,
            imageCount: Array.isArray(metadata.images) ? metadata.images.length : 0,
            images: Array.isArray(metadata.images) ? metadata.images : []
        });
    } catch (_) {
        // Logging must never block an import.
    }
}

function normalizeScrapedMetadata(rawMeta, fallbackTitle, fallbackPageUrl) {
    if (rawMeta && typeof rawMeta === "object" && !Array.isArray(rawMeta)) {
        const sourceSite = rawMeta.sourceSite || "";
        const isCults = sourceSite.toLowerCase() === "cults3d";
        return {
            sourceSite,
            title: rawMeta.title || fallbackTitle || "",
            thumbnailUrl: rawMeta.thumbnailUrl || rawMeta.image || "",
            sourceUrl: chooseSourcePageUrl(rawMeta.sourceUrl || rawMeta.pageUrl || "", fallbackPageUrl),
            author: rawMeta.author || "",
            authorUrl: rawMeta.authorUrl || "",
            description: rawMeta.description || "",
            printSettingsJson: isCults ? "" : (rawMeta.printSettingsJson || rawMeta.printSettings || ""),
            tags: Array.isArray(rawMeta.tags) ? rawMeta.tags.filter(Boolean) : splitTags(rawMeta.tags || ""),
            summary: rawMeta.summary || "",
            images: Array.isArray(rawMeta.images) ? rawMeta.images.filter(Boolean) : [],
            publishedAtUtc: rawMeta.publishedAtUtc || rawMeta.datePublished || "",
            modifiedAtUtc: rawMeta.modifiedAtUtc || rawMeta.modified || ""
        };
    }

    const parts = typeof rawMeta === "string" ? rawMeta.split("|||") : [];
    const scrapedPageUrl = parts[2] || "";
    return {
        title: parts[0] || fallbackTitle || "",
        thumbnailUrl: parts[1] || "",
        sourceUrl: chooseSourcePageUrl(scrapedPageUrl, fallbackPageUrl),
        author: parts[3] || "",
        authorUrl: parts[4] || "",
        tags: splitTags(parts[5] || ""),
        summary: "",
        images: [],
        description: parts[6] || "",
        printSettingsJson: "",
        publishedAtUtc: "",
        modifiedAtUtc: ""
    };
}

function chooseMetadataTitle(scrapedTitle, fallbackTitle, fileName, sourceUrl) {
    const candidates = [scrapedTitle, fallbackTitle, fileName]
        .map((value) => String(value || "").trim())
        .filter(Boolean);
    const isGrabCad = String(sourceUrl || "").toLowerCase().includes("grabcad.com");
    for (const candidate of candidates) {
        if (isGrabCad && isGenericGrabCadTitle(candidate)) continue;
        return candidate;
    }
    return candidates[0] || "";
}

function isGenericGrabCadTitle(value) {
    const clean = String(value || "").trim().toLowerCase();
    return /^original(?:\.[a-z0-9]+)?$/.test(clean)
        || /^download(?:\.[a-z0-9]+)?$/.test(clean)
        || /^file(?:\.[a-z0-9]+)?$/.test(clean);
}

function splitTags(value) {
    return String(value || "")
        .split(",")
        .map((tag) => tag.trim())
        .filter((tag, index, all) => tag && all.findIndex((candidate) => candidate.toLowerCase() === tag.toLowerCase()) === index);
}

function getSourceSite(url) {
    try {
        const host = new URL(url).hostname.toLowerCase();
        if (host.includes("printables.com")) return "Printables";
        if (host.includes("thingiverse.com")) return "Thingiverse";
        if (host.includes("makerworld.com")) return "MakerWorld";
        if (host.includes("thangs.com")) return "Thangs";
        if (host.includes("cults3d.com")) return "Cults3D";
        if (host.includes("grabcad.com")) return "GrabCAD";
        if (host.includes("myminifactory.com")) return "MyMiniFactory";
        if (host.includes("tinkercad.com")) return "Tinkercad";
        return host;
    } catch {
        return "";
    }
}

function chooseSourcePageUrl(scrapedPageUrl, fallbackPageUrl) {
    if (!scrapedPageUrl) return fallbackPageUrl || "";
    if (!fallbackPageUrl) return scrapedPageUrl;

    try {
        const scraped = new URL(scrapedPageUrl);
        const fallback = new URL(fallbackPageUrl);
        const scrapedIsOriginOnly = scraped.pathname === "/" && !scraped.search && !scraped.hash;
        if (scrapedIsOriginOnly && scraped.origin === fallback.origin && fallback.href.length > scraped.href.length) {
            return fallback.href;
        }
    } catch {
        return scrapedPageUrl;
    }

    return scrapedPageUrl;
}

async function isDesktopAvailable() {
    return (await getMeshVaultAvailability()).available;
}

async function getMeshVaultAvailability() {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 1200);
    try {
        const target = await getMeshVaultTarget();
        const statusPath = target.serverMode ? "/api/status" : "/status";
        const response = await fetch(`${target.baseUrl}${statusPath}`, {
            method: "GET",
            headers: target.headers,
            signal: controller.signal
        });
        if (!response.ok) return { available: false, readOnly: response.status === 402 };

        const status = await response.json().catch(() => null);
        const readOnly = status?.isReadOnly === true || status?.isProUnlocked === false;
        return { available: !readOnly, readOnly };
    } catch {
        return { available: false, readOnly: false };
    } finally {
        clearTimeout(timeoutId);
    }
}

async function maybeNotifyReadOnly(pageUrl = "") {
    if (!await isExtensionEnabled()) return;
    const siteKey = `readonly:${getOfflineNotificationSiteKey(pageUrl)}`;
    if (await hasOfflineNotificationBeenShown(siteKey)) return;
    await markOfflineNotificationShown(siteKey);
    notify("MeshVault Connect", "MeshVault Server is read-only, so this download will use the browser normally.");
}

async function maybeNotifyOffline(pageUrl = "") {
    if (!await isExtensionEnabled()) return;
    const enabled = await getStoredBoolean("notifyDesktopOffline", true);
    if (!enabled) return;
    const siteKey = getOfflineNotificationSiteKey(pageUrl);
    if (await hasOfflineNotificationBeenShown(siteKey)) return;
    await markOfflineNotificationShown(siteKey);
    notify("MeshVault Connect", "Start MeshVault or MeshVault Server to capture model downloads.");
}

function getOfflineNotificationSiteKey(url) {
    const domain = getSiteDomainForUrl(url);
    if (domain) return domain;
    try {
        return new URL(url || "").hostname.toLowerCase() || "unknown";
    } catch {
        return "unknown";
    }
}

async function hasOfflineNotificationBeenShown(siteKey) {
    if (offlineNotifiedSites.has(siteKey)) return true;
    if (!chrome.storage.session?.get) return false;
    const result = await chrome.storage.session.get({ offlineNotifiedSites: [] }).catch(() => ({ offlineNotifiedSites: [] }));
    const sites = Array.isArray(result.offlineNotifiedSites) ? result.offlineNotifiedSites : [];
    sites.forEach((site) => offlineNotifiedSites.add(site));
    return offlineNotifiedSites.has(siteKey);
}

async function markOfflineNotificationShown(siteKey) {
    offlineNotifiedSites.add(siteKey);
    if (!chrome.storage.session?.set) return;
    const sites = Array.from(offlineNotifiedSites);
    await chrome.storage.session.set({ offlineNotifiedSites: sites }).catch(() => {});
}

function isSupportedDownload(downloadItem, pageUrl) {
    const url = getDownloadItemUrl(downloadItem);
    if (isIgnoredDownloadUrl(url)) return false;
    const ext = getExtension(url) || getExtension(downloadItem.filename || "");
    if (isCultsDownloadCandidate(downloadItem) && !isCultsDownloadContextPage(pageUrl)) return false;
    if ((ext && MODEL_EXTENSIONS.has(ext)) && isSupportedUrl(pageUrl || url)) return true;
    if (isKnownDownloadHost(url) && isSupportedUrl(pageUrl || url)) return true;
    if (looksLikeThingiverseZip(url) && isSupportedUrl(pageUrl || url)) return true;
    if (looksLikeCultsModelDownload(downloadItem, pageUrl)) return true;
    return false;
}

function isIgnoredDownloadUrl(url) {
    if (consumeBrowserFallbackDownload(url)) return true;
    try {
        const parsed = new URL(url || "");
        const host = parsed.hostname.toLowerCase();
        const path = parsed.pathname.toLowerCase();
        if (host.includes("fuseplatform.net")) return true;
        if (path.includes("/telemetry/") || path.includes("/analytics/") || path.includes("/collect")) return true;
        if (host.includes("googletagmanager.com") || host.includes("google-analytics.com")) return true;
        return false;
    } catch {
        return false;
    }
}

function consumeBrowserFallbackDownload(url) {
    const key = normalizeDownloadIgnoreKey(url);
    if (!key || !browserFallbackDownloadUrls.has(key)) return false;

    const expiresAt = browserFallbackDownloadUrls.get(key) || 0;
    browserFallbackDownloadUrls.delete(key);
    return expiresAt > Date.now();
}

function looksLikeCultsModelDownload(downloadItem, pageUrl) {
    if (!isCultsModelPage(pageUrl)) return false;
    const url = getDownloadItemUrl(downloadItem);
    const filename = getFileName(downloadItem.filename || "") || getFileNameFromUrl(url);
    const ext = getExtension(filename) || getExtension(url);
    if (ext && MODEL_EXTENSIONS.has(ext)) return true;

    const lowerUrl = String(url || "").toLowerCase();
    const mime = String(downloadItem.mime || "").toLowerCase();
    if (mime.startsWith("image/") || /\.(?:png|jpe?g|gif|webp|svg)(?:[?#]|$)/i.test(lowerUrl)) return false;
    if (lowerUrl.includes("cults3d.com") && /(?:download|active_storage|rails\/active_storage|blob|attachment)/i.test(lowerUrl)) return true;
    if (/application\/(?:zip|octet-stream|x-zip-compressed)/i.test(mime)) return true;
    return false;
}

function getDownloadItemUrl(downloadItem) {
    return downloadItem?.finalUrl || downloadItem?.url || "";
}

function isCultsDownloadHost(url) {
    try {
        const host = new URL(url || "").hostname.toLowerCase();
        return host.includes("download.cults3d.com")
            || host.includes("downloader.cults3d.com");
    } catch {
        return false;
    }
}

function isCultsDownloadCandidate(downloadItem) {
    const url = getDownloadItemUrl(downloadItem);
    const lowerUrl = String(url || "").toLowerCase();
    if (!lowerUrl.includes("cults3d.com")) return false;
    const ext = getExtension(downloadItem?.filename || "") || getExtension(url);
    if (ext && MODEL_EXTENSIONS.has(ext)) return true;
    return isCultsDownloadHost(url)
        || /(?:download|active_storage|rails\/active_storage|blob|attachment)/i.test(lowerUrl)
        || /application\/(?:zip|octet-stream|x-zip-compressed)/i.test(String(downloadItem?.mime || ""));
}

function isCultsModelPage(url) {
    try {
        const parsed = new URL(url || "");
        return parsed.hostname.toLowerCase().includes("cults3d.com")
            && parsed.pathname.toLowerCase().includes("/3d-model/");
    } catch {
        return false;
    }
}

function isMakerWorldModelPage(url) {
    try {
        const parsed = new URL(url || "");
        return parsed.hostname.toLowerCase().includes("makerworld.com")
            && parsed.pathname.toLowerCase().includes("/models/");
    } catch {
        return false;
    }
}

function isTinkercadModelPage(url) {
    try {
        const parsed = new URL(url || "");
        return parsed.hostname.toLowerCase().includes("tinkercad.com")
            && parsed.pathname.toLowerCase().includes("/things/");
    } catch {
        return false;
    }
}

function isCultsDownloadContextPage(url) {
    try {
        const parsed = new URL(url || "");
        const host = parsed.hostname.toLowerCase();
        const path = parsed.pathname.toLowerCase();
        return host.includes("cults3d.com")
            && (path.includes("/3d-model/") || path.includes("/orders/"));
    } catch {
        return false;
    }
}

function isStaleRestoredDownload(downloadItem) {
    if (!downloadItem?.startTime) return false;
    const startedAt = Date.parse(downloadItem.startTime);
    if (!Number.isFinite(startedAt)) return false;
    return startedAt < serviceWorkerStartedAt - STALE_DOWNLOAD_GRACE_MS;
}

function isSupportedUrl(url) {
    const lower = (url || "").toLowerCase();
    return Object.keys(SITE_SCRAPERS).some((domain) => lower.includes(domain)) || isKnownDownloadHost(lower);
}

function isSupportedSitePage(url) {
    const lower = (url || "").toLowerCase();
    return Object.keys(SITE_SCRAPERS).some((domain) => lower.includes(domain));
}

function updateActionIconForTab(tabId, url) {
    if (typeof tabId !== "number" || tabId < 0) return;
    const siteDisabled = isSiteDisabledForUrl(url);
    if (!extensionEnabled) {
        chrome.action.setIcon({
            tabId,
            path: DISABLED_ICON_PATHS
        }, () => void chrome.runtime.lastError);
        chrome.action.setTitle({
            tabId,
            title: "MeshVault Connect: disabled"
        }, () => void chrome.runtime.lastError);
        chrome.action.setBadgeText({
            tabId,
            text: "OFF"
        }, () => void chrome.runtime.lastError);
        chrome.action.setBadgeBackgroundColor({
            tabId,
            color: "#c93b3b"
        }, () => void chrome.runtime.lastError);
        return;
    }

    if (siteDisabled) {
        chrome.action.setIcon({
            tabId,
            path: INACTIVE_ICON_PATHS
        }, () => void chrome.runtime.lastError);
        chrome.action.setTitle({
            tabId,
            title: `MeshVault Connect: disabled on ${getSiteLabelForUrl(url)}`
        }, () => void chrome.runtime.lastError);
        chrome.action.setBadgeText({
            tabId,
            text: "SITE"
        }, () => void chrome.runtime.lastError);
        chrome.action.setBadgeBackgroundColor({
            tabId,
            color: "#9a7cff"
        }, () => void chrome.runtime.lastError);
        return;
    }

    const supported = isSupportedSitePage(url);
    chrome.action.setIcon({
        tabId,
        path: supported ? ACTIVE_ICON_PATHS : INACTIVE_ICON_PATHS
    }, () => void chrome.runtime.lastError);
    chrome.action.setTitle({
        tabId,
        title: supported ? "MeshVault Connect: supported site" : "MeshVault Connect: unsupported site"
    }, () => void chrome.runtime.lastError);
    chrome.action.setBadgeText({
        tabId,
        text: activeDownloads > 0 ? String(activeDownloads) : ""
    }, () => void chrome.runtime.lastError);
    chrome.action.setBadgeBackgroundColor({
        tabId,
        color: "#2f9e62"
    }, () => void chrome.runtime.lastError);
}

async function updateActionIconForTabId(tabId) {
    if (typeof tabId !== "number" || tabId < 0) return;
    const tab = await chrome.tabs.get(tabId).catch(() => null);
    updateActionIconForTab(tabId, tab?.url || "");
}

async function refreshAllTabIcons() {
    const tabs = await chrome.tabs.query({}).catch(() => []);
    for (const tab of tabs) {
        if (tab.id != null) updateActionIconForTab(tab.id, tab.url || "");
    }
}

function isKnownDownloadHost(url) {
    const lower = (url || "").toLowerCase();
    return lower.includes("storage.googleapis.com/gcp-and-physna.appspot.com/uploads/models/") ||
        lower.includes("downloader.cults3d.com") ||
        lower.includes("download.cults3d.com") ||
        lower.includes("s3.amazonaws.com/gc-p/cads/files/");
}

function getScraperFile(url) {
    const lower = (url || "").toLowerCase();
    for (const [domain, file] of Object.entries(SITE_SCRAPERS)) {
        if (lower.includes(domain)) return file;
    }
    return "";
}

function normalizeDisabledSites(value) {
    const normalized = {};
    if (!value || typeof value !== "object" || Array.isArray(value)) return normalized;
    for (const domain of Object.keys(SITE_SCRAPERS)) {
        normalized[domain] = Boolean(value[domain]);
    }
    return normalized;
}

function getSiteDomainForUrl(url) {
    try {
        const host = new URL(url || "").hostname.toLowerCase();
        return Object.keys(SITE_SCRAPERS).find((domain) => host === domain || host.endsWith(`.${domain}`)) || "";
    } catch {
        const lower = String(url || "").toLowerCase();
        return Object.keys(SITE_SCRAPERS).find((domain) => lower.includes(domain)) || "";
    }
}

function getSiteLabelForUrl(url) {
    const domain = getSiteDomainForUrl(url);
    return getSiteLabel(domain) || "this site";
}

function getSiteLabel(domain) {
    if (domain === "printables.com") return "Printables";
    if (domain === "thingiverse.com") return "Thingiverse";
    if (domain === "makerworld.com") return "MakerWorld";
    if (domain === "thangs.com") return "Thangs";
    if (domain === "cults3d.com") return "Cults3D";
    if (domain === "grabcad.com") return "GrabCAD";
    if (domain === "myminifactory.com") return "MyMiniFactory";
    if (domain === "tinkercad.com") return "Tinkercad";
    return domain || "";
}

function isSiteDisabledForUrl(url) {
    const domain = getSiteDomainForUrl(url);
    return Boolean(domain && disabledSites[domain]);
}

function normalizeDownloadUrl(url, pageUrl) {
    if (pageUrl && pageUrl.includes("thingiverse.com/thing:") && isThingiverseUrl(url) && !getExtension(url)) {
        return buildThingiverseZipUrl(pageUrl) || url;
    }
    return url;
}

function isThingiverseUrl(url) {
    try {
        return new URL(url || "").hostname.toLowerCase().includes("thingiverse.com");
    } catch {
        return false;
    }
}

function buildThingiverseZipUrl(pageUrl) {
    try {
        const parsed = new URL(pageUrl);
        if (!parsed.hostname.includes("thingiverse.com")) return "";
        parsed.hash = "";
        parsed.pathname = parsed.pathname.replace(/\/files\/?$/, "").replace(/\/zip\/?$/, "");
        return parsed.toString().replace(/\/$/, "") + "/zip";
    } catch {
        return "";
    }
}

function looksLikeThingiverseZip(url) {
    try {
        const parsed = new URL(url || "");
        const host = parsed.hostname.toLowerCase();
        const path = parsed.pathname.toLowerCase();
        return host.includes("thingiverse.com") && (path.includes("/zip") || path.includes("/download"));
    } catch {
        return false;
    }
}

function parseDispositionFilename(value) {
    const match = value.match(/filename\*=UTF-8''([^;]+)|filename="?([^";]+)"?/i);
    if (!match) return "";
    try {
        return decodeURIComponent(match[1] || match[2] || "").trim();
    } catch {
        return (match[1] || match[2] || "").trim();
    }
}

function ensureFilename(name, url, contentType) {
    const grabCadName = extractGrabCadFilename(name, url);
    if (grabCadName) return grabCadName;

    const extracted = extractSupportedFilename(name);
    if (extracted && !isGenericThingiverseBlobName(extracted)) return extracted;

    const clean = safeFilename(getFileName(name) || "meshvault-download");
    const cleanExt = getExtension(clean);
    if (cleanExt && MODEL_EXTENSIONS.has(cleanExt) && !isGenericThingiverseBlobName(clean)) return clean;

    const urlExt = getExtension(url);
    const ext = (urlExt && MODEL_EXTENSIONS.has(urlExt) ? urlExt : "")
        || extensionFromContentType(contentType)
        || "zip";
    const base = isGenericThingiverseBlobName(clean)
        ? "thingiverse-download"
        : cleanExt && !MODEL_EXTENSIONS.has(cleanExt)
        ? safeFilename(clean.slice(0, -(cleanExt.length + 1))) || "meshvault-download"
        : clean;
    return `${base}.${ext}`;
}

function chooseFinalImportFilename(filename, metadata, pageUrl, downloadUrl, contentType) {
    const sourceUrl = metadata?.sourceUrl || pageUrl || "";
    if (!isTinkercadModelPage(sourceUrl) || !isGenericTinkercadFilename(filename)) return filename;

    const title = cleanTinkercadTitle(metadata?.title || titleFromTinkercadUrl(sourceUrl));
    if (isGenericTinkercadTitle(title)) return filename;

    const ext = getExtension(filename)
        || getExtension(downloadUrl)
        || extensionFromContentType(contentType)
        || "zip";
    const base = safeFilename(title);
    return base ? `${base}.${ext}` : filename;
}

function isGenericTinkercadFilename(filename) {
    const clean = String(filename || "").trim().toLowerCase();
    return /^(?:polysoup|download|file|model|meshvault-download)(?:\.[a-z0-9]+)?$/.test(clean);
}

function titleFromTinkercadUrl(value) {
    try {
        const path = new URL(value || "").pathname;
        const slug = path.match(/\/things\/[^/]+-([^/?#]+)/i)?.[1] || "";
        return slug
            .split("-")
            .filter(Boolean)
            .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
            .join(" ");
    } catch {
        return "";
    }
}

function extractGrabCadFilename(name, url) {
    const candidates = [];
    try {
        const parsed = new URL(url || "");
        ["response-content-disposition", "filename", "file", "key"].forEach((key) => {
            const value = parsed.searchParams.get(key);
            if (!value) return;
            candidates.push(value);
            candidates.push(decodeURIComponent(value));
            const dispositionName = parseDispositionFilename(value);
            if (dispositionName) candidates.push(dispositionName);
        });
        candidates.push(decodeURIComponent(parsed.pathname.split("/").pop() || ""));
    } catch {
        // Fall through to the supplied name.
    }
    candidates.push(name || "");

    for (const candidate of candidates) {
        const supported = extractSupportedFilename(candidate);
        if (supported && !/^original\.[a-z0-9]+$/i.test(supported)) return supported;
    }
    return "";
}

function isGenericThingiverseBlobName(filename) {
    return /^(?:image|download|blob|file)\.(?:zip|stl|3mf|obj)$/i.test(String(filename || "").trim());
}

function extractSupportedFilename(value) {
    const raw = String(value || "").replace(/\s+/g, " ").trim();
    if (!raw) return "";
    const extensions = Array.from(MODEL_EXTENSIONS)
        .map((ext) => ext.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"))
        .join("|");
    const pattern = new RegExp(`[A-Za-z0-9][A-Za-z0-9._ ()\\[\\]-]*\\.(${extensions})\\b`, "i");
    const match = raw.match(pattern);
    return match ? safeFilename(match[0]) : "";
}

function extensionFromContentType(contentType) {
    const lower = (contentType || "").toLowerCase();
    if (lower.includes("zip")) return "zip";
    if (lower.includes("3mf")) return "3mf";
    if (lower.includes("stl")) return "stl";
    return "";
}

function getExtension(url) {
    try {
        const clean = (url || "").split("?")[0].split("#")[0];
        const last = clean.split(/[\\/]/).pop() || "";
        const dot = last.lastIndexOf(".");
        return dot > 0 ? last.slice(dot + 1).toLowerCase() : "";
    } catch {
        return "";
    }
}

function getFileName(path) {
    return (path || "").split(/[\\/]/).pop() || "";
}

function getFileNameFromUrl(url) {
    try {
        return decodeURIComponent(new URL(url).pathname.split("/").pop() || "");
    } catch {
        return "";
    }
}

function safeFilename(raw) {
    return String(raw)
        .replace(/[^A-Za-z0-9._ -]+/g, "-")
        .replace(/\s+/g, " ")
        .replace(/^\.+/, "")
        .trim()
        .slice(0, 160) || "meshvault-download";
}

function documentTitleFallback(tab) {
    return tab?.title || "MeshVault download";
}

function cancelBrowserDownload(downloadId) {
    chrome.downloads.cancel(downloadId, () => {
        void chrome.runtime.lastError;
        chrome.downloads.erase({ id: downloadId }, () => void chrome.runtime.lastError);
    });
}

function openUrlInBrowser(tabId, url) {
    if (typeof tabId === "number" && tabId >= 0) chrome.tabs.update(tabId, { url });
    else chrome.tabs.create({ url });
}

function notify(title, message) {
    chrome.notifications.create({
        type: "basic",
        iconUrl: "icons/icon48.png",
        title,
        message
    });
}

function sendDownloadStatus(tabId, status) {
    if (typeof tabId !== "number" || tabId < 0) return;
    chrome.tabs.sendMessage(tabId, {
        action: "meshVaultDownloadStatus",
        status
    }, async () => {
        if (!chrome.runtime.lastError) return;
        await ensureContentLoaderForStatus(tabId);
        chrome.tabs.sendMessage(tabId, {
            action: "meshVaultDownloadStatus",
            status
        }, () => void chrome.runtime.lastError);
    });
}

async function ensureContentLoaderForStatus(tabId) {
    const tab = await chrome.tabs.get(tabId).catch(() => null);
    const scraperFile = getScraperFile(tab?.url || "");
    if (!scraperFile) return;
    await chrome.scripting.executeScript({
        target: { tabId },
        files: [scraperFile, "content_loader.js"]
    }).catch(() => null);
}

function updateBadge() {
    if (!extensionEnabled) {
        chrome.action.setBadgeText({ text: "OFF" });
        chrome.action.setBadgeBackgroundColor({ color: "#c93b3b" });
        void refreshAllTabIcons();
        return;
    }

    chrome.action.setBadgeText({ text: activeDownloads > 0 ? String(activeDownloads) : "" });
    chrome.action.setBadgeBackgroundColor({ color: "#2f9e62" });
    void refreshAllTabIcons();
}

function setExtensionEnabled(enabled) {
    chrome.storage.local.set({ extensionEnabled: Boolean(enabled) }, () => {
        void chrome.runtime.lastError;
    });
}

async function toggleSiteEnabled(pageUrl) {
    const url = pageUrl || (await getActiveTabUrl());
    const domain = getSiteDomainForUrl(url);
    if (!domain) return;
    const next = { ...disabledSites, [domain]: !disabledSites[domain] };
    chrome.storage.local.set({ disabledSites: next }, () => {
        void chrome.runtime.lastError;
    });
}

async function getActiveTabUrl() {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true }).catch(() => []);
    return tabs[0]?.url || "";
}

async function updateToggleContextMenu() {
    if (!chrome.contextMenus?.create) return;
    upsertActionContextMenu(TOGGLE_CONTEXT_MENU_ID, extensionEnabled ? "Disable MeshVault Connect" : "Enable MeshVault Connect", true);
    const activeUrl = await getActiveTabUrl();
    const activeDomain = getSiteDomainForUrl(activeUrl);
    const activeSiteLabel = getSiteLabel(activeDomain);
    const siteToggleLabel = activeSiteLabel || "this site";
    upsertActionContextMenu(
        TOGGLE_SITE_CONTEXT_MENU_ID,
        disabledSites[activeDomain] ? `Resume MeshVault on ${siteToggleLabel}` : `Pause MeshVault on ${siteToggleLabel}`,
        Boolean(activeDomain)
    );
    upsertActionContextMenu(CANCEL_CONTEXT_MENU_ID, "Cancel MeshVault Download", activeDownloads > 0 || pendingDownload != null || capturedBlobSessions.size > 0);
    upsertActionContextMenu(CLEAR_METADATA_CONTEXT_MENU_ID, "Clear Stored Metadata", true);
}

function upsertActionContextMenu(id, title, enabled) {
    chrome.contextMenus.update(id, { title, enabled }, () => {
        if (!chrome.runtime.lastError) return;
        chrome.contextMenus.create({
            id,
            title,
            enabled,
            contexts: ["action"]
        }, () => void chrome.runtime.lastError);
    });
}

function createTrackedAbortController() {
    const controller = new AbortController();
    activeAbortControllers.add(controller);
    updateToggleContextMenu();
    return controller;
}

function releaseTrackedAbortController(controller) {
    if (!controller) return;
    activeAbortControllers.delete(controller);
    updateToggleContextMenu();
}

function cancelActiveMeshVaultDownloads() {
    resolvePrompt(null);
    capturedBlobSessions.clear();
    for (const controller of Array.from(activeAbortControllers)) {
        try {
            controller.abort();
        } catch {
            // Keep cancelling the rest.
        }
    }
    activeAbortControllers.clear();
    activeDownloads = 0;
    updateBadge();
    updateToggleContextMenu();
}

function clearAllStoredMetadata(notifyUser = true) {
    metadataByPageUrl.clear();
    cultsOrderMetadataByUrl.clear();
    cultsFallback = null;
    if (notifyUser) notify("MeshVault Connect", "Stored metadata cache cleared.");
}

function formatBytes(bytes) {
    if (!Number.isFinite(bytes) || bytes <= 0) return "0 B";
    const units = ["B", "KB", "MB", "GB"];
    let size = bytes;
    let unit = 0;
    while (size >= 1024 && unit < units.length - 1) {
        size /= 1024;
        unit++;
    }
    return `${size.toFixed(size >= 10 || unit === 0 ? 0 : 1)} ${units[unit]}`;
}

function getStoredString(key, fallback) {
    return new Promise((resolve) => chrome.storage.local.get({ [key]: fallback }, (result) => resolve(result[key] || fallback)));
}

function getStoredBoolean(key, fallback) {
    return new Promise((resolve) => chrome.storage.local.get({ [key]: fallback }, (result) => resolve(Boolean(result[key]))));
}

async function getMeshVaultTarget() {
    const settings = await new Promise((resolve) => chrome.storage.local.get({
        meshVaultTargetMode: "desktop",
        meshVaultServerBaseUrl: DEFAULT_SERVER_BASE_URL,
        meshVaultServerToken: ""
    }, resolve));

    const serverMode = settings.meshVaultTargetMode === "server";
    const baseUrl = serverMode
        ? normalizeMeshVaultBaseUrl(settings.meshVaultServerBaseUrl || DEFAULT_SERVER_BASE_URL)
        : DESKTOP_BASE_URL;
    const token = serverMode ? String(settings.meshVaultServerToken || "").trim() : "";
    const headers = token ? { "X-MeshVault-Token": token } : {};
    return { baseUrl, headers, serverMode };
}

function normalizeMeshVaultBaseUrl(value) {
    const raw = String(value || "").trim() || DEFAULT_SERVER_BASE_URL;
    try {
        const url = new URL(raw.includes("://") ? raw : `http://${raw}`);
        url.pathname = "";
        url.search = "";
        url.hash = "";
        return url.toString().replace(/\/$/, "");
    } catch {
        return DEFAULT_SERVER_BASE_URL;
    }
}

function isExtensionEnabled() {
    return new Promise((resolve) => {
        chrome.storage.local.get({ extensionEnabled: true }, (settings) => {
            extensionEnabled = settings.extensionEnabled !== false;
            resolve(extensionEnabled);
        });
    });
}

async function shouldHandleMessageWhenDisabled(message) {
    const action = message?.action || "";
    const alwaysAllowed = new Set([
        "getPendingDownload",
        "cancelPrompt",
        "setDownloadFolder",
        "validateMetadataCapture"
    ]);
    if (alwaysAllowed.has(action)) return true;
    return await isExtensionEnabled();
}

function promptForFolder(payload) {
    resolvePrompt(null);
    pendingDownload = payload;
    return new Promise((resolve) => {
        pendingResolver = resolve;
        chrome.windows.create({
            url: chrome.runtime.getURL("prompt.html"),
            type: "popup",
            width: 420,
            height: 330
        }, (win) => {
            promptWindowId = win?.id ?? null;
        });
    });
}

function resolvePrompt(value) {
    if (pendingResolver) pendingResolver(value);
    pendingResolver = null;
    pendingDownload = null;
    if (promptWindowId != null) {
        chrome.windows.remove(promptWindowId, () => void chrome.runtime.lastError);
        promptWindowId = null;
    }
}
