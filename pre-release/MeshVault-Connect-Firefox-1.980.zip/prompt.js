const DESKTOP_BASE_URL = "http://localhost:24268";
const DEFAULT_SERVER_BASE_URL = "http://localhost:5225";
const meshVaultBrowser = typeof browser !== "undefined" ? browser : chrome;

const folderSelect = document.getElementById("folderSelect");
const saveBtn = document.getElementById("saveBtn");
const cancelBtn = document.getElementById("cancelBtn");
const status = document.getElementById("status");
const fileLabel = document.getElementById("fileLabel");
const customFolder = document.getElementById("customFolder");
const customFolderFromSelection = document.getElementById("customFolderFromSelection");

let promptPort = null;
let promptHeartbeat = null;

function resizePromptWindow() {
    try {
        window.resizeTo(405, 310);
    } catch {
        // ignore
    }
}

function setStatus(text) {
    status.textContent = text;
}

function connectPromptPort() {
    try {
        promptPort = chrome.runtime.connect({ name: "meshvault-prompt" });
        promptHeartbeat = setInterval(() => {
            try {
                promptPort?.postMessage({ action: "keepPromptAlive" });
            } catch {
                // The save handler will surface any real connection failure.
            }
        }, 20000);
        promptPort.onDisconnect.addListener(() => {
            promptPort = null;
            if (promptHeartbeat) clearInterval(promptHeartbeat);
            promptHeartbeat = null;
        });
    } catch {
        promptPort = null;
    }
}

async function loadPendingInfo() {
    const info = await chrome.runtime.sendMessage({ action: "getPendingDownload" });
    if (info?.title) {
        fileLabel.textContent = info.title;
    } else if (info?.url) {
        try {
            const name = info.url.split("/").pop().split("?")[0];
            fileLabel.textContent = name || "Download";
        } catch {
            fileLabel.textContent = "Download";
        }
    }
}

async function fetchFolders() {
    setStatus("Loading folders...");
    try {
        const target = await getMeshVaultTarget();
        const resp = await fetchTargetFolders(target);
        if (!resp.ok) throw new Error("MeshVault target not running");
        const data = await resp.json();
        const folders = normalizeFolderResponse(data);
        return ["Unsorted", ...folders.filter((f) => f && f !== "Unsorted")];
    } catch {
        setStatus("MeshVault target not running.");
        return ["Unsorted"];
    }
}

async function populateFolders() {
    const folders = await fetchFolders();
    folderSelect.innerHTML = "";
    const last = await storageGet({ lastPromptFolder: "Unsorted" });
    folders.forEach((folder) => {
        const opt = document.createElement("option");
        opt.value = folder;
        opt.textContent = folder;
        if (folder === last.lastPromptFolder) opt.selected = true;
        folderSelect.appendChild(opt);
    });
    setStatus("");
}

saveBtn.addEventListener("click", async () => {
    const custom = (customFolder.value || "").trim();
    const selected = folderSelect.value || "Unsorted";
    let folder = selected;
    if (custom) {
        if (customFolderFromSelection.checked && selected && selected !== "Unsorted") {
            folder = `${selected}/${custom}`;
        } else {
            folder = custom;
        }
    }
    saveBtn.disabled = true;
    setStatus("Saving...");
    try {
        const response = await chrome.runtime.sendMessage({
            action: "setDownloadFolder",
            folder
        });
        if (!response?.ok) {
            saveBtn.disabled = false;
            setStatus(response?.message || "Save prompt expired. Try the download again.");
        }
    } catch (err) {
        saveBtn.disabled = false;
        setStatus(err?.message || "Could not save.");
    }
});

cancelBtn.addEventListener("click", () => {
    chrome.runtime.sendMessage({
        action: "cancelPrompt"
    });
    window.close();
});

async function getMeshVaultTarget() {
    const settings = await storageGet({
        meshVaultTargetMode: "desktop",
        meshVaultServerBaseUrl: DEFAULT_SERVER_BASE_URL,
        meshVaultServerToken: ""
    });
    const serverMode = settings.meshVaultTargetMode === "server";
    const baseUrl = serverMode
        ? normalizeMeshVaultBaseUrl(settings.meshVaultServerBaseUrl || DEFAULT_SERVER_BASE_URL)
        : DESKTOP_BASE_URL;
    const token = serverMode ? String(settings.meshVaultServerToken || "").trim() : "";
    const headers = token ? { "X-MeshVault-Token": token } : {};
    return { baseUrl, headers, serverMode };
}

function normalizeMeshVaultBaseUrl(value) {
    const raw = String(value || "").trim() || DEFAULT_SERVER_BASE_URL;
    try {
        const url = new URL(raw.includes("://") ? raw : `http://${raw}`);
        url.pathname = "";
        url.search = "";
        url.hash = "";
        return url.toString().replace(/\/$/, "");
    } catch {
        return DEFAULT_SERVER_BASE_URL;
    }
}

async function fetchTargetFolders(target) {
    const paths = target.serverMode ? ["/folders", "/api/folders"] : ["/folders"];
    let lastResponse = null;
    for (const path of paths) {
        const response = await fetch(`${target.baseUrl}${path}`, {
            method: "GET",
            headers: target.headers
        });
        if (response.ok || response.status === 401 || response.status === 402) return response;
        lastResponse = response;
    }
    return lastResponse;
}

function normalizeFolderResponse(data) {
    if (Array.isArray(data?.folders)) return data.folders;
    if (Array.isArray(data)) return data.map((folder) => folder?.path || folder?.Path || folder?.name || folder?.Name || "");
    return [];
}

function storageGet(defaults) {
    return callWebExtensionApi(meshVaultBrowser.storage.local.get, meshVaultBrowser.storage.local, defaults)
        .then((result) => result || defaults);
}

function callWebExtensionApi(fn, thisArg, ...args) {
    try {
        const result = fn.call(thisArg, ...args);
        if (result?.then) return result;
    } catch (err) {
        return Promise.reject(err);
    }

    return new Promise((resolve, reject) => {
        try {
            fn.call(thisArg, ...args, (result) => {
                const err = chrome.runtime?.lastError;
                if (err) reject(new Error(err.message));
                else resolve(result);
            });
        } catch (err) {
            reject(err);
        }
    });
}

connectPromptPort();
populateFolders();
loadPendingInfo();
resizePromptWindow();




