const DESKTOP_BASE_URL = "http://localhost:24268";
const DEFAULT_SERVER_BASE_URL = "http://localhost:5225";
const meshVaultBrowser = typeof browser !== "undefined" ? browser : chrome;

const folderSelect = document.getElementById("folderSelect");
const refreshBtn = document.getElementById("refreshBtn");
const saveStatus = document.getElementById("saveStatus");
const extensionEnabled = document.getElementById("extensionEnabled");
const targetMode = document.getElementById("targetMode");
const serverTargetFields = document.getElementById("serverTargetFields");
const serverBaseUrl = document.getElementById("serverBaseUrl");
const serverToken = document.getElementById("serverToken");
const saveServerTargetBtn = document.getElementById("saveServerTargetBtn");
const testTargetBtn = document.getElementById("testTargetBtn");
const promptPerDownload = document.getElementById("promptPerDownload");
const notifyDesktopOffline = document.getElementById("notifyDesktopOffline");
const blockAIGenerated = document.getElementById("blockAIGenerated");
const siteToggles = document.getElementById("siteToggles");
const validateBtn = document.getElementById("validateBtn");
const validationStatus = document.getElementById("validationStatus");
const validationResult = document.getElementById("validationResult");
const validationPill = document.getElementById("validationPill");
const validationMessage = document.getElementById("validationMessage");
const validationSourceSite = document.getElementById("validationSourceSite");
const validationMetadataSource = document.getElementById("validationMetadataSource");
const validationPageUrl = document.getElementById("validationPageUrl");
const validationCheckedAt = document.getElementById("validationCheckedAt");
const validationFields = document.getElementById("validationFields");
const metadataPreview = document.getElementById("metadataPreview");
const debugLog = document.getElementById("debugLog");

const VALIDATION_FIELDS = [
    ["fileName", "File name"],
    ["folder", "Folder"],
    ["sourceUrl", "Source URL"],
    ["downloadUrl", "Download URL during import"],
    ["title", "Title"],
    ["author", "Author"],
    ["authorUrl", "Author URL"],
    ["description", "Description"],
    ["tags", "Tags"],
    ["thumbnailUrl", "Thumbnail"],
    ["imageMetadata", "Image metadata"],
    ["summary", "Summary"],
    ["images", "Extra gallery images"],
    ["printSettingsJson", "Print settings"],
    ["capturedAtUtc", "Captured timestamp"]
];

const SITE_OPTIONS = [
    ["printables.com", "Printables"],
    ["thingiverse.com", "Thingiverse"],
    ["makerworld.com", "MakerWorld"],
    ["thangs.com", "Thangs"],
    ["cults3d.com", "Cults3D"],
    ["grabcad.com", "GrabCAD"],
    ["myminifactory.com", "MyMiniFactory"],
    ["tinkercad.com", "Tinkercad"]
];

function setStatus(text) {
    saveStatus.textContent = text;
}

function debug(message, detail = null) {
    if (!debugLog) return;
    debugLog.style.display = "block";
    const stamp = new Date().toLocaleTimeString();
    const suffix = detail == null
        ? ""
        : ` ${typeof detail === "string" ? detail : JSON.stringify(detail)}`;
    debugLog.textContent += `[${stamp}] ${message}${suffix}\n`;
    debugLog.scrollTop = debugLog.scrollHeight;
}

function saveSelectedFolder(folder) {
    chrome.storage.local.set({ targetFolder: folder }, () => {
        setStatus("Saved");
        setTimeout(() => setStatus(""), 1500);
    });
}

function loadSelectedFolder() {
    return new Promise((resolve) => {
        chrome.storage.local.get({
            extensionEnabled: true,
            targetFolder: "Unsorted",
            promptPerDownload: true,
            notifyDesktopOffline: true,
            meshVaultTargetMode: "desktop",
            meshVaultServerBaseUrl: DEFAULT_SERVER_BASE_URL,
            meshVaultServerToken: "",
            blockAIGenerated: null,
            blockAIGeneratedThingiverse: null,
            disabledSites: {}
        }, (result) => {
            resolve(result.targetFolder || "Unsorted");
            extensionEnabled.checked = result.extensionEnabled !== false;
            targetMode.value = result.meshVaultTargetMode === "server" ? "server" : "desktop";
            serverBaseUrl.value = result.meshVaultServerBaseUrl || DEFAULT_SERVER_BASE_URL;
            serverToken.value = result.meshVaultServerToken || "";
            updateTargetFields();
            promptPerDownload.checked = Boolean(result.promptPerDownload);
            notifyDesktopOffline.checked = Boolean(result.notifyDesktopOffline);
            renderSiteToggles(result.disabledSites || {});
            let aiEnabled = result.blockAIGenerated;
            if (aiEnabled == null) {
                aiEnabled = Boolean(result.blockAIGeneratedThingiverse);
                chrome.storage.local.set({ blockAIGenerated: aiEnabled }, () => {
                    void chrome.runtime.lastError;
                });
            }
            blockAIGenerated.checked = Boolean(aiEnabled);
        });
    });
}

async function fetchFolders() {
    try {
        const target = await getMeshVaultTarget();
        const resp = await fetchTargetPath(target, "folders");
        if (!resp.ok) throw new Error("MeshVault target not running");
        const data = await resp.json();
        const folders = normalizeFolderResponse(data);
        return ["Unsorted", ...folders.filter((f) => f && f !== "Unsorted")];
    } catch (err) {
        setStatus(`MeshVault target not running: ${formatConnectionError(err)}`);
        return ["Unsorted"];
    }
}

async function populateFolders() {
    const folders = await fetchFolders();
    const selected = await loadSelectedFolder();

    folderSelect.innerHTML = "";
    folders.forEach((folder) => {
        const opt = document.createElement("option");
        opt.value = folder;
        opt.textContent = folder;
        if (folder === selected) opt.selected = true;
        folderSelect.appendChild(opt);
    });
}

folderSelect.addEventListener("change", () => {
    saveSelectedFolder(folderSelect.value);
});

extensionEnabled.addEventListener("change", () => {
    chrome.storage.local.set({ extensionEnabled: extensionEnabled.checked }, () => {
        setStatus(extensionEnabled.checked ? "Enabled" : "Disabled");
        setTimeout(() => setStatus(""), 1500);
    });
});

promptPerDownload.addEventListener("change", () => {
    chrome.storage.local.set({ promptPerDownload: promptPerDownload.checked }, () => {
        setStatus("Saved");
        setTimeout(() => setStatus(""), 1500);
    });
});

notifyDesktopOffline.addEventListener("change", () => {
    chrome.storage.local.set({ notifyDesktopOffline: notifyDesktopOffline.checked }, () => {
        setStatus("Saved");
        setTimeout(() => setStatus(""), 1500);
    });
});

blockAIGenerated.addEventListener("change", () => {
    chrome.storage.local.set({ blockAIGenerated: blockAIGenerated.checked }, () => {
        chrome.storage.local.remove("blockAIGeneratedThingiverse", () => {
            void chrome.runtime.lastError;
        });
        setStatus("Saved");
        setTimeout(() => setStatus(""), 1500);
    });
});

refreshBtn.addEventListener("click", () => {
    populateFolders();
});

targetMode.addEventListener("change", () => {
    updateTargetFields();
    if (targetMode.value === "desktop") {
        saveTargetSettings(false);
    } else {
        setStatus("Save server target to grant access.");
    }
});

serverBaseUrl.addEventListener("change", () => setStatus("Save server target to apply changes."));
serverToken.addEventListener("change", () => setStatus("Save server target to apply changes."));

saveServerTargetBtn.addEventListener("click", async () => {
    saveServerTargetBtn.disabled = true;
    setStatus("Saving server target...");
    debug("Save server target clicked", { mode: targetMode.value, url: serverBaseUrl.value, hasToken: Boolean(serverToken.value.trim()) });
    try {
        if (await saveTargetSettings(true)) {
            debug("Server target saved");
            await populateFolders();
            debug("Folders refreshed after save");
        } else {
            debug("Server target save returned false");
        }
    } catch (err) {
        debug("Save failed", err?.message || String(err));
        setStatus(`Save failed: ${formatConnectionError(err)}`);
    } finally {
        saveServerTargetBtn.disabled = false;
    }
});

testTargetBtn.addEventListener("click", async () => {
    testTargetBtn.disabled = true;
    setStatus("Testing...");
    debug("Test connection clicked", { mode: targetMode.value, url: serverBaseUrl.value, hasToken: Boolean(serverToken.value.trim()) });
    try {
        if (!await saveTargetSettings(true)) {
            debug("Test stopped because saveTargetSettings returned false");
            return;
        }
        const target = await getMeshVaultTarget();
        debug("Testing target", { baseUrl: target.baseUrl, serverMode: target.serverMode, hasHeaders: Object.keys(target.headers || {}).length > 0 });
        const statusResponse = await fetchTargetPath(target, "status");
        debug("Status response", { status: statusResponse.status, ok: statusResponse.ok });
        if (!statusResponse.ok) throw new Error(`HTTP ${statusResponse.status}`);
        const status = await statusResponse.json().catch(() => ({}));
        debug("Status payload", status);
        if (target.serverMode) {
            const authResponse = await testServerImportAuthorization(target);
            debug("Upload auth response", { status: authResponse.status, ok: authResponse.ok });
            if (authResponse.status === 401) throw new Error("Server token was rejected");
            if (authResponse.status === 402) {
                setStatus("Connected, but server is read-only. Activate MeshVault Pro on the server to import downloads.");
                return;
            }
            if (authResponse.status !== 400) throw new Error(`Upload auth check returned HTTP ${authResponse.status}`);
        }
        const readOnly = status?.isReadOnly === true || status?.isProUnlocked === false;
        setStatus(readOnly ? "Connected, but server is read-only." : "Connected and ready to import.");
        await populateFolders();
        debug("Folders refreshed after test");
    } catch (err) {
        debug("Test failed", err?.message || String(err));
        setStatus(`Connection failed: ${formatConnectionError(err)}`);
    } finally {
        testTargetBtn.disabled = false;
    }
});

validateBtn.addEventListener("click", async () => {
    validationStatus.textContent = "Checking...";
    validateBtn.disabled = true;
    try {
        const result = await chrome.runtime.sendMessage({ action: "validateMetadataCapture" });
        renderValidationResult(result || {
            ok: false,
            message: "No validation response was returned by the extension background worker."
        });
    } catch (err) {
        renderValidationResult({
            ok: false,
            message: err?.message || "Validation failed."
        });
    } finally {
        validateBtn.disabled = false;
        validationStatus.textContent = "";
    }
});

function renderValidationResult(result) {
    const metadata = result?.metadata || {};
    validationResult.classList.add("visible");
    validationPill.textContent = result?.ok ? "PASS" : "FAIL";
    validationPill.classList.toggle("pass", Boolean(result?.ok));
    validationMessage.textContent = result?.message || "";
    validationSourceSite.textContent = result?.sourceSite || "Unknown";
    validationMetadataSource.textContent = result?.metadataSource || result?.scraperFile || "None";
    validationPageUrl.textContent = result?.pageUrl || "No supported page found";
    validationCheckedAt.textContent = result?.checkedAtUtc || "";

    validationFields.innerHTML = "";
    VALIDATION_FIELDS.forEach(([key, label]) => {
        const item = document.createElement("li");
        const present = key === "imageMetadata"
            ? hasMetadataValue(metadata.thumbnailUrl) || hasMetadataValue(metadata.images)
            : hasMetadataValue(metadata[key]);
        item.className = present ? "present" : "";
        item.textContent = `${present ? "OK" : "--"} ${label}`;
        validationFields.appendChild(item);
    });

    metadataPreview.textContent = result?.metadata
        ? JSON.stringify(result.metadata, null, 2)
        : result?.rawMetadataPreview || "No metadata captured.";
}

function renderSiteToggles(disabledSites) {
    siteToggles.innerHTML = "";
    SITE_OPTIONS.forEach(([domain, label]) => {
        const id = `site-${domain.replace(/[^a-z0-9]/gi, "-")}`;
        const row = document.createElement("div");
        row.className = "site-toggle";

        const input = document.createElement("input");
        input.type = "checkbox";
        input.id = id;
        input.checked = !disabledSites[domain];
        input.addEventListener("change", () => {
            chrome.storage.local.get({ disabledSites: {} }, (result) => {
                const next = { ...(result.disabledSites || {}) };
                next[domain] = !input.checked;
                chrome.storage.local.set({ disabledSites: next }, () => {
                    setStatus(input.checked ? `${label} enabled` : `${label} disabled`);
                    setTimeout(() => setStatus(""), 1500);
                });
            });
        });

        const text = document.createElement("label");
        text.htmlFor = id;
        text.textContent = label;

        row.append(input, text);
        siteToggles.appendChild(row);
    });
}

function hasMetadataValue(value) {
    if (Array.isArray(value)) return value.length > 0;
    if (value == null) return false;
    return String(value).trim().length > 0;
}

function updateTargetFields() {
    serverTargetFields.style.display = targetMode.value === "server" ? "block" : "none";
}

async function saveTargetSettings(requestPermission) {
    const normalized = normalizeMeshVaultBaseUrl(serverBaseUrl.value || DEFAULT_SERVER_BASE_URL);
    serverBaseUrl.value = normalized;
    debug("saveTargetSettings", { requestPermission, normalized, mode: targetMode.value });
    if (targetMode.value === "server" && requestPermission) {
        const granted = await requestServerOriginPermission(normalized);
        debug("Server permission result", { granted });
        if (!granted) {
            debug("Continuing without runtime permission grant; manifest host permissions or the fetch step will decide access.");
        }
    }

    await storageSet({
        meshVaultTargetMode: targetMode.value === "server" ? "server" : "desktop",
        meshVaultServerBaseUrl: normalized,
        meshVaultServerToken: serverToken.value.trim()
    });
    debug("storageSet complete");
    setStatus("Saved");
    setTimeout(() => setStatus(""), 1500);
    return true;
}

async function getMeshVaultTarget() {
    const settings = await storageGet({
        meshVaultTargetMode: "desktop",
        meshVaultServerBaseUrl: DEFAULT_SERVER_BASE_URL,
        meshVaultServerToken: ""
    });
    const serverMode = settings.meshVaultTargetMode === "server";
    const baseUrl = serverMode
        ? normalizeMeshVaultBaseUrl(settings.meshVaultServerBaseUrl || DEFAULT_SERVER_BASE_URL)
        : DESKTOP_BASE_URL;
    const token = serverMode ? String(settings.meshVaultServerToken || "").trim() : "";
    const headers = token ? { "X-MeshVault-Token": token } : {};
    return { baseUrl, headers, serverMode };
}

function normalizeMeshVaultBaseUrl(value) {
    const raw = String(value || "").trim() || DEFAULT_SERVER_BASE_URL;
    try {
        const url = new URL(raw.includes("://") ? raw : `http://${raw}`);
        url.pathname = "";
        url.search = "";
        url.hash = "";
        return url.toString().replace(/\/$/, "");
    } catch {
        return DEFAULT_SERVER_BASE_URL;
    }
}

async function requestServerOriginPermission(baseUrl) {
    try {
        const url = new URL(baseUrl);
        const origin = `${url.protocol}//${url.host}/*`;
        debug("Checking server permission", { origin });
        if (await permissionsContains({ origins: [origin] })) return true;
        debug("Requesting server permission", { origin });
        return await permissionsRequest({ origins: [origin] });
    } catch {
        return false;
    }
}

function storageGet(defaults) {
    return callWebExtensionApi(meshVaultBrowser.storage.local.get, meshVaultBrowser.storage.local, defaults)
        .then((result) => result || defaults);
}

function storageSet(values) {
    return callWebExtensionApi(meshVaultBrowser.storage.local.set, meshVaultBrowser.storage.local, values);
}

function permissionsContains(query) {
    if (!meshVaultBrowser.permissions?.contains) return Promise.resolve(true);
    return callWebExtensionApi(meshVaultBrowser.permissions.contains, meshVaultBrowser.permissions, query)
        .then((granted) => Boolean(granted));
}

function permissionsRequest(query) {
    if (!meshVaultBrowser.permissions?.request) return Promise.resolve(true);
    return callWebExtensionApi(meshVaultBrowser.permissions.request, meshVaultBrowser.permissions, query)
        .then((granted) => Boolean(granted));
}

function callWebExtensionApi(fn, thisArg, ...args) {
    try {
        const result = fn.call(thisArg, ...args);
        if (result?.then) return result;
    } catch (err) {
        return Promise.reject(err);
    }

    return new Promise((resolve, reject) => {
        try {
            fn.call(thisArg, ...args, (result) => {
                const err = chrome.runtime?.lastError;
                if (err) reject(new Error(err.message));
                else resolve(result);
            });
        } catch (err) {
            reject(err);
        }
    });
}

async function fetchTargetPath(target, kind) {
    const paths = getTargetPaths(target, kind);
    let lastResponse = null;
    let lastError = null;
    for (const path of paths) {
        try {
            debug("Fetch target path", { kind, path });
            const response = await fetch(`${target.baseUrl}${path}`, {
                method: "GET",
                headers: target.headers
            });
            if (response.ok || response.status === 401 || response.status === 402) return response;
            lastResponse = response;
        } catch (err) {
            lastError = err;
        }
    }
    if (lastResponse) return lastResponse;
    throw lastError || new Error("Connection failed");
}

function getTargetPaths(target, kind) {
    if (!target.serverMode) return kind === "status" ? ["/status"] : ["/folders"];
    return kind === "status" ? ["/api/status", "/status"] : ["/folders", "/api/folders"];
}

function normalizeFolderResponse(data) {
    if (Array.isArray(data?.folders)) return data.folders;
    if (Array.isArray(data)) return data.map((folder) => folder?.path || folder?.Path || folder?.name || folder?.Name || "");
    return [];
}

async function testServerImportAuthorization(target) {
    const formData = new FormData();
    return fetch(`${target.baseUrl}/upload`, {
        method: "POST",
        headers: target.headers,
        body: formData
    });
}

function formatConnectionError(err) {
    const message = err?.message || String(err || "unknown error");
    if (message === "Failed to fetch" || message.includes("NetworkError")) {
        return "could not reach the server. Check the URL, permission prompt, firewall, and that MeshVault Server is running.";
    }
    return message;
}

populateFolders();
